const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const root=process.cwd(),dir=path.join(root,'.tmp/document-cleanup-publish'),q=path.join(root,'docs/_ops/qa/document-cleanup-20261017');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=a=>cp.execFileSync('git',a,{maxBuffer:30e6,windowsHide:true});
const base=git(['rev-parse','origin/master']).toString().trim();
const tracked=new Set(git(['ls-tree','-r','--name-only',base]).toString().split('\n'));
const chains=JSON.parse(fs.readFileSync(path.join(dir,'all-chains.json')));
const stage=path.join(dir,'source-stage'),recovery=path.join(dir,'recovery-input');
const norm=b=>b.toString('utf8').replace(/\r\n/g,'\n');
function write(p,b){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);}
const results=[],conflicts=[];
const shared=new Set(['docs/_ops/결정.md','docs/_ops/트랙.md']);
const ownedNew=new Set(['docs/마케팅/HyperFrames_기존영상_참고.md']);
for(const item of chains.files){
 const p=item.path,a=item.steps;
 const latest=a.at(-1),current=fs.readFileSync(p);
 if(sha(current)!==latest.afterSha256&&!shared.has(p)&&p!=='docs/문서_지도.md')throw Error('Current drift '+p);
 write(path.join(recovery,'repo-before',p),fs.readFileSync(a[0].beforePath));
 write(path.join(recovery,'repo-after',p),current);
 if(!tracked.has(p)&&!ownedNew.has(p)){
  results.push({path:p,kind:'untracked-delta-backup',beforeSha256:a[0].beforeSha256,afterSha256:sha(current)});continue;
 }
 if(ownedNew.has(p)){
  write(path.join(stage,p),current);results.push({path:p,kind:'owned-new-source',afterSha256:sha(current)});continue;
 }
 const remote=git(['cat-file','blob',base+':'+p]);let content=norm(remote);
 if(shared.has(p)){
  const source=norm(current).split('\n');
  if(p.endsWith('결정.md')){
   for(const key of ['[문서·지침 정리 · 로컬 반영]','[영상 제작 도구]']){
    const rows=source.filter(s=>s.includes(key));if(rows.length!==1)throw Error('Ambiguous own decision '+key);
    const lines=content.split('\n'),hits=lines.map((s,i)=>s.includes(key)?i:-1).filter(i=>i>=0);
    if(hits.length>1)throw Error('Ambiguous remote decision '+key);
    if(hits.length)lines[hits[0]]=rows[0];else {const at=lines.indexOf('|---|---|---|---|');if(at<0)throw Error('No decision table');lines.splice(at+1,0,rows[0]);}
    content=lines.join('\n');
   }
  }else{
   const rows=source.filter(s=>s.startsWith('2026-10-17 문서·지침 정리는 '));if(rows.length!==1)throw Error('No own track row');
   const lines=content.split('\n'),at=lines.findIndex(s=>s.startsWith('2026-10-17 문서·지침 정리는 '));
   if(at>=0)lines[at]=rows[0];else{const i=lines.findIndex(s=>s.startsWith('## 1.'));if(i<0)throw Error('No track section');lines.splice(i,0,rows[0],'');}content=lines.join('\n');
  }
 }else{
  for(let i=0;i<a.length;i++){
   const f=a[i];let afterPath=f.afterPath;
   if(!afterPath){const indexFile=path.join(dir,'recovered/index.json');if(fs.existsSync(indexFile)){const recoveries=JSON.parse(fs.readFileSync(indexFile));afterPath=recoveries.find(r=>r.path===p&&r.phase===f.phase)?.afterPath;}}
   if(!afterPath){conflicts.push({path:p,reason:'missing exact phase after',phase:f.phase});content=null;break;}
   const before=fs.readFileSync(f.beforePath),after=fs.readFileSync(afterPath);
   if(sha(before)!==f.beforeSha256||sha(after)!==f.afterSha256)throw Error('Phase hash mismatch '+p+' '+f.phase);
   if(norm(before)===norm(after))continue;
   const work=path.join(dir,'merge-input');fs.mkdirSync(work,{recursive:true});
   const inputs=['remote','before','after'].map(x=>path.join(work,x));
   [content,norm(before),norm(after)].forEach((s,j)=>fs.writeFileSync(inputs[j],s));
   const m=cp.spawnSync('git',['merge-file','-p',...inputs],{encoding:'utf8',windowsHide:true,maxBuffer:30e6});
   if(m.status!==0){
    let resolved=m.stdout;
    const blocks=[...resolved.matchAll(/^<<<<<<<[^\n]*\n([\s\S]*?)^=======\n([\s\S]*?)^>>>>>>>[^\n]*\n/gm)];
    if(p==='AGENTS.md'&&f.phase==='hyperframes-scope-validation.json'&&blocks.length===1){
     const b=blocks[0],addition=' 새 영상과 기존 영상의 도구 범위는 [제작 도구 선택](docs/마케팅/콘텐츠_제작방식_v2_20261002.md#video-tool-selection)을 따른다.';
     if(!b[1].includes('그 자리에서 장부에 올린다.')||!b[2].includes(addition))throw Error('Unexpected AGENTS conflict');
     resolved=resolved.replace(b[0],b[1].replace('그 자리에서 장부에 올린다.','그 자리에서 장부에 올린다.'+addition));
    }else if(p==='docs/마케팅/온라인마케팅지도/engagement/company/CLOUD-OPERATIONS.md'&&f.phase==='validation-pass3.json'&&blocks.length===1){
     const b=blocks[0];if(b[1]!==''||!b[2].includes('2026-10-14 다음 릴리스 통합 후보'))throw Error('Unexpected CLOUD conflict');
     resolved=resolved.replace(b[0],b[1]);
    }else{const conflictPath=path.join(dir,'conflicts',p);write(conflictPath,m.stdout);conflicts.push({path:p,reason:'merge conflict',phase:f.phase,file:conflictPath});content=null;break;}
    if(/^([<=>])\1{6}/m.test(resolved))throw Error('Unresolved markers '+p);
    content=resolved;
   }else content=m.stdout;
  }
 }
 if(content!==null){
  const buffer=Buffer.from(content);write(path.join(stage,p),buffer);
  results.push({path:p,kind:content===norm(remote)?'already-applied':'scoped-source',baseSha256:sha(remote),beforeSha256:a[0].beforeSha256,afterSha256:latest.afterSha256,commitSha256:sha(buffer)});
 }
}
const output={base,stage,recovery,results,conflicts};write(path.join(dir,'source-plan.json'),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({base,counts:results.reduce((a,r)=>(a[r.kind]=(a[r.kind]||0)+1,a),{}),conflicts},null,2));
