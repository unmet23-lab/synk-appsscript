import hashlib, json, pathlib, zipfile

root = pathlib.Path.cwd()
work = root / '.tmp/document-cleanup-publish'
qa = root / 'docs/_ops/qa/document-cleanup-20261017'
plan = json.loads((work / 'source-plan.json').read_text(encoding='utf-8'))
assert not plan['conflicts']
archive = qa / 'recovery-20261017.zip'
manifest_path = qa / 'remote-backup-manifest.json'
entries = {}
def add(name, source):
    assert name not in entries and not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
    assert source.is_file() and not source.is_symlink(), source
    entries[name] = source.read_bytes()
def digest(data):
    return hashlib.sha256(data).hexdigest()
for source in sorted(qa.rglob('*')):
    if source.is_file() and source.name not in {archive.name, manifest_path.name, 'remote-push-verification.json', 'publication-scope.json'}:
        add('qa/' + source.relative_to(qa).as_posix(), source)
untracked = [x for x in plan['results'] if x['kind'] == 'untracked-delta-backup']
for item in untracked:
    for phase in ['before', 'after']:
        source = work / 'recovery-input' / ('repo-' + phase) / item['path']
        assert digest(source.read_bytes()) == item[phase + 'Sha256'], item['path']
        add('untracked-' + phase + '/' + item['path'], source)
global_changes = json.loads((qa / 'hyperframes-scope-global-changes.json').read_text(encoding='utf-8'))
for item in global_changes['files']:
    source = pathlib.Path(item['path'])
    assert digest(source.read_bytes()) == item['updatedSha256'], source
    assert digest(pathlib.Path(item['backup']).read_bytes()) == item['originalSha256'], source
    add('global-after/' + item['family'] + '/' + item['relativePath'], source)
for name in ['source-plan.json', 'all-chains.json', 'recovered-pass12.json', 'pass12-provenance.json', 'prepare-sources.cjs', 'recover-pass12.cjs', 'package-recovery.py']:
    source = work / name
    if source.is_file():
        add('publication-evidence/' + name, source)
for source in sorted((work / 'recovered').rglob('*')):
    if source.is_file():
        add('publication-evidence/recovered/' + source.relative_to(work / 'recovered').as_posix(), source)
records = [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(entries.items())]
internal = {
    'date': '2026-10-17', 'baseCommit': plan['base'], 'entries': records,
    'restore': [
        'Extract into a new empty folder, never directly over the working repository or global skills.',
        'qa/_archive contains original snapshots and retired duplicate skills; they are historical recovery data, not active guidance.',
        'global-after contains only the 26 edited global skill entry/UI files. Restore onto the matching existing skill version after comparing hashes; other referenced skill files are not included as a full installation.',
        'untracked-before and untracked-after preserve 55 pre-existing untracked documents without adopting their unrelated baseline contents into active repository source.',
        'Use the before/after hashes and phase ledgers to apply only needed changes; preserve later or concurrent edits.'
    ]
}
entries['bundle-manifest.json'] = (json.dumps(internal, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as z:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 17, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(entries)
    assert z.testzip() is None
    for name, data in entries.items():
        assert digest(z.read(name)) == digest(data), name
result = {
    'date': '2026-10-17', 'archive': archive.relative_to(root).as_posix(),
    'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
    'baseCommit': plan['base'], 'targetBranch': 'codex/document-cleanup-20261017',
    'entries': len(entries), 'uncompressedBytes': sum(len(b) for b in entries.values()),
    'verifiedEntries': len(entries), 'crcErrors': 0, 'sha256Errors': 0,
    'untrackedDocumentPairs': len(untracked), 'globalChangedFilesBeforeAndAfter': len(global_changes['files']),
    'retiredSkillFiles': sum(n.startswith('qa/_archive/retired-skill-copies/') and n != 'qa/_archive/retired-skill-copies/manifest.json' for n in entries),
    'restoreInstructions': internal['restore'],
    'publicationState': 'prepared; the remote branch and archive are verified after push in a separate local receipt'
}
manifest_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(work / 'recovery-summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'restoreInstructions'}, indent=2))
