const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const {spawnSync} = require('node:child_process');
const qa = 'docs/_ops/qa/document-cleanup-20261017';
const out = '.tmp/document-cleanup-publish';
const chains = JSON.parse(fs.readFileSync(out + '/all-chains.json', 'utf8'));
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const evidence = [];
function save(step, bytes, method, details) {
  if (sha(bytes) !== step.afterSha256) throw Error('After SHA mismatch: ' + step.path);
  const dest = out + '/recovered/' + step.path;
  fs.mkdirSync(path.dirname(dest), {recursive:true});
  if (fs.existsSync(dest) && sha(fs.readFileSync(dest)) !== step.afterSha256) throw Error('Existing recovery differs');
  fs.writeFileSync(dest, bytes);
  evidence.push({path:step.path, phase:step.phase, beforePath:step.beforePath, beforeSha256:step.beforeSha256,
    recoveredPath:dest, afterSha256:step.afterSha256, afterBytes:bytes.length, method, ...details});
}
{
  const rel = 'docs/마케팅/제작양식/만족사례_장부.md';
  const step = chains.files.find(x => x.path === rel).steps[0];
  const before = fs.readFileSync(step.beforePath);
  if (sha(before) !== step.beforeSha256) throw Error('Before SHA mismatch');
  const scriptPath = qa + '/edit-content-pass2.cjs';
  const script = fs.readFileSync(scriptPath, 'utf8');
  const marker = "edit('" + rel + "', r => {\n";
  const normalizedScript = script.replace(/\r\n/g, '\n');
  const start = normalizedScript.indexOf(marker);
  if (start < 0) throw Error('Callback not found');
  const end = normalizedScript.indexOf('\n});', start);
  const callbackBody = normalizedScript.slice(start + marker.length, end);
  const raw = before.toString('utf8');
  let s = raw.replace(/\r\n/g, '\n');
  let replacements = 0;
  vm.runInNewContext(callbackBody, {r:(a,b) => {
    if (!s.includes(a)) throw Error('Original replacement text not found');
    s = s.replace(a,b); replacements++;
  }}, {timeout:1000});
  if (replacements !== 5) throw Error('Unexpected replacement count');
  const bytes = Buffer.from(raw.includes('\r\n') ? s.replace(/\n/g, '\r\n') : s, 'utf8');
  save(step, bytes, 'Replay only the five guarded replacements in the saved pass2 callback against its immutable before snapshot; preserve original newline convention',
    {scriptPath, scriptSha256:sha(Buffer.from(script)), replacements});
}
{
  const rel = 'docs/문서_지도.md';
  const step = chains.files.find(x => x.path === rel).steps[0];
  const before = fs.readFileSync(step.beforePath);
  if (sha(before) !== step.beforeSha256) throw Error('Before SHA mismatch');
  const current = fs.readFileSync(rel);
  const diff = spawnSync('git', ['-c','core.autocrlf=false','diff','--no-index','--no-ext-diff','--text','--unified=0','--',step.beforePath,rel], {encoding:'utf8'});
  if (![0,1].includes(diff.status)) throw Error('Read-only diff failed');
  const hunks = []; let h;
  for (const line of diff.stdout.split('\n')) {
    const m = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/.exec(line);
    if (m) { h={oldStart:+m[1],oldCount:m[2] === undefined ? 1 : +m[2], newLines:[]}; hunks.push(h); }
    else if (h && line.startsWith('+')) h.newLines.push(line.slice(1)+'\n');
  }
  if (hunks.length > 12) throw Error('Too many candidate hunks');
  const lines = before.toString('utf8').match(/[^\n]*\n|[^\n]+$/g) || [];
  function reconstruct(mask) {
    const result=[];let cursor=0;
    for(let i=0;i<hunks.length;i++) {
      const q=hunks[i], pos=q.oldCount===0?q.oldStart:q.oldStart-1;
      if(mask & (1<<i)) { result.push(...lines.slice(cursor,pos),...q.newLines);cursor=pos+q.oldCount; }
    }
    result.push(...lines.slice(cursor));return Buffer.from(result.join(''),'utf8');
  }
  if (sha(reconstruct((1<<hunks.length)-1)) !== sha(current)) throw Error('Hunk reconstruction does not match current bytes');
  const matches=[];
  for(let mask=0;mask<(1<<hunks.length);mask++) if(sha(reconstruct(mask))===step.afterSha256) matches.push(mask);
  if(matches.length!==1) throw Error('Expected exactly one exact historical SHA match, got '+matches.length);
  const mask=matches[0];
  save(step,reconstruct(mask),'Enumerate subsets of exact zero-context hunks between immutable original and current file; accept only the unique historical after-SHA match',
    {currentSourceSha256:sha(current), candidateHunks:hunks.length, matchedHunkIndices:hunks.flatMap((_,i)=>(mask&(1<<i))?[i]:[]), matchedBeforeLines:hunks.flatMap((q,i)=>(mask&(1<<i))?[q.oldStart]:[])});
}
fs.writeFileSync(out+'/recovered-pass12.json',JSON.stringify({sourceEdits:false,gitMutations:false,evidence},null,2)+'\n');
console.log(JSON.stringify(evidence.map(({path,afterBytes,afterSha256,recoveredPath,matchedBeforeLines,replacements})=>({path,afterBytes,afterSha256,recoveredPath,matchedBeforeLines,replacements})),null,2));
