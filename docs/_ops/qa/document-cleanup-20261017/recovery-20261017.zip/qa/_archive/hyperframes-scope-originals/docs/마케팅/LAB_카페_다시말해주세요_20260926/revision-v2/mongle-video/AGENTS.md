# 기존 HyperFrames 영상 작업

공통 역할·설치·비용·권한은 [AI 운영 원칙](../../../../AI_운영원칙.md)을 따른다.

이 프로젝트의 기존 영상을 수정·재렌더할 때 [HyperFrames 0.8.x 기술 참고](../../../HyperFrames_기존영상_참고.md)를 읽는다. 명령·고정 버전·별도 동기화 단계는 이 폴더의 package.json과 README를 먼저 확인한다.
