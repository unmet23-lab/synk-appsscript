# 통합 검증 · 2026-09-29

<a id="sns-close-20261016"></a>
## SNS 최종 점검·종료 · 2026-10-16

- **수정·기록 범위:** 현재 운영 `f1978e99…`에 포함된 SNS 게시 연결/복귀 화면(`public/app.js`), 미디어 capability 주소 로그 가림(`deploy/Caddyfile`)과 관련 시험의 미커밋 원문을 정리한다. 추가 실행 결함은 발견하지 않았고 새 최적화 코드나 재배포는 필요하지 않았다. 기존 SNS 최적화·직접 게시·운영 인수 기록을 함께 보존하며, 오래된 운영 버전/미배포 표현 2곳을 완료 이력과 현재 인수 기록에 맞췄다. 다른 로그인·고객 작업의 변경은 포함하지 않는다.
- **현재 소스 회귀:** Node 24.18의 핵심 SNS 12파일 **405/405**, 연결·SNS 화면 2파일 **115/115**, 기존 로컬 Caddy의 설정·실제 합성 502 로그 가림 **2/2**, 총 **522/522**를 통과했다. 실패·취소·건너뜀0, 시험/제품33파일 전후 SHA 일치, 외부 네트워크 차단이다. 이번 집중 점검 수치를 기존 Windows/Linux 전체1,255개와 합산하지 않는다. [목록·해시·결과](../../../../../.tmp/company-sns-close-20261016/qa/summary.json).
- **운영 재확인(15:24 KST):** manifest 유지·observer 경고0, Instagram/Facebook/YouTube 세 연결 정상·계정 일치·재연결 요구0, 댓글 두 연결의 오류0을 확인했다. Facebook의 최근 한도/과거 이어읽기 `partial`은 당시 진행 상태이며 실패로 바꾸어 해석하지 않는다. 관측 도구는 운영 쓰기·SNS API 호출·비밀값 반환0이다. [운영 읽기](../../../../../.tmp/company-sns-soak-20261015/release-prep/observations/sample-1792131883749.json) · [인증 메타데이터](../../../../../.tmp/company-sns-auth-20261016/live/credential-status-1792131885340.json). 공개 `/api/health`는15:26 KST에 TLS 검증을 유지한 HTTP200·ok/ready였다. [공개 확인](../../../../../.tmp/company-sns-close-20261016/public-health.json).
- **실제 1일 예약:** 10월16일15:00 예약이15:00:15에 1회 시도로 발행됐다. 작업·원장·계정·공급자 결과와 저장된 YouTube API의 비공개 확인이 일치한다. 새 실시간 YouTube 조회나 구독자 알림 전달 여부를 직접 검증한 것은 아니다. 저장 원장 중복 참조0이며 원격 전체 중복 부재를 단정하지 않는다. 18일·22일15시 예약은 비공개·구독자 알림 끔·시도0을 유지한다.
- **남은 일정·재개:** 같은 대화의 `synk-sns-3`은10월18일16시, `synk-sns-7`은10월22일16시에 실제 예약 결과를 확인한다. `synk-sns`는 매일16시10분 인증 유지·자연 갱신을 점검하며 세 일정의 ACTIVE·한국 시간·대상 대화를 확인했다. 로컬 예약 점검에는 PC와 Codex 앱 실행이 필요하다. 확인된 관련 문제는 최소 수정·시험·기존 회사 배포 절차·운영 대조 후 알리며, 정상/동일 비조치 상태는 반복 알리지 않는다. 새 SNS 발송·재전송·삭제·권한 확대·유료 자원/구독은 하지 않는다. 7일 실제 경과와 수개월 인증 유지의 최종 결과는 아직 미확인이다.
- **새 노트북에서 재개:** `unmet23-lab/synk-appsscript`의 최신 `master`를 받은 뒤 `AGENTS.md` → `docs/AI_운영원칙.md` → 이 절과 [현재 운영 인수](CLOUD-OPERATIONS.md#sns-auth-production-20261016)에서 시작한다. 제품 원문과 요약은 SNS 마감 커밋 `b463c323c`에 포함돼 있다. 위 `.tmp/`의 관측 도구·계획·상세 시험 증거는 Git 제외 대상이며, 현재 PC의 Codex 자동화 설정·로컬 서버 접근 자격도 Git clone/pull로 옮겨지지 않는다. 기존 PC 자료를 보존하고 새 환경에서 도구/의존 파일·허용된 서버 접근·예약 실행 위치를 확인한 뒤 읽기 점검부터 재개한다. 기존 세 자동화의 상태를 먼저 확인해 중복 등록을 피하며, 새 PC의 읽기 점검이 성공하기 전에는 후속 점검 이전 완료로 보고하지 않는다. SNS 예약 발행과 자동 토큰 갱신은 운영 서버가 담당하고, 여기의 Codex 일정은 결과 확인·문제 대응용이다. 이 재개 안내에는 자격증명을 넣지 않았으며 운영 계정·기존 예약·자동화 설정은 변경하지 않았다.

<a id="sns-auth-refresh-20261016"></a>
## SNS 장기 인증·자동 토큰 갱신 · 2026-10-16

- **목적·범위:** 사용자 승인에 따라 기존 Instagram·Facebook·YouTube 계정의 장기 인증과 자동 갱신을 검증한다. 신규 구독·서버·권한 추가·공개 게시·댓글 전송 없이 기존 공식 API 연결을 사용하며, 10월22일16시 장기 예약 확인을 유지한다. 실제 수개월 경과와 격리 시계 시험을 구분한다.
- **운영 인증 기준선(11:28 KST):** 세 계정 모두 게시 연결 `connected`, 계정 ID 일치·재연결 요구0. YouTube 정기 점검10:45:02에 발급된 토큰이11:45:01까지 유효하며 refresh token이 저장되어 있다. Instagram은 long-lived Instagram Login으로12월13일20:06 KST까지 유효하다. Facebook은 토큰 만료일이 없는 응답이며 데이터 접근 시각2027년1월13일03:32 KST가 저장돼 있다. 다만 Page 게시·댓글의 필요 권한은 일반 데이터 접근 만료의 예외이므로 이 날짜를 반드시 재연결해야 하는 날로 해석하지 않는다. 실제 토큰 만료·권한 철회는 별도로 적용된다. 비밀값은 반환하지 않고 메타데이터만 읽었다. [기준선](../../../../../.tmp/company-sns-auth-20261016/live/credential-status-1792117735447.json).
- **공급자 조건 대조:** Google 콘솔 `synk-radio24`의 현재 게시 상태는 프로덕션·외부·사용자1/100이며 설정 변경0이다. 현재 앱은 테스트 상태가 아니며, 토큰 발급 당시 설정 이력까지 확인한 것은 아니다. 저장된 refresh token의 장기 유효성은 공급자 응답과 실제 갱신 경과로 확인한다. 시간제 refresh token 응답의 공식 필드는 `refresh_token_expires_in`이다. Instagram 공식 문서는 발급24시간 이상·미만료 long-lived token을 갱신하고 응답의 `expires_in`으로 새 만료 시각을 정하도록 한다. [Google 공식 수명 조건](https://developers.google.com/identity/protocols/oauth2#expiration) · [Google 시간제 접근](https://developers.google.com/identity/protocols/oauth2/web-server#time-based-access) · [Meta 공식 갱신 조건](https://developers.facebook.com/documentation/instagram-platform/reference/refresh_access_token) · [현재 앱 설정 확인](../../../../../.tmp/company-sns-auth-20261016/live/google-audience-current.json).
- **자동 실행 경로:** 활성 direct 연결은 화면 방문·게시 예약 없이 서버의1분 health poll에서 계정별1시간 점검을 거쳐 `credentialsFor`를 호출한다. Instagram은 만료7일 전부터, YouTube는 만료5분 전부터 갱신 대상이다. 창 시작 시각에 별도 작업이 생기는 것은 아니며 다음 정기 점검 또는 실제 작업에서 실행한다. Facebook은 refresh-token grant가 없으므로 만료·권한 철회 때 재연결하는 정책을 유지한다.
- **실제 자연 갱신(11:45 KST):** 배포 전 부모574 서버에서 YouTube 토큰 발급이10:45:02→11:45:32, 만료가11:45:01→12:45:31로 바뀌고11:45:33 공식 계정 조회가 연결 정상으로 끝났다. 계정·기존 동의 시각·scope 수를 유지했으며 강제 갱신·재로그인·관측 도구의 API/DB 쓰기0이다. 이전 access 만료와 새 발급 사이31.353초가 있어 access token의 끊김 없는 유효성을 주장하지 않는다. 유효한 refresh grant가 있으면 예약 가능 상태를 유지하고 실제 발행·health 요청에서 먼저 갱신하는 기존 코드/시험을 확인했으므로 이 간격을 게시 장애로 해석하지 않는다. [실제 갱신 대조](../../../../../.tmp/company-sns-auth-20261016/live/youtube-natural-renewal-v1.json).
- **수정본의 실제 자연 갱신(12:45 KST):** 갱신 보완 b9 운영에서 YouTube 발급 시각이11:45:32→12:45:47, 만료가12:45:31→13:45:46으로 바뀌고12:45:47 계정 조회가 정상 완료됐다. 배포 전후 서버·OAuth 수정본 SHA와 연결·소유자 바인딩·기존 동의 시각·scope 수가 같으며, 12:51:32 최종 f197의 실행6파일 SHA와 세 계정 정상 상태도 확인했다. 강제 갱신·관측 도구의 SNS API/DB 쓰기0이다. access 만료부터 새 발급까지15.035초이며 실제 작업의 선행 갱신과 유효 refresh grant에 의한 예약 가능 상태를 별도로 확인했다. [수정본 실제 갱신](../../../../../.tmp/company-sns-auth-20261016/live/youtube-natural-renewal-after-fix.json) · [최종 코드·계정 메타데이터](../../../../../.tmp/company-sns-auth-20261016/live/credential-status-1792122692753.json).
- **Facebook 데이터 접근 예외:** [Meta 공식 문서](https://developers.facebook.com/documentation/facebook-login/auth-vs-data)의 현재 Page 게시·댓글 권한은 일반 데이터 접근 만료 예외다. 연결 검증·발행·댓글 수집·답장이 `dataAccessExpiresAt` 날짜만으로 막히는10개 하위 사례를 재현한 뒤, 해당 작업의 필요 권한 전체가 예외일 때만 불필요한 차단을 제외했다. 실제 토큰 만료·잘못된 날짜·권한 폐지·계정 일치·페이지 관리 권한 검사는 유지하며 일반 사용자 정보·통계·Instagram으로 예외를 넓히지 않는다. 집중41/41·관련232/232와 독립 코드 검토를 통과했고 `e20c71ff2`로 commit/push했다. 현재 운영 장애나 1월의 실제 권한 유효성을 확인한 것은 아니다. [공급자 조건 기록](../../../../../.tmp/company-sns-auth-20261016/live/provider-auth-documentation.json) · [재현·수정·시험](../../../../../.tmp/company-sns-auth-20261016/facebook-data-access/RESULT.md).
- **수정·검증:** 계정별 동시 갱신3요청을1회로 합치고, 갱신 중 새 로그인·연결 해제·소유자 비활성이 발생하면 오래된 응답을 저장하지 않는다. 실패 후 대기는 일시 오류15분·그 밖의 오류1시간이며 서버 재시작 후에도 유지하고 새 인증 정보에는 이전 대기를 적용하지 않는다. Google 시간제 refresh 만료를 보존하며 잘못된 만료 응답은 거부한다. 댓글 미리보기·건강점검·결과 재확인은 정상 갱신 후 새 토큰으로 읽되 실제 답장 발송은 승인 당시의 연결 조건을 유지한다. 기존 동시 요청·갱신 중 secret 교체·댓글4개 읽기 경로에서 문제를 재현한 뒤 관련84/84, 동결 후보의 Windows 통합1,215/1,215(80파일·실패/skip0·네트워크 차단·원문 변조0)을 통과했다. Instagram52일째 무갱신→53일째 갱신→다음날 무갱신→만료 시 재연결을 주입 시계로 확인했으며 실계정의 수개월 경과를 주장하지 않는다. [재현·수정 결과](../../../../../.tmp/company-sns-auth-20261016/implementation/RESULT.md) · [통합 시험](../../../../../.tmp/company-sns-auth-20261016/qa/result.json).
- **배포 검증:** 부모 `574180783026…`에 이미 포함된 OAuth 공용 변경은 SHA 대조 후 `350b417b8`로 기록하고 그대로 보존했다. 갱신 보완 `4e663d221`의 후보 `b9b1da239177…`는 source1,024·payload594·실행 변경3·시험 변경/추가4·부모 원문1,017개 보존이며, Windows/Linux 각1,215시험과 운영·백업 복원·HA 인수(12:27:53 KST)를 마쳤다. 기존 Meta 게시 원문도 `570e34fb7`로 별도 기록했다. Facebook 후속 `e20c71ff2`의 후보 `f1978e99e62b…`는 부모b9의1,016개 원문을 보존하고 실행4·시험4개만 변경했다. Windows/Linux 각각1,255/1,255·운영 이미지 호환성2/2를 통과했고, 12:51 운영 반영과13:33:16 KST 새 백업 복원·HA 최종 인수를 완료했다. [후속 Windows](../../../../../.tmp/company-sns-page-auth-20261016/qa/result.json) · [후속 Linux](../../../../../.tmp/company-sns-page-auth-20261016/deployment/reviewed-candidate-receipt.json).

- **최종 확인(13:33 KST):** 최종6개 실행 SHA와3계정 연결 정상·재연결 요구0을 다시 확인했다. 양 노드 source1,024개씩 전체 일치·기존 예약3건의 시각/옵션/시도0·댓글2연결·HTTPS/복제/자동 장애 대응 정상이며 최종 observer 경고0이다. 10월22일16시 기존 단발 확인은 유지한다. 실제7일 경과·수개월 연속 인증·이번 판의 강제 장애 시험은 아직 입증하지 않았으며, 공급자의 권한 철회·계정 제한은 재연결이 필요할 수 있다. [최종 인증 메타데이터](../../../../../.tmp/company-sns-auth-20261016/live/credential-status-1792125224394.json) · [최종 읽기](../../../../../.tmp/company-sns-soak-20261015/release-prep/observations/baseline-1792125226925.json) · [운영 인수](CLOUD-OPERATIONS.md#sns-auth-production-20261016).

<a id="sns-facebook-history-20261016"></a>
## Facebook 과거 댓글 이어받기 · 2026-10-16

**10:13 KST 현재 권한으로 Meta API가 반환한 게시물·댓글 범위의 끝 페이지 조회와 저장 대조를 완료했다. 누락·불일치·중복은 없었으며 제품 수정이나 재배포는 하지 않았다.** 운영 릴리스는 `574180783026dd4c21cff594e42a19d7111e7dc51ac8a4911a20149b57fdfc2e`를 유지한다.

- **실제 자동 이어받기:** 10:01 기준의 history 대기는 10:05:35 자동 회차에서 최근 5개·과거 2개 처리 후 해제됐다. 저장 작업 0개·완료 시각 갱신·오류 없음이다. 완료 시각을 보유한 채 다음 순회의 대기가 다시 생기는 것은 정상 동작이며, `partial`의 `recent-post-limit`은 그 회차의 최근 목록 한도를 뜻한다. [운영 진행](../../../../../.tmp/company-sns-fb-history-20261016/live/progress-1792112992384.json).
- **독립 API 대조:** 10:13:37~42 GET 17회 모두 200. 게시물 목록을 5→5→2의 3쪽으로 읽어 총 12개(2026-08-04~10-15 KST)의 마지막 페이지와 각 댓글 목록의 끝을 확인했다. 원댓글 1개·답글 1개의 ID·게시물·부모 관계·작성 시각이 저장 결과와 일치했고, ID 집합 해시 동일·누락 0·불일치 0·저장에만 남은 항목 0이다. 페이지·권한·연결 정보가 같은 것을 조회 전후에 확인했다. DB와 SNS 쓰기 0, 댓글 본문 요청·자격증명/원본 ID 출력 0이다. [API·저장 집합 대조](../../../../../.tmp/company-sns-fb-history-20261016/live/api-history-audit-1792113222754.json).
- **회귀 시험:** 실제와 같은 Facebook user→Page 경로의 모의 응답에서 최근/과거 10+0→5+2→10+0→5+2, 새 Store에서 cursor 재개·오래된 게시물의 다음 댓글 페이지·순회 완료 후 생긴 답글을 확인했다. 예상 14개 ID가 중복 없이 저장됐고 해결 상태·담당자·작성 중 답변을 보존했다. 회귀 1개 추가 후 관련 파일 **46/46 통과**. provider/progress 제품 원문은 그대로이며 시험만 추가했다. [시험 근거](../../../../../.tmp/company-sns-fb-history-20261016/implementation/RESULT.md).
- **최종 운영·범위:** 10:14:35 읽기에서 기존 릴리스·SNS 연결·HTTPS 정상, 예약 3건/발행 4건 유지·경고 0을 확인했다. 이번 대조는 현재 API 접근 범위의 한 시점이며, 삭제·권한상 미노출·순회 도중 변한 모든 댓글을 포함하는 무조건적 전체 이력 보장은 아니다. 신규 게시·답장·권한 확대·구독·서버 증설은 없다. 10월 22일 16:00 KST의 기존 장기 예약 확인 `synk-sns-7`은 활성 상태로 유지한다. [최종 읽기](../../../../../.tmp/company-sns-soak-20261015/release-prep/observations/sample-1792113275690.json).

<a id="sns-health-cadence-20261016"></a>
## SNS 계정 연결 점검 간격·순서 · 2026-10-16

사용자 요청에 따라 계정 연결 점검의 이중 1시간 대기와 앞 계정 편중을 수정했다. 원본 `b3453b3e73f882ff276e7591f8812f746d80fe8d`를 push했고, 부모 `97f0382c…`에 실행 2파일·시험 2파일만 얹은 후보 `574180783026dd4c21cff594e42a19d7111e7dc51ac8a4911a20149b57fdfc2e`를 동결했다. 나머지 1,019파일 보존·삭제 0, source 1,023개·이미지 payload 594개다.

- **간격:** 점검할 대상을 찾는 서버 주기는 1분, 계정별 실제 자동 점검은 최소 1시간으로 유지한다. 게시 실행 15초·수동 점검·기존 요청 예산은 유지한다. 바쁜 작업이나 여러 배치의 대기는 있을 수 있으므로 모든 계정의 60분 정각 실행을 보장하지 않는다.
- **순서·한도:** 현재 연결에서 미점검한 계정과 마지막 시도가 오래된 계정부터 한 회 최대 5시도, 실패도 5시도에 포함한다. 각 실행 직전에 연결·권한·최근 점검을 다시 확인한다. 요청 전 시각을 기록해 취소·재시작 후 짧은 재호출을 막고 기존 정상 확인 결과를 보존한다.
- **불필요한 갱신:** 실제 점검 0건인 회차에는 직원 알림 화면 갱신을 보내지 않는다. 댓글 연결 점검은 기존 오래된 순서·개별 1시간·최대 10개 제한을 그대로 사용한다.
- **시험:** 1.5초 차이로 시작한 두 계정, 7계정 공정성, 실패 시도 한도, 권한·연결 변경, 취소·재시작, 잘못된 시각, 중복 실행의 새 회귀 7개는 변경 전 0/7 → 수정 후 7/7. 관련 시험 220/220, 배포 후보 Windows/Linux 각각 **1,200/1,200**, 이미지 호환성 2/2가 통과했다. 외부 SNS 요청을 막은 시험이며 실제 장기간 경과와 구분한다. [재현·관련 시험](../../../../../.tmp/company-sns-health-20261016/implementation/RESULT.md) · [Windows](../../../../../.tmp/company-sns-health-20261016/qa/result.json) · [Linux·이미지](../../../../../.tmp/company-sns-health-20261016/deployment/reviewed-candidate-receipt.json).
- **운영 반영:** 09:34 KST 새 버전의 실행 상태와 공개 파일 126/126·HTTPS ready를 확인했다. 09:53 새 백업의 격리 복원·계정 9테이블 보존, 10:01:26 HA 인수를 완료했다. A owner epoch7·B 대기·복제 정상·armed=true이며 새 강제 장애 시험은 하지 않았다. [실행 상태](../../../../../.tmp/company-sns-health-20261016/deployment/runtime-live-postcheck-1792110808894.json) · [공개 파일](../../../../../.tmp/company-sns-health-20261016/deployment/public-verification-1792110846880.json) · [격리 복원](../../../../../.tmp/company-sns-health-20261016/rearm/dr/restore-v1.json) · [최종 HA](../../../../../.tmp/company-sns-health-20261016/rearm/arm-postcheck-final-v1.json).
- **검증 경계:** Chrome 화면 제어가 응답하지 않아 이번에는 새 로그인·화면 조작 검증을 하지 않았다. 실행 파일·공개 HTTP·저장된 운영 기록을 대조한 결과다. 시작 전 계정 데이터 보존은 일치했고, 시작 후 로그인 세션 1건은 수가 1→1로 유지되지만 해시가 달라 바이트 동일로 보고하지 않는다. 원키·스키마·다른 토큰/세션 수는 유지됐다.
- **자연 점검 실회차:** 09:45:27 읽기 관측에서 Instagram·YouTube·Facebook의 마지막 자동 시도가 각각 09:44:17.170·17.620·17.843으로 갱신된 것을 확인했다. 직전 08:44 기록에서 약 60분 15초 뒤이며 세 계정 모두 현재 연결 세대 일치·connected·오류 없음이다. 새 앱 시작 후 다시 한 시간을 기다리지 않았고, 검증 도구의 SNS API 강제 호출·운영 쓰기는 0이다. 예약 3건의 옵션·시도 0과 published 4건도 유지됐다. 이 단기 실회차 확인을 7일 연속 운영 검증으로 확대하지 않는다. [배포 직후 기록](../../../../../.tmp/company-sns-health-20261016/primary-sns-after-deploy-1792110970490.json) · [자동 갱신 후 기록](../../../../../.tmp/company-sns-health-20261016/primary-sns-after-deploy-1792111527974.json).
- **최종 읽기:** 10:01:51 KST 두 노드 원문 각각 1,023파일의 해시 일치·제어 상태 안정·HTTPS 200/ready/TLS·경고 0을 확인했다. 현재 SNS 연결 3개 connected·오류 없음, 예약 3개 scheduled·날짜/비공개/알림 끔 동일·시도 0, 기존 published 4개·5분 초과 지연 0·저장된 중복 결과 참조 0이다. Instagram 댓글 수집은 scanned, Facebook은 최근 10개 게시물 한도의 partial·오류 없음이며 전체 과거 댓글 수집 완료는 아니다. 이 도구의 SNS API·운영 쓰기는 0인 시점 관측이다. [최종 기준선](../../../../../.tmp/company-sns-soak-20261015/release-prep/observations/baseline-1792112511095.json).
- **후속:** 기존 비공개 예약 3건(10월 16·18·22일 15:00 KST)과 22일 16:00 결과 확인을 유지한다. 이번 작업에서 새 게시물·답장·예약을 만들지 않았다. 새 구독·유료 AI 호출·서버 증설·권한 확대·Postiz 설치는 없다.

[운영 인수](CLOUD-OPERATIONS.md#sns-health-production-20261016) · [기존 실제 발행·장기 예약 근거](#sns-soak-release-20261015).

<a id="sns-soak-release-20261015"></a>
## SNS 장기 예약·Facebook 답장·YouTube 공개 발행 · 2026-10-15~16

수정 원본 `987596e65f52b592936628c6d9fb0310778195ba`를 push했고, `8684bfc0feaf719f1d94e34a2619909d78614439fc0496fdd64a608e5db8ee42`의 **Windows/Linux 각각 1,190/1,190·이미지 호환성 2/2**를 통과했다. 10파일(실행 5) 변경, 부모 원문 1,013개 보존, source 1,023개·이미지 payload 594개다. 10월 15일 09:54 운영·공개 검증과 11:33 백업/격리 복구·HA 인수를 완료했다. **실제 Facebook 답장·YouTube 공개 발행과 재생은 확인했으며, 7일 실제 경과는 아직 검증 전이다.** 시험에서 발견한 답장 전송 중 안내의 후속 수정 `c993248d78f2f16312d440af64c6b99bd9df96b9`도 10월 16일 운영에 반영했다. 후속 manifest `97f0382c8909bb6266fab00f556b18b465df8e0f353001957ae04fd428914654`는 **Windows/Linux 각각 1,193/1,193·호환성 2/2**, 공개 126/126을 통과했으며 10월 16일 07:29 KST 새 백업·격리 복구·HA 인수까지 완료했다. [최종 Windows](../../../../../.tmp/company-sns-reply-ui-20261015/qa-v2/result.json) · [최종 Linux](../../../../../.tmp/company-sns-reply-ui-20261015/deployment/reviewed-candidate-receipt.json) · [운영 파일 대조](../../../../../.tmp/company-sns-reply-ui-20261015/deployment/public-verification-1792100885174.json) · [첫 수정 원본](../../../../../.tmp/company-sns-soak-release-20261015/source-commit.json).

- **예약 내구성:** 발행 확정과 다음 반복 예약을 한 transaction에 저장하고, 성과 연결 재시도 표시를 비동기 처리 전에 남긴다. 실행기가 5분 넘게 멈추거나 시계가 뒤로 움직이면 과거 backlog 유예를 초기화한다. 실제 SQLite·자식 프로세스 강제 종료/재기동, 28일 모의시간·DB 재열기, 장기 결과 불명 시 재전송 금지, OAuth 만료·갱신 경로를 확인했다. 이는 실제 28일 운영 결과가 아니다. [관련 147/147](../../../../../.tmp/company-sns-soak-20261015/scheduler/verification.json).
- **Facebook 답장:** 운영 원댓글의 `object`가 API에서 생략되어 미리보기가 막히는 현상을 재현했다. 소유 게시물의 원댓글 목록을 최대 4쪽·200개까지 완전히 대조해 정확한 ID·본문·최상위 관계를 확인한다. 명시적 다른 게시물·불완전 목록·중복 ID·숨김·소유권 변경은 계속 차단한다. 답장 결과 대조도 새로 확인한 원댓글 관계를 사용한다. [관련 89/89·실제 원댓글/수집 행 각 1개](../../../../../.tmp/company-sns-soak-20261015/facebook/object-omission-verification.json).
- **댓글 자동 수집:** 전체 실행 대상 점검을 1분으로 바꾸고 계정별 최소 15분 간격·요청 예산을 유지했다. 앞 계정이 1.5초 늦어져 다음 계정이 추가 15분 기다리던 문제를 실제 server 진입점과 모의 Graph로 재현·수정했다. 모의 31분 동안 중간 점검의 추가 수집 요청은 0이며 관련 104/104를 통과했다. [재현·시험](../../../../../.tmp/company-sns-soak-20261015/scheduler/inbox-cadence/verification.json).
- **YouTube 결과 확인:** 제목·본문·공개 범위·아동용 설정 등이 실제 결과와 다르면 대조 횟수가 늘어도 발행 완료로 바꾸지 않는다. 기존 영상 ID로 다시 읽고, 일치하기 전에는 결과 불명으로 유지하며 업로드를 재전송하지 않는다. 화면에 기존 지원 옵션인 구독자 게시 알림 선택도 연결했다. [YouTube 38/38](../../../../../.tmp/company-sns-soak-20261015/youtube/after.tap) · [화면 110/110](../../../../../.tmp/company-sns-soak-20261015/youtube/client.tap).
- **실제 Facebook 왕복:** 시험 원댓글 1개를 작업실에 수집하고, 11:35 작업실에서 답장 버튼을 1회 눌렀다. 원문 화면과 API의 정확한 답글 1개·서버 `sent` 원장 1개·수신함 표시를 대조했다. 자연 수집도 11:33 실행됐지만 시험 댓글의 최초 유입은 09:22 수동 수집이다. 최근 게시물 10개 한도의 부분 수집 상태를 전체 댓글 수집 완료로 해석하지 않는다. [API/원장](../../../../../.tmp/company-sns-soak-20261015/facebook/observation-v2-1792031733491.json) · [공개 화면](../../../../../.tmp/company-sns-soak-20261015/evidence/facebook-reply-public.png).
- **실제 YouTube 공개:** 11:37 예약이 11:37:27 공개 발행됐다. 작업/직접 원장 각 1개·시도 1회, 정확 채널·제목·본문 해시·public·처리 완료·아동용 아님을 API에서 확인했다. [공개 영상](https://www.youtube.com/watch?v=Nq4ek0Cuau4)을 브라우저에서 5.041초 끝까지 재생하고 12:27 작업실에 공개 확인을 기록했다. 기존 로그인 브라우저 재생이며 비로그인 재생 검증은 아니다. 구독자 알림 끔은 요청 snapshot의 증거이며 실제 알림 수신함 전수 확인은 하지 않았다. [API/원장](../../../../../.tmp/company-sns-soak-20261015/youtube/publication-observation-1792032059681.json) · [재생 증거](../../../../../.tmp/company-sns-soak-20261015/evidence/youtube-public-ui.json).
- **실제 장기 예약:** 10월 16·18·22일 각각 15:00 KST에 별도 YouTube 비공개 게시물 3개를 UI에서 승인·예약했다. 11:39 읽기 검증에서 정확한 날짜·시각·계정·비공개·알림 끔·승인 snapshot·실제 미디어 SHA-256/23,499바이트가 일치했다. [예약 ID와 대조](../../../../../.tmp/company-sns-soak-20261015/release-prep/observations/target-discovery-1792031983822.json). **10월 22일 16:00 KST 최종 확인 1회**를 현재 대화의 heartbeat `synk-sns-7`로 등록했다. [대상 계획](../../../../../.tmp/company-sns-soak-20261015/seven-day-plan.json) · [예약 확인](../../../../../.tmp/company-sns-soak-20261015/seven-day-followup.json). 10월 16일 07:30 기준선 읽기에서 3건 모두 예약·옵션 일치·시도 0, 5분 초과 지연 0, 발행 4건을 확인했다. 전체 관측 상태는 Instagram의 마지막 게시 연결 확인이 5,845초 전인 데 따른 `attention`이다(저장된 연결 상태 connected·오류 없음·계정 binding 일치). 이 읽기만으로 현재 Instagram 인증 유효성을 새로 검증한 것은 아니다. [운영 기준선](../../../../../.tmp/company-sns-soak-20261015/release-prep/observations/baseline-1792103407514.json). 데스크톱/로그인 또는 서버 관리 접근이 없으면 확인 범위가 제한될 수 있으며, SSH 불가 시 기존 브라우저의 게시 달력·목록으로 확인하고 접근 권한을 자동 확대하지 않는다. 실제 시간 경과·장기 토큰 갱신·24시간 연속 가용성은 아직 입증하지 않았다. [관측기 검증 19/19](../../../../../.tmp/company-sns-soak-20261015/release-prep/observer-review/verification.json).
- **시험 중 발견한 화면 안내:** 전송 시작 직후 대기 상태를 응답 유실 경고로 표시하던 결함을 재현했다. 전송 중·응답 유실·정확한 기존 시도의 `sent` 확인을 구분하도록 고쳤다. 새 3시험은 수정 전 2실패→수정 후 3통과, 관련 화면/답장 157/157이다. 실제 답장을 다시 보내지 않았다. [재현/수정](../../../../../.tmp/company-sns-soak-20261015/facebook/reply-pending-verification.json).
- **10월 16일 운영 화면:** 새로고침 뒤 재로그인 없이 예약 3건·7일 게시 4건·확인할 발행 문제 0과 시험 Facebook 원댓글·답글 표시를 확인했다. Facebook 자동 수집은 06:46에 최근 게시물 10개·댓글/답글 2개를 요청 예산 13/40으로 읽었다. 수동 수집 버튼은 누르지 않았으며 최근 한도·과거 이어받기 대기의 부분 수집이다. 관측 콘솔 오류/경고 0, 추가 SNS 쓰기 0이다. [화면 검증](../../../../../.tmp/company-sns-reply-ui-20261015/ui/production-browser-verification.json) · [운영 화면](../../../../../.tmp/company-sns-reply-ui-20261015/ui/production-overview.png).
- **배포 전후 선택 기록 보존:** SHA-256으로 대조한 사전 백업과 현재 SQLite에서 5대상·11행을 읽었다. 장기 예약의 원고/작업 6행·공개 YouTube 원고/작업/직접 원장 3행·Facebook 전송 원장 1행은 완전히 같다. 원댓글 1행은 `externalReplyEvidence`·`lastCollectedAt`만 달라졌으며 나머지 필드와 본문·식별자·답장 연결은 같다. 두 필드는 실제 수집 코드가 갱신하는 정보다. 검사기의 허용 목록에 `lastCollectedAt`이 없어 원문은 `held`로 보존하며 **11행 전체 동일 또는 검사기 통과로 보고하지 않는다.** 최초 조회의 백업 폴더 시각 추정 오류는 원본 manifest의 `dataBackupName`을 사용하도록 고쳤고 관련 13/13을 확인한 뒤 보존 읽기만 1회 재실행했다. 이 대조의 SNS API·운영 쓰기는 0이며 현재 SNS 공개 상태를 새로 읽은 결과는 아니다. [기록 대조](../../../../../.tmp/company-sns-reply-ui-20261015/qa/sns-row-preservation-1792103671177.json).

<a id="sns-followup-release-20261015"></a>
## SNS 예약 몰림·게시 대조·댓글 상태·유입 검증 · 2026-10-15 운영 검증

후보 `31db29ba898ff…`의 운영 후검사·실제 화면·08:10:10 KST 복원·HA 인수를 완료했다. [이번 운영 인수와 보존 한계](CLOUD-OPERATIONS.md#sns-followup-production-20261015).

- **회귀·공개 확인:** 78파일의 시험을 Windows/Linux 각각 **1,162/1,162**, 이미지 호환성 **2/2**로 통과했다(실패·취소·건너뜀 0, 환경별 수치 합산 안 함). Linux 첫 SSH 결과 전달만 실패했고 같은 원격 작업의 완료 원문을 읽기로 회수했으며 재실행하지 않았다. 공개 **126/126**, 기존 로그인·자동 발행 3계정·댓글 연결 2계정·예약 몰림 상세·콘솔 오류/경고 0을 확인했다. [Windows](../../../../../.tmp/company-sns-followup-20261015/qa/result.json) · [Linux](../../../../../.tmp/company-sns-followup-20261015/deployment/reviewed-candidate-receipt.json) · [회수 근거](../../../../../.tmp/company-sns-followup-20261015/deployment/rootqa/linux-1792016888115/collection-provenance.json) · [운영 화면](../../../../../.tmp/company-sns-followup-20261015/qa/production-browser-verification.json) · [공개 대조](../../../../../.tmp/company-sns-followup-20261015/deployment/public-verification-1792017959387.json).
- **예약 몰림:** 합성 원고 221개·작업 5,000개·예약 3,333개에서 대기 화면 응답 **1,022,377→189,031바이트(81.51% 감소)**, 전체 집계 유지·상세 50→100건·중복 0·revision에 묶인 이어 읽기·모바일 가로 넘침 0을 확인했다. 전체 승인 일정의 서버 계산은 유지하면서 전송·표시량을 줄인 결과다. 운영 지연 시간·요금 절감률이나 운영 5,000건 실험은 아니다. [측정](../../../../../.tmp/company-sns-followup-20261015/qa/capacity-http-measurement.json) · [브라우저](../../../../../.tmp/company-sns-followup-20261015/qa/browser-verification.json).
- **Meta 대조:** 최종 관련 시험 **85/85**·회귀 재현 **5/5**, 실계정 읽기 **9GET 모두 200**으로 계정·권한·다음 쪽 cursor·시간창 계약을 확인했다. 50건×최대 10쪽·500건, 자동 확인 3회의 경계를 유지하며 한도·복수 후보·불완전 조회를 완료로 확정하지 않는다. 새 실게시·결과불명 업로드 실험은 하지 않았다. [시험](../../../../../.tmp/company-sns-followup-20261015/meta-reconcile/verification.json) · [실계정 읽기](../../../../../.tmp/company-sns-followup-20261015/meta-reconcile/live-read-contract-1792016545214.json).
- **Facebook 댓글:** 07:14:15 KST **15GET 모두 200**, API-visible 게시 12개·반환 댓글 0, 페이지 identity·관리 권한을 확인했다. 독립 10조건×4회 비교에서 기존 요청 순서·수집 행·기존 상태/집계를 유지했다. 운영 후 읽기의 마지막 수집(07:44:20 KST)은 최근 10개 한도와 과거 조회 진행 중을 `recent-post-limit`·`history-pending`으로 각각 설명한다. 과거 한 바퀴 완료 시각은 최신 전체 수집 완료를 뜻하지 않으며, 접근 불가·비공개·삭제 댓글까지 없다고 주장하지 않는다. [실계정 조회](../../../../../.tmp/company-sns-followup-20261015/facebook-observation-1792016059872.json) · [불변 비교](../../../../../.tmp/company-sns-followup-20261015/inbox-independent-review-v1.json) · [운영 관측](../../../../../.tmp/company-sns-followup-20261015/runtime-observation-1792018075181.json).
- **유입 프록시:** desktop/controller의 두 실제 network peer에 같은 위조 XFF를 넣어 edge가 서로 다른 접속을 확인하는지 검증했다. 정확한 Caddy peer 신뢰·`remote_host` 덮어쓰기를 유지하며 실행 설정 변경·새 자원·원시 주소 영구 기록은 0이다. 동일 공인 IP의 서로 다른 사람을 구별하는 시험은 아니다. [두 접속 검증](../../../../../.tmp/company-sns-followup-20261015/proxy-peer-verification-1792016175044.json).
- **인수 범위:** 최종 원문 115개와 DR 원본 누락·변조 방지 **18/18**을 확인했다. `postStartAllSessionAndTokenRowsExact=false`, 설명되지 않은 활성 세션 누락 0, 새 복원 사본의 만료 토큰 삭제 0, `currentReleaseOutageTested=false`다. 이번 작업의 추가 게시·답장·삭제·신규 구독·서버 증설·유료 API 추가는 0이다. [보존 검토](../../../../../.tmp/company-sns-followup-20261015/qa/preservation-review-v2.json) · [DR 근거 시험](../../../../../.tmp/company-sns-followup-20261015/final-dr-unit-v1/result.json) · [최종 결과](../../../../../.tmp/company-sns-followup-20261015/final-release.json).

<a id="sns-query-release-20261015"></a>
## SNS 첫 진입·대량 조회 · 2026-10-15 운영 검증

후보 `4abedf7b9d112…`를 운영에 반영했다. [현재 운영·복원·HA 결과](CLOUD-OPERATIONS.md#sns-query-production-20261015).

- **관련 회귀:** 고객 관리·알림·SNS를 포함한 78파일의 시험을 Windows와 격리 Linux에서 각각 **1,115/1,115**, Linux 이미지 호환성 **2/2**로 통과했다. 실패·취소·건너뜀 0이며 두 환경의 수치를 합산하지 않는다. [Windows](../../../../../.tmp/company-sns-query-20261015/qa/result.json) · [Linux·호환성](../../../../../.tmp/company-sns-query-20261015/deployment/reviewed-candidate-receipt.json).
- **첫 진입·요청 순서:** 로딩·실제 실패·명시적 재시도·중복 요청·화면 이탈, 페이지 밖 원고 상세, 늦은 상세 응답의 다른 원고/새 버전 덮어쓰기 방지를 확인했다. [상세 응답 재현 재검사](../../../../../.tmp/company-sns-query-20261015/qa/readonly-detail-race-recheck-v2.json).
- **합성 대량 자료의 실제 브라우저:** 원고 221개·작업 5,000개에서 개요 응답이 **6,711,765→189,298바이트(97.2% 감소)**였다. 이는 로컬 합성 자료의 응답 크기 비교이며 운영 응답 시간·비용 절감률은 아니다. 일간 일정 143건을 50→100→143건으로 읽고 페이지 밖 원고와 전체 작업 25건을 확인했다. 예약 몰림 3,333건의 전체 집계를 유지하면서 초기 작업/몰림 목록을 각각 50건으로 표시했고 더 보기로 몰림 목록 100건을 확인했다. 해당 대기 화면 DOM은 25,020→2,041개였으며 모바일 가로 넘침·관측 콘솔 오류/경고는 없었다. [합성 브라우저 근거](../../../../../.tmp/company-sns-query-20261015/qa/browser-verification.json).
- **운영 확인:** 공개 파일 126/126 일치, 기존 로그인에서 첫 로딩→성공, 날짜별 일정 버튼→기존 게시 작업 3/3건, 자동 발행 3계정·공식 댓글 연결 2계정을 확인했다. 새 게시·댓글 답장·삭제나 추가 인증을 실행하지 않았다. 운영에 5,000개 작업을 넣어 시험한 결과는 아니다. [공개 대조](../../../../../.tmp/company-sns-query-20261015/deployment/public-verification-1792012433950.json) · [운영 브라우저](../../../../../.tmp/company-sns-query-20261015/qa/production-browser-verification.json).

<a id="sns-p6-release-20261015"></a>
## 이전 SNS 공용 3차 합본 · 2026-10-15 운영·HA 검증 완료

공용 SNS 화면과 직접 게시를 포함한 manifest `3e30afd0c33d6c256f8e42f8bc8d80fa23c1d5ff90b80d9534a9d7f9683731b9`를 운영에 반영했다. 이전 461a… 릴리스와 아래 실제 업로드 시험 기록은 이력으로 보존한다. [당시 운영 인수](CLOUD-OPERATIONS.md#sns-p6-production-20261015).

- **후보 범위:** 원문 1,019개·이미지 목록 593개, 변경·추가 51개(실행 24)·부모 968개 보존·삭제 0. 공용 입력 76개가 후보와 일치했고 SNS28파일의 커밋·push를 확인했다. 비SNS 신규 기능은 포함하지 않았다. [후보 검증](../../../../../.tmp/company-sns-p6-release-20261015/candidate-validation.json) · [원문 대조](../../../../../.tmp/company-sns-p6-release-20261015/source-provenance.json).
- **관련 회귀:** 실제 격리 Linux 이미지에서 앱 1,089/1,089·호환성 2/2, 별도 HA Node119·Python35·배포 절차 126을 통과했다. 실패·취소·건너뜀 0이며 운영 자료 마운트·운영 서비스 조작 없이 검증했다. 이전 705/950 수치와 합산하지 않는다. [Linux 인수](../../../../../.tmp/company-sns-p6-release-20261015/deployment/reviewed-candidate-receipt.json).
- **배포와 보존:** 사전 백업 뒤 발행 색인 3개만 먼저 추가했다. 배포v1은 시간 초과 후 기동 전 복구, 새 기준선의 v2는 04:44 KST 후검사 통과. 기동 전 전체 논리DB·파일 일치와 기동 후 스키마·키 보존을 확인했다. 기동 후 identity 세션 1→1행의 해시는 달라 원행·원인은 미확정이지만 실제 브라우저의 기존 로그인은 유지됐다. [v2 후검사](../../../../../.tmp/company-sns-p6-release-20261015/deployment/runtime-live-v2-postcheck-1792007057841.json).
- **운영 화면·공개 결과:** 공개 126/126파일 일치·health200/ready·익명 SNS401을 확인했다. 로그인한 화면에서 기존 게시물 3개·자동 게시 3계정·댓글 수집 2계정을 확인했다. 이번 배포의 추가 게시·고객 답장·삭제 0이며 기존 공개 2/비공개 1 시험 결과를 유지한다. [공개 대조](../../../../../.tmp/company-sns-p6-release-20261015/deployment/public-live-v2-postcheck-1792007068638.json) · [계정](../../../../../.tmp/company-sns-p6-release-20261015/evidence/final-connections.jpg) · [원장](../../../../../.tmp/company-sns-p6-release-20261015/evidence/postdeploy-calendar.jpg) · [댓글](../../../../../.tmp/company-sns-p6-release-20261015/evidence/postdeploy-comments.jpg).
- **복원·최종 HA:** 공간 관문에서 멈춘 복원v1을 보존하고 기존 디스크의 로그 압축·검증 캐시 정리 뒤 복원v2를 통과했다. 비토큰 계정 8테이블·활성 세션/토큰·키는 보존됐고 만료 pulse-session 토큰 1개만 격리 복사본에서 기동 전 정리했다(3→2, 전체 계정행 무변경은 아님). 05:20:21 KST armed=true·A epoch7·B 정상 대기·복제 healthy·HTTPS200/ready/TLS를 확인했다. 정상 동작 18표본·3리전·1,100,542ms에서 오류 0이며 실제 새 장애 전환 시험이나 격리 환경의 실사용자 로그인 시험은 아니다. [복원](../../../../../.tmp/company-sns-p6-release-20261015/rearm/dr/restore-v2.json) · [최종 HA](../../../../../.tmp/company-sns-p6-release-20261015/rearm/arm-postcheck-final-v1.json) · [정상 관측](../../../../../.tmp/company-sns-p6-release-20261015/rearm/natural-final-v1.json).
- **당시 남은 P2의 후속 처리:** 조회 전 오류 문구 표시는 [첫 진입·대량 조회 릴리스](#sns-query-release-20261015)에서 수정하고 운영 첫 진입의 로딩→성공을 확인했다. 앞선 운영 요청의 실제 실패 원인을 새로 확정한 것은 아니다.

<a id="sns-direct-publishing-20261014"></a>
## 이전 Postiz 없는 직접 게시 릴리스 · 2026-10-14 운영 반영·최종 인수 완료

[구현과 지원 범위](WORKSPACE.md#sns-direct-publishing-20261014)는 공용 원본과 **2026-10-14 19:06 KST 운영 서버에 반영했다.** 공개 파일·프록시·계정 상태 검증을 통과했다. 이후 사용자 승인으로 세 플랫폼 앱 정보를 저장했고 **10-15 KST 기준 Instagram `@yuhobuilds`·YouTube 유호빌드(`@yuhobuilds`)·Facebook SYNK(`@synkworld`)의 실제 OAuth·게시 권한 확인·자동 게시 활성화를 완료했다.** Facebook의 기존 페이지 접근 오류는 승인받은 `business_management` 저장 뒤 페이지 목록·게시 작업 권한·실제 콜백을 확인해 해소했다. 운영 개요의 자동 발행3계정·연결별 대기 일정0을 확인했다. Instagram과 Facebook 댓글 연결 점검은 정상이고 Facebook 정기 수집의 실제 갱신도 확인했다. **10-15 예약 시험3건이 실제 업로드에 성공했다(Instagram·Facebook 공개2건, YouTube 비공개1건).** 실화면·YouTube 끝까지 재생을 확인했으며 중복·고객 댓글 작성/답장·삭제0이다. Facebook 과거 조회 한 바퀴는 완료됐으나 화면은 일부수집 상태다. 10-14 새 버전 백업·격리 복원 뒤 19:27 KST HA `armed=true`의 최종 운영 인수를 완료했다. Postiz 구독·설치·새 VM·유료 API 호출은 없으며 로컬 LLM PC를 요구하지 않는다. [현재 운영 인수 상태](CLOUD-OPERATIONS.md#sns-query-production-20261015).

- **배포한 최종 후보:** 이전 운영 부모 `7aeace53b532…` 위에 직접 게시 변경만 합친 manifest `461a38789e56f185bc4f2f1eb47c23a45365a5d73b0bef4bad3d55d45c0a5fca`를 고정했다. 원문1,017개·이미지 목록593개, 부모 대비 변경·추가29개(실행13·시험16), 부모 원문988개 보존·삭제0이다. 직접 게시와 무관한 공용 작업본의 화면 수정은 제외했다. [후보와 원문 대조](../../../../../.tmp/social-direct-release-20261014/candidate-validation.json).
- **최종 앱·고객·알림 회귀:** 후보 자체의 관련72파일을 Windows Node24.18.0에서 **950/950**, 동일 후보의 Linux Node24.21.0 이미지 `sha256:5b9d8c642ec0ba916e08f90dd1336a818cb89bbb124875d0e43f9f117a5ae55d`에서 **950/950 및 이미지 호환성2/2**로 검증했다. 실패·취소·건너뜀0이며 직접 게시·Meta/OAuth·서버 인증/예약·고객11판·알림 회귀를 포함한다. 외부 통신을 차단했고 운영 자료를 마운트하거나 운영 서비스를 변경하지 않았다. 이미지593파일의 SHA도 모두 일치했다. 앞선 개별 시험이나 두 실행 환경의 수치를 합산하지 않는다. [Windows 결과](../../../../../.tmp/social-direct-release-20261014/qa/result.json) · [Linux 인수](../../../../../.tmp/social-direct-release-20261014/deployment/reviewed-candidate-receipt.json) · [Linux 격리·호환성 원문](../../../../../.tmp/social-direct-release-20261014/deployment/rootqa/linux-1791971354469/result.json).
- **HA·기존 배포 절차 회귀:** 별도 Linux 격리 환경에서 Node119·Python35·기존 배포 절차126개가 모두 통과했고 건너뜀0이다. 외부 통신과 운영 경로 접근을 차단했으며 운영 쓰기0·실제 HA 재활성화 실행0이다. 이는 배포 전 절차 검증이며 새 버전의 운영 전환이나 HA 인수 결과가 아니다. [HA Linux 결과](../../../../../.tmp/social-direct-release-20261014/rearm/linux-qa-result-v1.json).
- **댓글 보존·실제 회귀 보완:** HTTP/SQLite와 합성 Meta 응답으로 기존 수동 댓글 연결에 게시 권한을 추가하는 흐름을 검증했다. 댓글 권한까지 서버에서 확인한 같은 계정만 연결을 교체하며, 기존 활성 수집·댓글·답장 원장을 보존하고 재수집 중복을 막는다. 부분 동의·다른 계정·인증 도중 설정 변경 시 기존 인증/연결을 덮어쓰지 않고, 비활성 수집은 그대로 둔다. 댓글 보존 시험은 보완 전4개 실패를 재현한 뒤 수정했고 최종950개에 포함했다. 별도로 전용 미디어 처리의 불필요한 비동기 대기가 고객 로그아웃의 종료 중 요청을503으로 바꾸는 회귀를 수정했다. 부모에서도 실패한 SNS 주기 시험과 새 직접 게시 설정에 맞지 않는 기대값은 실제 계약에 맞춰 교정했으며 공용 원본의 해당2파일도13/13 통과했다. [수정 전 댓글 회귀](../../../../../.tmp/social-direct-release-20261014/attempt-2/qa/comment-preservation-before.tap) · [보완 후 댓글 회귀](../../../../../.tmp/social-direct-release-20261014/attempt-2/qa/comment-preservation-final.tap) · [최초 통합 실패 기록](../../../../../.tmp/social-direct-release-20261014/attempt-1/qa/result.json) · [공용 원본 시험](../../../../../.tmp/social-direct-release-20261014/qa/canonical-scheduler-result.json).
- **초기 개발 단계 기능·통합 시험 265개:** 당시 묶음 최초 실행은 263/265였고, YouTube 재예약 보완 과정에서 생긴 중첩 SQLite 트랜잭션 오류 2건을 수정했다. 영향을 받는 어댑터·실제 HTTP/SQLite 통합 33/33 재실행으로 해당 실패를 해소했다. 서버 인증·권한·예약·설정 회귀는 55/55(위 265개와 용량 시험 8개 중복), Caddy 시험은 2/2 통과했다. 아래 원본 SHA는 초기 개발 단계의 기록이며 위 최종 후보와 구분한다. [초기 집계와 원본 SHA](../../../../../.tmp/social-direct-20261014/validation.json), [최초 묶음](../../../../../.tmp/social-direct-20261014/final-targeted.tap), [수정 후 33개](../../../../../.tmp/social-direct-20261014/youtube-final.tap), [서버 회귀](../../../../../.tmp/social-direct-20261014/regression.tap).
- **실제 로컬 흐름:** 임시 SQLite와 로컬 HTTP를 사용해 계정별 자동 게시 켜기 → 작성 → 승인 → 예약 실행 → 결과 확인을 검증했다. FFmpeg로 만든 재생 가능한 합성 JPEG·MP4를 실제 파일 규격 검사와 비공개 미디어 resolver에 통과시켰다. SNS API만 mock이다. Instagram 처리 중 재개·전용 파일 주소 접근, 긴급 중단 뒤 접근 차단, Facebook 응답 유실 시 중복 전송 금지, YouTube 명시 재예약을 확인했다.
- **권한·보존:** OAuth 목적·세션·계정 연결 세대·실제 승인 scope/소유 계정을 확인한다. 댓글 읽기 증명으로 게시 권한을 만들지 않는다. 같은 SNS 계정 중복 연결, 승인 뒤 대상/원문/파일 변경, 권한 철회, 동시에 실행된 작업을 차단한다. YouTube 만료 인증의 갱신 경로와 Shorts 3분·정사각/세로 조건도 검사한다. 이전 Postiz 접수는 조회 경로로만 이어간다. 새 원장·연결·토큰 해시와 암호화 인증의 백업 복원 시험 2개를 포함한다.
- **화면:** 독립 포트의 회사 앱과 Chromium에서 1440px·390px, 계정별 연결/해제·점검, OAuth 뒤 계정 관리 복귀, YouTube 공개 범위·아동용 필수 선택, 열람자 권한 등 21/21을 확인했다. 가로 넘침·브라우저 오류·외부 요청 0, 시험 서버·DB 정리 완료. [브라우저 결과](../../../../../.tmp/social-direct-20261014/ui/report.json), [PC 연결 설정](../../../../../.tmp/social-direct-20261014/ui/direct-settings-desktop.png), [모바일 YouTube 연결](../../../../../.tmp/social-direct-20261014/ui/account-youtube-mobile.png). 실제 휴대폰·운영 로그인 화면 시험은 아니다.
- **전용 미디어 주소 보호:** 공식 Caddy 2.11.7 Windows 임시 실행 파일의 SHA-256을 릴리스 digest와 대조했다. 배포 Caddyfile의 `adapt` 성공과 독립 로컬 프록시의 실제 502 오류 로그에서 합성 토큰이 `REDACTED`로 가려짐을 확인했다. 최종 후보의 Caddy 설정·시험 파일이 직전2/2 통과 회차와 바이트 단위로 같음을 연결했다. 이 격리 시험에서 서비스 설치·운영 설정 변경은 없다. **19:08 KST 운영 Caddy의 새 설정 SHA와 실제 runtime 필터 적용도 확인했다.** [초기 프록시 시험](../../../../../.tmp/social-direct-20261014/caddy/caddy-tests.tap) · [최종 후보와 프록시 검증 연결](../../../../../.tmp/social-direct-release-20261014/qa/caddy-binding.json) · [운영 프록시·공개 검사](../../../../../.tmp/social-direct-release-20261014/ops/direct-public-check-1791972500564.json).
- **운영 반영·보존 범위:** 19:06 KST 양노드 새 manifest·A epoch7 단일 writer·B 대기·배포 후검사 통과, 공개126/126파일 SHA와 health200/ready·익명 SNS401을 확인했다. 19:08 KST에는 변경된 `app.js`·`social-workspace.js` 공개 바이트와 유효하지 않은 전용 미디어 주소404까지 대조했다. writer 정지 중 수집한 전체 논리 DB·DB 외 파일은 정확히 보존됐고 기동 후 스키마·원래 키도 같다. 기동 후 `synk_identity_sessions`는1→1행이면서 집계 해시가 달랐다. 19:18 KST 추가 진단에서 18:53 KST 사전 온라인 백업과 현재의 기본키 집합 일치·생성0·삭제0·공통1행 복호화 성공을 확인했다. 바뀐 평문 필드는 `accessToken`·`expiresAt`·`refreshToken`뿐이며 사용자·세션·identity 연결 값은 같았다. 이 비교에서 세션 삭제는 발견되지 않았으나, 온라인 백업의 암호문 집계가 정지 CAPTURE와 달라 CAPTURE 원행 보존·실제 로그인 연속성·변경 원인은 확정하지 않는다. 새 버전 백업·격리 복원과 19:27 KST HA `armed=true`의 최종 인수를 완료했으며 상세 범위는 아래 기록을 따른다. [운영 후검사](../../../../../.tmp/social-direct-release-20261014/deployment/runtime-live-postcheck-1791972375411.json) · [공개126파일](../../../../../.tmp/social-direct-release-20261014/deployment/public-verification-1791972382515.json) · [세션 추가 진단](../../../../../.tmp/social-direct-release-20261014/ops/identity-session-backup-comparison-1791973082330.json) · [새 버전 백업 완료](../../../../../.tmp/social-direct-release-20261014/rearm/dr/backup-status-1791972975535.json).
- **추가 인증 전 운영 계정 읽기 검증:** 19:09 KST 전체 등록 계정34개를 읽었고, 이전 기준선이 있는 Instagram·Facebook·YouTube26개에서는 추가·삭제·계정 식별 변경·신규 인증·기존 인증 유실0이었다. 기존 Instagram 댓글 연결1개는 활성·현재 연결 세대 일치·`canSync=true`이며, 당시 새 OAuth 성공 기록0·직접 게시 활성0·정확한 `socialPublishJobs`0개였다. 세 플랫폼의 OAuth 앱 설정도 당시 모두 미등록이었다. 이 조회는 아래 실제 계정 연결을 진행하기 전의 보존 기준선이다. 조회는 읽기 전용 SQLite로 수행했고 SNS 외부 호출·연결/활성화 실행0, 토큰·계정 비공개 내용 출력0이다. 이전 증거에 전체 자격증명 지문이 없어 자격증명 바이트의 완전 보존은 별도 입증으로 주장하지 않는다. [계정 요약](../../../../../.tmp/social-direct-release-20261014/ops/postdeploy-connection-inventory-1791972568030.json) · [읽기 검증 증거](../../../../../.tmp/social-direct-release-20261014/ops/postdeploy-connection-proof-1791972568030.json).

- **실제 앱 설정·계정 연결(10-15 후속 검증):** 기존 Google 데스크톱 클라이언트를 보존하고 새 웹 클라이언트 `SYNK Workspace SNS`를 생성해 SYNK에 저장했다. Google 앱의 게시 상태는 Production이며 YouTube 유호빌드(`@yuhobuilds`)를 선택해 실제 OAuth 서버 저장·게시 권한 검증·자동 게시 활성화를 완료했고 대기 일정0을 확인했다. [YouTube 연결·활성 화면](../../../../../.tmp/social-direct-release-20261014/oauth-setup/youtube-connected-enabled.jpg). Instagram 콜백을 추가하고 기존 DM 콜백을 보존했으며, Facebook 콜백도 저장 후 다시 읽어 확인했다. 세 플랫폼 앱 정보는 모두 SYNK에 암호화 저장했다. 사용자가 Instagram `@yuhobuilds`의 기본 계정·게시·댓글3권한을 허용한 뒤 OAuth 서버 성공, 댓글 연결의 실제 조회 점검, 자동 게시 활성화를 완료했다. 운영 화면에서 자동 발행 가능·게시 연결 확인·공식 댓글 연결 확인·대기 일정0을 확인했다. Facebook은 사용자 승인으로 `PAGES_API` 이용 사례와 `pages_manage_posts`·`pages_read_engagement`·`pages_show_list`를 준비해 첫 scope 오류를 보완했다. 10-14 콜백의 `META_PAGE_ACCESS_REQUIRED` 발생 뒤 SYNK 선택·공개 페이지 ID 일치와 포트폴리오 소유·사용자 전체 액세스를 확인했다. 21:51 KST 기존 대상 채널의 `externalId`·`connectionVersion`만1회 보정하고 감사 기록1개를 추가했으며, 이 보정의 자격증명·토큰 쓰기·서버 재시작은0이고 운영 후검사를 통과했다. 당시 동일3scope의 공식 `GET /me/accounts`는 LAB3개만 반환했고 다음 페이지가 없었다. **10-15 KST 사용자 명시 승인 후 SYNK Guide의 `business_management`를 `synk.mn` 포트폴리오(`1057004986835568`)1개에 저장하고 기존 페이지4개를 유지했다.** 공식 Graph Explorer의 `GET /me/accounts?fields=id,name,tasks` 결과4개에 SYNK(`1140051542527584`)가 포함됐고 `MANAGE`·`CREATE_CONTENT`를 확인했다. 이어 운영 SYNK의 Facebook OAuth 콜백 성공·인증 저장을 확인하고 대기 일정0에서 「권한 확인 후 자동 게시 켜기」를 실행했다. 최종 Facebook 카드의 자동 발행 가능·발행 연결·연결 확인과 대기0, 운영 개요의 자동 발행3계정을 확인했다. **Facebook 댓글2권한 추가·계정 동의도 완료했고 기존4페이지 선택을 유지한 채 SYNK만 수집을 켰다.** 첫03:33 수집은10게시물·0댓글·일부수집·과거 이어받기 대기였다. 연결 점검과 게시 연결 끄기/켜기 재검증은 정상이다. 03:50 KST 브라우저 새로고침에서 수동 재수집 없이 정기 수집의 갱신을 확인했다. 이번 조회6게시물·0댓글(최근5·과거1), 과거 조회 한 바퀴 완료·일부수집 상태이며 모든 과거 댓글을 수집했다는 뜻은 아니다. 신규 구독·서버 비용0이며 10-15 재배포·서버 재시작·키 재설정은 없었다. 앱 심사 완료를 주장하지 않는다. [Facebook 댓글 수집 활성](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-comments-enabled-20261015.jpg) · [게시·댓글 연결 정상](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-publishing-and-comments-connected-20261015.jpg) · [정기 수집 갱신](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-comments-auto-synced-20261015.jpg). [비즈니스 권한 저장](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-business-grant-saved-20261015.jpg) · [Facebook 연결·활성 화면](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-connected-enabled-20261015.jpg) · [공식 페이지 ID 보정 결과](../../../../../.tmp/social-direct-release-20261014/ops/facebook-page-id-apply-result-v1.json) · [이전 콜백 오류](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-callback-page-access-required.jpg) · [진척 기록](../../../../../.tmp/social-direct-release-20261014/oauth-setup/progress-v1.json) · [Instagram 연결·활성 화면](../../../../../.tmp/social-direct-release-20261014/oauth-setup/instagram-connected-enabled.jpg).
- **실제 예약·업로드 시험(2026-10-15 KST):** 승인된 자체 텍스트·도형 테스트 카드와5초 무음 영상을 사용했다. Instagram `@yuhobuilds`는03:43 예약→03:43 실제 게시, [게시물](https://www.instagram.com/p/DefDdOEgcHx/)의 이미지·문구를 확인하고03:45 SYNK 공개 확인을 기록했다. Facebook `@synkworld`는03:46 예약→03:46 실제 게시, [게시물](https://www.facebook.com/122136096939343429/posts/122136098109343429)의 SYNK·synkworld 대상과 전체 공개·이미지·문구를 확인해03:47 공개 확인을 기록했다. YouTube `@yuhobuilds`는03:40 예약→03:40 [비공개 동영상](https://www.youtube.com/watch?v=m-1mBAmjdeI) 업로드,03:44 결과 조회에서 처리 완료·게시됨을 확인했다. 약03:46 본인 채널 로그인에서 비공개 표시와5초 끝까지 재생을 확인했으며 비공개이므로 SYNK 공개 확인은 기록하지 않았다. **3업로드 성공·공개2·비공개1·중복0**, 고객 댓글 작성/답장·삭제0·추가 비용/유료 자원0이다. [시험 결과 JSON](../../../../../.tmp/social-direct-release-20261014/upload-test-20261015/actual-publish-results.json) · [Instagram 실화면](../../../../../.tmp/social-direct-release-20261014/oauth-setup/instagram-test-published-20261015.jpg) · [Facebook 실화면](../../../../../.tmp/social-direct-release-20261014/oauth-setup/facebook-test-published-20261015.jpg) · [YouTube 비공개 재생](../../../../../.tmp/social-direct-release-20261014/oauth-setup/youtube-test-private-playback-20261015.jpg).
- **새 백업·복원·최종 HA:** 백업419,125,680바이트·generation `1791972966347938`의 완료 뒤 19:22 KST 격리 복원·기동을 통과했다. DB 논리 사본·원래 키·identity 연결·참조 파일22개 보존, 자격증명4개 복호화·health ready·외부 요청0·시험 컨테이너 제거를 확인했다. 새 백업의 계정/세션 행과 토큰3→3(삭제0)은 격리 기동 전후 같았으며 실제 고객 로그인 시험은 아니다. 19:27 KST HA armed=true·A epoch7 ready·B 정상 대기·복제 healthy·공개 HTTPS200/ready/TLS를 인수했다. 같은 controller PID128775·동일 invocation의25.872초 관측과 재시작0을 확인했다. 새 강제 장애 전환 시험은 추가 실행하지 않았다(`currentReleaseOutageTested=false`·`noNativeRearmClaim=true`). [격리 복원](../../../../../.tmp/social-direct-release-20261014/rearm/dr/restore-v1.json) · [최종 HA 후검사](../../../../../.tmp/social-direct-release-20261014/rearm/arm-postcheck-final-v1.json).

운영 배포와 공개·계정 상태 검증, 새 버전 백업·격리 복원·HA 재활성화의 최종 인수를 완료했다. [최종 운영 인수 요약](../../../../../.tmp/social-direct-release-20261014/final-live-summary-v1.json). 10-15 KST 기준 Instagram·YouTube·Facebook3계정의 실제 연결·자동 게시 활성과 예약 업로드 시험3건을 완료했다. Facebook 댓글 연결·정기 수집도 확인했으며 과거 조회 한 바퀴 완료·일부수집 상태다. 고객 댓글에 대한 실제 답장·삭제 시험과 모든 과거 댓글 수집 완료를 확인한 것은 아니다. 앱 심사 완료나 모든 외부 SNS/형식의 자동 게시 지원을 주장하지 않는다.

<a id="sns-optimization-20261014"></a>
## SNS 전체 검수·성능 개선 · 2026-10-14 운영 반영

사용자 「전부 니가 직접 검수해보면서 최적화할거있으면 해줘」에 따라 기존 SNS 기능과 공용 작업본의 12·13판 화면을 보존하며 문의함 조회와 달력 그리기의 반복 연산을 줄였다. 고객 관리11판·고객 알림·SNS12·13판과 통합한 **`7aeace53b532…`를 운영에 반영했다**. 새 백업·격리 복원과 자동 장애 전환 활성화(HA armed=true·A epoch7·B 대기)의 최종 인수를 16:25 KST 마쳤다. 새 버전의 강제 장애 시험은 하지 않았으며 상세 결과는 [현재 운영 인수 기록](CLOUD-OPERATIONS.md#company-combined-release-20261014)을 따른다. 아래 수치는 합성 자료의 로컬 측정이며 운영 화면 응답 시간이나 실제 휴대폰 성능이 아니다.

| 같은 입력의 변경 전후 중앙값 | 변경 전 | 변경 후 | 측정 범위 |
|---|---:|---:|---|
| 댓글·전송 기록 각 1,000건 | 3,950ms | 211ms | 실제 로컬 HTTP·SQLite, 1회 준비 뒤 4회, 선택형 studio/client 서비스는 양쪽 모두 비움 |
| 300예약 달력 · PC 1440px | 1,619ms | 29.9ms | Edge 화면 생성·DOM·배치, 5회 |
| 300예약 달력 · 모바일 폭 390px | 673ms | 12.2ms | 같은 Edge의 화면 폭 변경, 5회 |

- **문의함:** `social-replies.mjs`가 답장 시도 전체를 댓글마다 다시 읽던 처리를 응답당 1회로 줄였다. 채널·자격증명도 그 동기 응답 안에서 계정당 1회만 읽는다. `social-marketing.mjs`의 문의함 채널 조회도 같은 방식이다. 삭제된 문의의 전송 시도라도 같은 원댓글의 중복 발송을 막으며, 원장 순서·최신 결과·보여 줄 정보는 유지한다. 다음 요청은 사용자·권한·연결 상태를 새로 읽고 실제 미리보기/전송의 권한·중복 검사는 그대로다.
- **화면:** `public/social-workspace.js`에서 예약을 날짜별로 한 번 묶고 게시물·계정 조회의 반복 순회를 줄였다. 날짜 포맷터만 최대32개 재사용하며 날짜·계정·권한 정보는 캐시하지 않는다. 서울 날짜 경계·예약 정렬·미예약 목록·이동 동작을 보존했다.
- **결과 동치:** HTTP 100/500/1,000건 응답 전체가 전후 동일하다. 합성100게시물·300예약·23계정의 9개 화면×1440/390px HTML과 문서 폭도 동일하고 외부 요청·JS 오류·가로 넘침0이다. 첫 UI 측정의 CSS 적용 범위 오류를 고친 `browser-measurement-styled.json`을 최종 수치로 사용한다. [HTTP 측정](../../../../../.tmp/social-optimize-20261014/endpoint-result.json) · [화면 전후 측정](../../../../../.tmp/social-optimize-20261014/ui/browser-measurement-styled.json) · [백엔드 규모별 측정](../../../../../.tmp/social-optimize-20261014/core/benchmark-result.json).
- **최적화 단계의 회귀·직접 화면:** 백엔드 고유56/56, 서버·연결·수집·복구·백업76/76, UI83/83을 통과했다. 별도의 실제 로컬 앱·격리 SQLite·합성 Meta 브라우저 검사는 PC1440/390/320px의 예약 이동·답장 초안 보존·권한 등을 포함해97/97 통과했다. 반복 실행은 중복 합산하지 않는다. root도 달력 PC/390px 캡처를 확인했다. 운영 브라우저 제어는 시간 초과로 실제 로그인 화면을 확인하지 못했다. [백엔드 시험](../../../../../.tmp/social-optimize-20261014/core/verification-result.json) · [서버 시험](../../../../../.tmp/social-optimize-20261014/server-tests.tap) · [UI 검증](../../../../../.tmp/social-optimize-20261014/ui/summary.json) · [브라우저97개](../../../../../.tmp/social-optimize-20261014/ui/browser-acceptance/report.json).
- **독립 검토:** 변경3파일과 Store 순서·원대상 식별·권한/중복 차단·시간대/달력 동치를 대조했고 실제 결함 지적0건이다. 변경 전 원문은 이번 증거 폴더의 `core/before/`와 `ui/social-workspace.before.js`에 보존했다. [검토·원문 SHA](../../../../../.tmp/social-optimize-20261014/ops/independent-source-review-v1.json).
- **운영 준비 진단:** 기존 배포 승인 준비는 로컬30.64초 동안 과거 증거2.356GB를 반복 읽었다. fresh 읽기·SHA·경로·마지막 대조를 유지한 JSON 파싱 재사용 실험8/8을 통과했으나 부분 실험이며 운영 도구에는 적용하지 않았다. 동결된 배포 도구·과거 실패 기록은 보존한다. [진단·제한](../../../../../.tmp/social-optimize-20261014/ops/diagnosis-v1.json).

- **최종 통합 후보·Linux:** 원문1,007개·이미지 목록588개인 후보 `7aeace53b532…`를 이미지 `sha256:86e883d5fefc…`로 검증했다. Node24.21.0의 격리 Linux에서 관련149파일 **1,760/1,760**, 이미지 호환성 **2/2**, 실패·취소·건너뜀0이다. 운영 데이터 마운트 없이 실행했으며 앞선 개별 시험과 합산하지 않는다. Windows 최종 회귀는1,758통과·실패0·심볼릭 링크 권한 제약2건 건너뜀이었고 Linux에서 두 검사까지 통과했다. [Linux 인수](../../../../../.tmp/company-combined-release-20261014/deployment/reviewed-candidate-receipt.json) · [최종 로컬 원문](../../../../../.tmp/company-combined-release-20261014/qa/final-result.json).
- **시험 교정·실패 기록:** SNS12의 실제 버튼 표시에 맞춰 보이는 필터 이름과0건을 검증하고, 부분 본문 수신 시험은 첫 본문 조각을 실제로 읽은 뒤 권한을 회수하도록 동기화했다. 기존401·자료 쓰기 금지 단언은 유지했다. 제품 동작을 완화하지 않았으며 교정 전 실패 회차·두 시험 원문·차이·부모와 후보 비교를 보존했다. [교정 기록](../../../../../.tmp/company-combined-release-20261014/qa-fix-result.json) · [기존 실패 회차](../../../../../.tmp/company-combined-release-20261014/qa/main-result.json) · [독립 검토](../../../../../.tmp/company-combined-release-20261014/ui/test-corrections-independent-review.json).
- **통합 화면:** 격리 앱·합성 자료로 SNS125개와 고객관리77개, 총 **202/202**를 확인했다. 마지막 시험2파일 교정 뒤 나머지1,005파일과 이미지 목록588파일이 동일한지 대조해 최종 후보에 연결했다. 운영 세션의 직접 화면 검증과는 구분한다. [최종 후보·화면 연결](../../../../../.tmp/company-combined-release-20261014/ui/final-runtime-binding.json).
- **운영 반영·한계:** 15:31 KST 후검사에서 양노드 새 manifest·A epoch7 단일 활성 상태·B 대기·control idle, 공개 기존126/126파일과 이번 변경·추가51/51파일 SHA, health200/ready·익명 SNS401을 확인했다(두 공개 목록은 별도 검사이며 합산하지 않는다). 기동 전 정지 상태의 논리 DB·파일·원키 보존은 정확히 확인했다. 기동 후 `synk_identity_sessions`는2→2행이지만 집계 해시가 달라 전체 세션 보존이나 로그인 연속성을 증명하지 않는다. 운영 IAB 제공자 불가로 기존 로그인 세션 화면 직접 확인은 미완료다. [운영 후검사](../../../../../.tmp/company-combined-release-20261014/deployment/runtime-live-postcheck-1791959484928.json) · [기존 공개 파일](../../../../../.tmp/company-combined-release-20261014/deployment/public-verification-1791959493148.json) · [변경 공개 파일](../../../../../.tmp/company-combined-release-20261014/public-added-1791959523557.json) · [운영 화면 시도](../../../../../.tmp/company-combined-release-20261014/ui/production-readonly-attempt.json).

최적화와 통합 검증에서 추가 실제 SNS 발송·유료 AI 호출은 하지 않았다. Postiz는 추가 비용 없이 설치 준비까지만 유지한다. 새 백업·격리 복원·HA 활성화의 최종 결과는 [통합 운영 인수](CLOUD-OPERATIONS.md#company-combined-release-20261014)에서 확인한다.

<a id="sns-meta-followup-20261014"></a>
## 댓글 운영 후속 네 항목 · 2026-10-14

[이번 구현 범위](WORKSPACE.md#sns-meta-followup-20261014)는 11:29 KST 운영 앱에 반영했고 실제 수집·공개 답장1회·답장 이후 백업/격리 복원/원장 대조를 확인했다. 이후 현재 로그인 상태로 새 백업·격리 복원·원장 대조와 최종 HA 인수까지 완료했다. Postiz는 추가 비용 없이 설치 준비까지만 유지한다.

- **최종 통합:** 관련11개 시험 파일 **197/197 통과**, 실패·취소·건너뜀0. 실행 전후21개 원문·시험의 SHA가 같고 루프백 외 네트워크를 막은 합성 시험이다. 진행 위치와 댓글의 원자 저장·실제 SQLite 재열기·부분 실패·커서/권한 변경, 외부 답장 식별·확인·전송 직전 변화 차단, 실제 HTTP 권한/CSRF·오류코드, 재연결 검증·수집 재개를 포함한다. [최종 결과](../../../../../.tmp/social-meta-followup-20261014/integration/20261014014703866/result.json) · [TAP](../../../../../.tmp/social-meta-followup-20261014/integration/20261014014703866/tests.tap).
- **예외와 독립 검토:** 오래된 수집 버퍼가 새 완전 조회 결과나 숨김 해제 상태를 되돌리는 문제, 삭제된 답글 관측 후 미리보기가 무효화되는 UI 문제, 내 계정의 답글을 미답변 문의로 집계하는 문제를 수정하고 회귀로 확인했다. 기존 수동 상태·담당·초안·전송 원장을 보존하며 내부 진행/전체 답글 ID는 공개 응답에서 제외한다. 수집기 [동결 지문](../../../../../.tmp/social-meta-followup-20261014/core/source-manifest-v3.json)과 UI [동결 지문](../../../../../.tmp/social-meta-followup-20261014/ui/source-final-v2.json)을 따르며 개별 시험 수는 통합 수에 다시 더하지 않는다.
- **실제 배포 후보:** 로그인 개선 부모 `0aac9438f17d…` 위에 이번 변경만 합친 후보 `2c401084ce7c…`는 원문983개·이미지 payload570개·실행 변경10개다. 부모978개 중967개를 바이트 그대로 보존했고 변경11개·신규5개·삭제0을 독립 대조했다. 공용 작업본의 별도 SNS12/13 디자인은 합치지 않았다. 기존 화면과 겹친 UI3함수에는 기능만 통합하고 없는 디자인 helper에 의존한 신규시험2곳을 후보의 실제 DOM·필터 검증으로 바꿨다. 후보 자체도 관련11파일 **197/197 통과**했으며 위 원문 시험과 합산하지 않는다. [후보 구성](../../../../../.tmp/social-meta-followup-20261014/runs/20261014015650197-24546847/preparation.json) · [후보 시험](../../../../../.tmp/social-meta-followup-20261014/runs/20261014015650197-24546847/qa/20261014015700199/result.json) · [후보 UI 보존·브라우저](../../../../../.tmp/social-meta-followup-20261014/ui/candidate-review.json).
- **Linux 이미지:** 실제 후보 이미지 `sha256:56ca0149b70b69fb195ce263cb38c8c6d6311a3815fc4bab26cb900b08f2731f`의 Node24.21 환경에서 같은 관련 시험197개와 이미지 호환성2개를 통과했다. network none·운영 데이터 마운트0·서비스 변경0의 격리 시험이며 기존 시험 수와 합산하지 않는다. [Linux 후보 인수](../../../../../.tmp/social-meta-followup-20261014/deployment/reviewed-candidate-receipt.json). 배포 실행기46파일은 검증된 부모의 SHA와 이번19개 바인딩 치환만 있는지 root가 독립 대조했다. [실행기 대조](../../../../../.tmp/social-meta-followup-20261014/deployment-binding-root-review.json).
- **화면:** 기존 Edge를 사용한 로컬 합성 fixture에서 PC1280px·모바일390px의 재연결 확인→수집 재개, 미답변/답장 필터, 기존 답장 확인란·초안 유지·삭제 후 새 미리보기를 확인했다. 가로 넘침·JS 오류·외부 호출0이다. 실제 계정으로 로그인한 운영 화면 검증은 아니며 Codex 브라우저 제어는 kernel assets의 경로 오류로 시작하지 못했다. [원문 화면 검증](../../../../../.tmp/social-meta-followup-20261014/ui/browser-result-v2.json) · [배포 후보 화면 검증](../../../../../.tmp/social-meta-followup-20261014/ui/candidate-browser/browser-result.json). 후보의 PC·390px 캡처는 root도 시각 대조했다.
- **운영 교체:** 11:29 KST 양노드 FINALIZE·controller complete·exit0, A epoch7 단일 writer·B 대기·control idle을 확인했다. 공개126/126파일 SHA 일치·health200/ready·익명 SNS401이다. 원키와 정지 중 전체 논리 DB/파일은 정확히 보존했으며 기동 후 `synk_identity_sessions`1→1행의 집계 해시 차이는 원인 미확정으로 기록한다. 실제 브라우저 로그인 연속성 검증은 아니다. [운영 검증](../../../../../.tmp/social-meta-followup-20261014/deployment/runtime-live-postcheck-1791944947347.json) · [공개 검증](../../../../../.tmp/social-meta-followup-20261014/deployment/public-verification-1791944955168.json).
- **배포 전 실제 읽기:** 로그인 개선 부모 `0aac9438f17d…`에서 `@yuhobuilds`의 공개 원댓글4개를 확인해 미답장 후보3개를 준비했다. Meta GET9회·POST0, DB 읽기 전용·원키/계정 연결 보존·방화벽 변경0이다. 실제 작성자 ID가 담긴 답글은 없는 후보였으므로 이 결과를 실제 답글 작성자 필드 검증으로 확대하지 않는다. [후보 읽기](../../../../../.tmp/social-meta-followup-20261014/ops/public-candidates-1791942350186.json).
- **다른 계정:** 10:49 KST 기존 Vault의 `@synkbrief` 자격증명으로 계정·게시물 GET2회를 수행했으나 소유 게시물의 댓글 접근 증거가 없어 `META_COMMENT_PROOF_REQUIRED`로 보류했다. 빈 게시물 결과를 댓글 권한으로 간주하거나 저장하지 않았다. `@synk.mn`은 기존 자격증명이 없다. [현재 읽기 결과](../../../../../.tmp/social-meta-followup-20261014/ops/existing-account-readiness-1791942562748.json). Facebook4채널과 회사 Facebook OAuth 설정은 10:21 KST 조회 때 자격증명이 없었으며, 다른 앱의 토큰을 빌리지 않았다. 이 계정들의 새 인증·실수집은 완료되지 않았다.
- **운영 수집과 저장 결과:** 새 앱의 실제 GET14회·POST0으로 수집→health→지정 원댓글 미리보기를 진행했으나 마지막 전체 보호행 비교에서 `PROTECTED_DATABASE_ROWS_CHANGED`로 보류됐다. 검사를 반복하지 않고 readOnly/query_only의 한 snapshot으로 원실행 시각·대상·문구·원증거를 대조해 진행 revision34·게시물1·댓글6·대기 큐 없음, connected 건강 결과, 미리보기1 저장을 확인했다. 전체 과거 기록 완전 수집을 뜻하지 않는다. 회수 자체는 Meta0·DB쓰기0이고 실행 전후 owner/epoch·이미지·컨테이너·data mount·ready/control을 대조했다. 원 보류·전체 보호행 비교 실패·원인 미확정은 그대로 남긴다. [원 검증](../../../../../.tmp/social-meta-followup-20261014/ops/live-check-completion-1791945003222.json) · [저장 결과 회수](../../../../../.tmp/social-meta-followup-20261014/ops/stored-recovery-completion-1791946041263.json).
- **실제 공개 답장1회:** 사용자의 대상·문구 승인 후 11:52:58 KST 지정 Instagram 원댓글에1회 전송했다. 해당 단계의 GET11·POST1, native durable `sent`, Meta에서 작성자·원댓글·게시물·정확한 문구를 재조회한 결과와 dedupe/inbox 전송 원장이 일치했다. 현재 app container 안에서 전후 owner/epoch·이미지·data mount·ready/control이 같고 임시 SSH 허용은 원복했다. 이번 실행 구간의 보호행 비교는 일치했으며 앞선 수집 검증의 불일치를 소급해 성공으로 바꾸지 않는다. 추가 발송·재전송은0이다. [실제 전송 확인](../../../../../.tmp/social-meta-followup-20261014/ops/live-reply-completion-1791946378952.json). 발송 보조 도구의 별도 합성14/14는 결과 불명·응답 유실·권한 회수·기존 답장 발견·1회 제한·조회 한도·두 작성자 필드 불일치를 포함한다. [한정 실행 검증](../../../../../.tmp/social-meta-followup-20261014/live-reply/source-freeze-v1.json).
- **답장 후 최종 백업:** 실제 답장 완료11:52:58 KST 뒤 12:02:11 KST 데이터 snapshot을 만들고 같은 invocation의 완료·업로드를 확인했다. 416,883,873바이트·generation `1791947305647429`·SHA256 `866cd3d950e631cbd214f42d983b163c670984b8ab218fc94595e4a99a64e113`이다. 앞선 요청은 기존 작업 잠금에서 실행 전 멈췄고, 미실행과 잠금 해제를 확인한 뒤 새 요청으로 진행했다. 원 실패 기록은 보존한다. [완료 백업](../../../../../.tmp/social-meta-followup-20261014/rearm/dr/backup-status-after-reply-retry-1791947411146.json) · [답장 이후 시각 대조](../../../../../.tmp/social-meta-followup-20261014/rearm/dr/backup-after-reply-retry-order-v1.json).
- **복원 공간 확보:** 원격 원본의 정확한 generation·해시와 기존 성공 증거를 대조한 뒤 이전 복원 파생본·중복 다운로드/이미지 전송 캐시7경로만 정리했다. 실제 여유 공간1,836,408,832바이트 증가, 운영 데이터·원격 백업·로드한 이미지·현재/부모 릴리스 원문·190개 검증 원문을 보존했다. [정리·보존 결과](../../../../../.tmp/social-meta-followup-20261014/cleanup/cache-cleanup-result-v1.json).
- **실제 격리 복원:** 12:16:58 KST 최종 백업의 정확한 generation·해시로 복원·앱 기동을 통과했다. 원키·릴리스983파일·계정/세션9표·토큰3→3 보존, 외부 요청0, network:none·공개 포트0·시험 컨테이너 제거·대기 서버 불변을 확인했다. 운영 DB/VM/클라우드 권한 복원이나 실제 사용자 로그인·새 강제 장애 시험은 아니다. [격리 복원 결과](../../../../../.tmp/social-meta-followup-20261014/rearm/dr/restore-after-reply-retry-v1.json).
- **복원된 실제 답장 원장:** 12:20:26 KST 완료된 복원본만 읽기 전용 Docker에 연결해 native sent1건·dedupe·문의함·승인 문구/시각 일치를 확인했다. DB 바이트 불변·키/자격증명 읽기0·네트워크/운영쓰기0, B 권한·원문·control 전후 동일·시험 컨테이너 제거를 확인했다. 임시4파일 부재는 `privateMarkersPassed:false`와 정규 백업 제외로 표시하며 원장 필수 검증의 성공과 구분한다. [원장 대조](../../../../../.tmp/social-meta-followup-20261014/ops/read-restored-reply-v1.completion.json). 읽기 도구와 실행 wrapper의 별도 모의시험은15/15·10/10이며 실제 복원 결과와 합산하지 않는다.
- **별도 실행 증거:** claim/dispatch/outcome/final 임시4파일은 정규 백업 대상이 아니다. 안전한 고정 필드만 읽어 로컬에 SHA·크기와 함께 보관했으며 실제 답장 completion과 일치한다. Meta·DB·키 접근과 원격 쓰기는0이다. [별도 보관](../../../../../.tmp/social-meta-followup-20261014/ops/reply-evidence-retained-1791947335725.json). 복원본의 필수 검사는 native sent·중복 방지·문의함 원장이다.
- **첫 HA 재활성화 중단:** request `ac7fafc2…`는 실제 직전 Google 로그인 계약을 Meta 연결 계약 schema로 검사한 `LIVE_PRIOR_ARM_SCOPE`에서 중단됐다. 동일 request의 unit/원장을 읽어 설정 변경 전 중단을 확인했다(원장 없음·armed=false·원 plan/acceptance·runtime/worker·control 동일, A epoch7·controller 정상·잠금 소유0). 응답 불명확 기록과 원 계약·QA를 보존했으며 같은 요청을 재전송하지 않았다. [실제 원인·현재 상태](../../../../../.tmp/social-meta-followup-20261014/ops/arm-diagnostic-1791948334169.json).
- **HA 후계 검증과 추가 보류:** 실제 Google 부모 schema1곳만 수정한 별도 후계의 Linux Node119·Python35·기존 배포126, **280/280 통과·실패/건너뜀0**을 확인했다. 원190개 소스·실패 계약을 보존하고 실제 부모/다른 schema 거부 회귀를 추가했다. [후계 소스](../../../../../.tmp/social-meta-followup-20261014/rearm-v2/source-successor-v2.json) · [Linux 검증](../../../../../.tmp/social-meta-followup-20261014/rearm-v2/linux-qa-result-v1.json). 새 준비는 owner 읽기의 `PROTECTED_ACCOUNT_PRIMARY_KEY_DELETED`에서 arm 계약 생성 전에 멈췄으며, 현재 baseline 대비 tokens의 session1행과 연결된 synk_identity_sessions1행 누락을 확인했다. 원 snapshot상 관측시각에 미만료였고 credentials/users/identity links 등 안정4표는 누락0이다. 사용자는 이후 「로그아웃했던것같아」라고 답했다. 소스의 로그아웃·인증거부 시 token삭제와 FK CASCADE에 부합하지만 실제 삭제 경로는 확정하지 않는다. 삭제된 세션을 복원하지 않고 원 백업/복원/진단을 보존한 채 현재 상태의 새 최종 백업·격리 복원을 준비한다. [실제 차이 집계](../../../../../.tmp/social-meta-followup-20261014/ops/account-retention-result-1791950440656.json). [보호 검사 진단](../../../../../.tmp/social-meta-followup-20261014/ops/owner-read-diagnostic-1791949728674.json).
- **현재 로그인 상태의 새 백업·복원:** 삭제된 세션을 되살리지 않고 13:08:44 KST 현재 데이터 snapshot을 만들었다. 같은 invocation의 완료·업로드와 416,881,512바이트·generation `1791951310505965`·SHA256 `001d5110353ca3a95ddd7fd5cfc229ee4a581e6464dd0efb89920f67320674dc`를 대조했다. 13:40:09 KST 이 백업의 격리 복원·정상 기동을 통과했다. 원키·릴리스983파일·계정 관련9표와 토큰2→2 보존, 삭제0·외부 요청0·network:none·시험 컨테이너 제거를 확인했다. 원 백업·복원·세션 차이 기록을 보존하며 새 기준의 최종 HA 인수까지 완료했다. [새 완료 백업](../../../../../.tmp/social-meta-followup-20261014/rearm/dr/backup-status-after-logout-1791951320685.json) · [새 격리 복원](../../../../../.tmp/social-meta-followup-20261014/rearm/dr/restore-after-logout-v1.json).
- **새 복원의 공간 확보:** 이전에 성공한 복원 파생본4개·다운로드 캐시1개·완료된 부모 QA 원문 복제본1개를 정리해 실제 1,562,095,616바이트를 확보했다. 부모 원문978파일과 복제본의 동치·참조 없음, 원격 백업의 정확한 generation·SHA, 사용자 전용 로컬 백업 사본을 먼저 확인했다. 운영/부모 릴리스·로드한 이미지·원키·검증 원문190/192개는 보존했다. 원격 정리는 완료됐지만 마지막 로컬 후검사에서 오류가 나 원 결과를 보존하고, 같은 원장을 읽기 전용으로 회수해 결과 일치·6대상 부재·로컬 보존 검사를 확인했다. 재삭제0이며 원 후검사 실패 원인은 미확정으로 남긴다. [정리 결과 회수](../../../../../.tmp/social-meta-followup-20261014/cleanup-after-logout/cache-cleanup-recovered-v1.json).
- **새 복원 원장·최종 HA 인수:** 새 복원본에서도 native sent1건·중복 방지·문의함·승인 문구와 시각 일치, DB 쓰기/네트워크0을 확인했다. 현재 계정 기준을 새 완료 백업에 명시적으로 연결하고, 원 과거 기준·실패 기록을 그대로 보존했다. 새 요청 `c63a2f91-3ed2-4420-a608-e8f036317337`은 원120초 유효기간 안에1회 실행해 `installed-armed`·exit0으로 완료됐다. 최종 postcheck에서 `armed=true`·A epoch7 단일 writer·B 정상 대기·복제 healthy·공개200/ready를 확인했다. 재활성화 전 자연 관측은1,160.492초·19표본·3지역·오류0, 재활성화 후 controller 동일 프로세스60,318ms 관측·재시작0이다. 현재 릴리스의 새 강제 장애 시험을 한 결과는 아니다. [새 복원 원장](../../../../../.tmp/social-meta-followup-20261014/ops/read-restored-reply-after-logout-v1.completion.json) · [최종 HA](../../../../../.tmp/social-meta-followup-20261014/rearm-v2/arm-postcheck-after-logout-v1.json) · [재활성화 후 독립 공개 확인](../../../../../.tmp/social-meta-followup-20261014/root-public-after-arm-1791953665411.json).
- **최종 증거 대조:** [최종 인수 요약](../../../../../.tmp/social-meta-followup-20261014/final-live-summary-v1.json)의 참조106개 SHA를 root도 독립 재계산해 일치를 확인했다. 최종 공개126파일 일치·health200/ready·익명 SNS401과 임시 SSH 허용59회의 원복을 확인했다. 신규 유료 자원·Postiz 설치는0이며 기존 실패와 미확인 원인을 성공으로 덮어쓰지 않았다.
- **남은 확인:** 나머지 계정의 추가 인증이 남아 있다. 다른 앱에서 새로 보낸 답장을 실제로 생성한 운영 왕복은 하지 않았으며 관측·차단의 합성 검증과 구분한다. 마지막 Meta GET 뒤 다른 앱이 보내는 동시 답장까지 원자적으로 방지한다고 보장하지 않는다. 전체 과거 댓글 완전 수집·DM 수신·무검토 AI 자동 답장은 포함하지 않는다.

<a id="sns-meta-comments-20261014"></a>
## Meta 댓글 직접 연결 · 2026-10-14

[연결·수집·답장 흐름](WORKSPACE.md#sns-meta-comments-20261014)의 후속 검증이다. 운영 후보 `25bb4bff70bd…`의 배포와 `@yuhobuilds` 연결·댓글 6건 저장을 확인했다. 실제 건강 점검·답장 미리보기도 성공했다. 연결 후 새 백업·실제 격리 복원·HA 재활성화와 공개 서버 정상 응답을 확인했다.

- **실제 Meta 읽기:** 기존 Vault의 정확한 계정을 메모리에서만 조회했다. `@yuhobuilds`와 `@synkbrief`의 계정 인증은 성공했고 `user_id`와 앱 범위 `id`가 다른 것을 확인했다. `@yuhobuilds`의 게시물 소유자 ID는 앱 범위 ID와 일치하며 댓글 GET은 성공했다. [값을 제외한 계정 관측](../../../../../.tmp/social-meta-connect-20261014/meta-readonly-observation-1791929700185.json) · [댓글 읽기 관측](../../../../../.tmp/social-meta-connect-20261014/meta-comment-capability-1791929797243.json).
- **새 연결 서비스의 실측:** 운영 저장 전에 새 서비스로 `/me`·게시물 목록·소유자·댓글의 **GET 4회가 모두 HTTP 200**인 것을 확인했다. 실제 승인 scope 목록과 만료일을 얻었다고 표시하지 않았고, 답장 전송은 실행하지 않았다. [실측 영수증](../../../../../.tmp/social-meta-connect-20261014/meta-helper-live-1791930265046.json). 이후 Facebook 공식 링크 호환 수정은 Instagram의 이 GET 분기를 바꾸지 않았다.
- **로컬 검사:** 계정 불일치·타인 게시물·위조 scope/만료일·토큰 교체·중간 로그아웃/권한 해제·중복 계정·Facebook 앱/페이지·만료를 검사했다. 실제 API 필드에 맞춘 `from.username` 수집, 서로 다른 두 ID를 통한 소유자 검사, 수집→미리보기→확인된 가짜 전송을 검증했다. Meta 수동 연결은 관리자에게만 노출하고, 댓글 OAuth를 별도 선택하며, 읽기 확인을 실제 발송 성공으로 표시하지 않는다.
- **정확 배포 후보:** `25bb4bff70bd…`는 실제 부모 `ab82ff6c7439…`의 961파일을 보존하고 운영 8파일과 관련 시험만 바꿨다(source978·payload567). Windows 관련 **231/231**, 실제 Linux 후보의 같은 **231/231·이미지 호환성2/2**가 실패·건너뜀 없이 통과했다. 운영 데이터 마운트·서비스 변경·유료 호출은 0이다. [후보·Linux 검증](../../../../../.tmp/social-meta-connect-20261014/deployment/reviewed-candidate-receipt.json).
- **첫 운영 시도와 복구:** 첫 배포 `c4537a10…`는 새 writer 시작 전에 `TimeoutExpired`로 실패했고 자동 되돌림도 `PROBE_COMMAND_FAILED`에서 멈췄다. 컨테이너 제거가 뒤늦게 완료되며 복구 명령과 경합했을 가능성이 있으나 실패 명령이 기록되지 않아 원인을 확정하지 않는다. 같은 계약의 공식 `Controller.recover()`를 한 번 호출해 새 복구 순서로 진행했고 **08:33 KST 공개 HTTP200/ready**, 이후 `complete/recovered:true`와 원래 A epoch7·maintenance0을 확인했다. 원 실패 영수증과 기한을 보존했고 DB 복원은 0이다. 이 복구 시점에는 이전 `ab82ff6c…` 버전과 `armed=false`를 확인했다. 이후 새 배포 결과는 다음 항목과 구분한다. [실패 영수증](../../../../../.tmp/social-meta-connect-20261014/ops/incident-receipts-1791934020013.json) · [공식 복구](../../../../../.tmp/social-meta-connect-20261014/ops/recover-held-result-v1.json) · [복구 완료](../../../../../.tmp/social-meta-connect-20261014/deployment/live-status-1791934426945.json).
- **재발 방지 보완·두 번째 배포:** 컨테이너 제거 요청을 다시 보내지 않고 원 ID와 이름의 부재를 확인하며, 조회 경합은 기존 검사 전체를 다시 실행하도록 별도 worker 후계를 검토했다. 실제 Linux worker 시험 **140/140**(실제 Docker 호출은 모의)을 통과했다. 연결 후 보존 경계와 백업 준비 경로를 보완한 최종 재활성화 후계는 **287/287**(Node127·Python34·기존 배포126, 실패/건너뜀0·보호 코드 불변)이다. [최종 Linux 시험](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/linux-qa-result-v3.json). 앱의 Linux **233개** 결과는 같은 후보의 기존 결과를 재사용하며 새 실행으로 합산하지 않는다. 배포 `3d9fecd9…`는 `complete/recovered:false`, A/B FINALIZE·모든 job exit0으로 완료됐다. [worker 시험](../../../../../.tmp/social-meta-connect-20261014/deployment-v2/worker-qa-result-v2.json) · [배포 완료](../../../../../.tmp/social-meta-connect-20261014/deployment-v2/live-status-1791936316633.json).
- **실제 운영 코드·보존 대조:** 새 manifest의 역할·실행 이미지·정지 중 전체 논리 DB/파일·원 암호화 키·스키마를 확인했다. 공개 파일 **125/125 SHA 일치**, health HTTP200/ready, 익명 SNS API401이다. 기동 후 `synk_identity_sessions` 1행의 집계 해시는 달라 전체 세션 행 동일 보존이나 실제 로그인 연속성은 입증하지 못했다. [runtime 대조](../../../../../.tmp/social-meta-connect-20261014/deployment-v2/runtime-live-postcheck-1791936385995.json) · [공개 대조](../../../../../.tmp/social-meta-connect-20261014/deployment-v2/public-verification-1791936369668.json).
- **실제 연결·수집·미리보기:** 공식 연결 서비스로 `@yuhobuilds`의 암호화 자격증명·채널을 저장하고 수집을 켜 **원댓글 6건**을 가져왔다. 09:26 KST 계정 health `connected`·오류0, 답장 가능한 원댓글6, 실제 Meta GET으로 답장 미리보기 검증 성공을 확인했다. 최초 연결 GET8 + 재개 GET4 = **GET12·POST0·실제 발송0**이다. 재개 때 연결/설정/수집을 반복하거나 Vault를 다시 조회하지 않았다. [최종 연결 결과](../../../../../.tmp/social-meta-connect-20261014/ops/resume-v2-result-1791937558292.json).
- **부분 실행 보존과 재개:** 첫 관리 호출은 대상 외 채널의 secret 조회 제한으로 health 요약 단계에서 멈췄다. 저장된 연결과 댓글을 재생성하지 않고 타 채널 비밀값은 읽지 않는 좁은 호출자로 남은 단계만 진행했다. 과거 사전 백업과 비교하면 세션1행의 암호문만 달라져 과거 전체행 exact 보존은 `false`로 남겼다(PK 유지·추가삭제0, 다른 보호표·기존 credential·키·게시/예약/답장 기록 exact). 세션 자동 재검증의 재암호화 경로와 부합하나 원인은 확정하지 않는다. 재개 직전/직후 09:25:59.802~09:26:01.635의 별도 읽기 트랜잭션으로 새 보호행 exact 보존을 확인했다. [최초 부분 실행](../../../../../.tmp/social-meta-connect-20261014/ops/connect-result-1791936433915.json) · [값 없는 차이 관측](../../../../../.tmp/social-meta-connect-20261014/ops/preservation-inspection-1791937313757.json). 재개 모의 회귀7/7을 통과했으며 원 실패/백업은 수정하지 않았다.
- **주기 수집 설정·실제 갱신:** 연결별 `enabled=true`와 기존 서버 스케줄러 설정을 확인했다. 추가 수동 sync 없이 `lastSyncedAt`가 **09:07:22.740→09:26:58.964 KST**로 갱신됐고 `scanned`·오류0, 댓글6·실제 답장 attempt0을 유지했다. [읽기 전용 운영 관측](../../../../../.tmp/social-meta-connect-20261014/ops/inventory-1791937884925.json). 서버15분 점검과 계정별15분 간격을 각각 적용한다. 다음 계정 자격 시각 09:41:57 KST는 계산값이며 실제 다음 실행 시각이나 런타임 메모리의 성공시각을 직접 읽은 것으로 표현하지 않는다.
- **연결 후 백업·격리 복원:** 09:37:41 KST 요청한 최종 백업 `b260c43d…`가 같은 invocation `7348266c…`의 완료 이벤트·업로드·exit0으로 끝났다. 데이터 시각09:37:48 KST는 계정 연결 이후이며, **416,564,892바이트·generation1791938638295886·SHA256 `220877fee741…`**를 대조했다. 09:50:40 KST B의 격리 복원에서 원키·계정표9개·credentials3행·토큰2→2 보존, 자격증명 복호화4개·ready·network:none·외부요청0·검증 컨테이너 제거를 확인했다. 운영 DB·VM·클라우드 권한 복원은 없으며 실제 사용자 로그인·새 강제 장애 시험을 뜻하지 않는다. 이 백업의 복원·계정 보존 증거를 아래 HA 인수에 연결했다. [연결 포함 근거](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/connection-inclusion-v1.json) · [완료 백업](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/dr/backup-status-1791938723929.json) · [실제 격리 복원](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/dr/restore-v1.json).
- **최종 HA·공개 확인:** request `4a907d93…`는 원래 120초 계약과 동일 검사 안에서 준비→stage→dispatch를 순차 실행해 `installed-armed`·exit0으로 완료했다. 기존 배포 후 journal과 3지역 Monitoring의 **820.601초·14표본·오류0**을 교차 확인해 최소180초/4표본 기준을 충족했다. 새 controller invocation의 **42.875초** 관측에서 동일 PID·재시작0·`RECOVERED`, **armed=true·A epoch7 단일 writer·B 정상 대기·복제 healthy·공개 TLS200/ready**를 확인했다. 공개 파일도 **125/125 SHA 일치·익명 SNS401**이다. 표본 관측을 연속 무중단이나 이번 릴리스의 새 강제 장애 시험으로 표현하지 않는다. [자연 관측](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/natural-final-v1.json) · [활성화 결과](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/arm-status-1791939546061.json) · [활성화 후 실제 확인](../../../../../.tmp/social-meta-connect-20261014/rearm-v2/arm-postcheck-final-v1.json) · [최종 공개 대조](../../../../../.tmp/social-meta-connect-20261014/deployment-v2/public-verification-1791939591740.json).
- **인증이 남은 계정:** `@synkbrief`는 게시물 목록이 비어 수동 토큰의 댓글 기능 검증을 완료하지 않았다. `@synk.mn`은 해당 공개 handle의 운영 Vault 계정 행이 없고 Facebook 네 채널에는 회사 서버의 계정 연결이 없다. 이 계정들을 연결 완료로 표시하지 않는다.
- **보존·확인 범위:** 기존 `synkbrief-dm` 콜백·구독·DM/공개 자동 답글·억제 기록·토큰 갱신 설정을 변경하지 않았다. 실제 댓글/DM 발송, Postiz 설치, 신규 유료 자원, 가입·SNS 게시 시험은 0이다. 브라우저 제어 도구가 시작 오류를 내 이번 실제 로그인 화면 검증은 수행하지 못했다. 서버의 실제 읽기 관측과 로컬 UI 검사로 확인한 범위를 구분한다.

최종 09:59 KST 조회에서 자동 수집 성공 시각이 **09:57:00.537 KST**로 다시 전진했고, 댓글6·답장 시도0·A ready·B 정상 대기·HA 활성·control idle을 유지했다. 임시 SSH 규칙은 원래 API 값으로 모두 원복했다. 과거 원복 미완료3건의 후속 복구 증거도 [최종 인수 요약](../../../../../.tmp/social-meta-connect-20261014/final-live-summary-v1.json)에 연결했다. 요약의 SHA256은 `4dbbe0c301680aedd6e047e7e9ae94971145c1d37d5383516b24285b72808c10`이며, root가 연결된 증거31개 SHA·크기를 모두 대조했다.

<a id="sns-workspace-launch-20261014"></a>
## 운영 반영·문의 후속 업무·첫 사용 설정 · 2026-10-14

[추가 네 항목](WORKSPACE.md#sns-workspace-launch-20261014)의 최초 04:36 KST 배포 검증 범위다. 후속 Meta 계정 연결은 [최신 검증](#sns-meta-comments-20261014)을 따른다. 회사 SNS 기능, 중앙 계정 서버 v57, 웹사이트 `af31faaa…`의 전환 연결 공개 반영을 확인했다. 아래 로컬 화면·합성 회귀, Linux 후보 시험, 실제 운영 코드 대조는 각각 별도 근거이며 실제 SNS 게시나 사용자 유입·전환 성과로 합산하지 않는다. 회사 HA의 최종 재활성화·복구 상태는 [운영 기록](CLOUD-OPERATIONS.md)을 따른다.

- **회사 운영 배포:** 로그인 3판 `1d5f93e0d19d…`에서 SNS·승인된 PULSE 후보 `ab82ff6c7439…`로 반영했고 [실제 runtime postcheck](../../../../../.tmp/social-workspace-live-20261013/deployment/runtime-live-postcheck-1791914988310.json)가 통과했다. A/B/controller 역할·이미지·원래 암호화 키·스키마·정지 중 데이터 보존을 확인했다. 기동 후 세션/토큰 표는 달라져 전체 행 동일 보존이나 실제 인증 브라우저의 로그인 연속성까지 증명한 결과는 아니다.
- **공개 코드 대조:** [공개 검증](../../../../../.tmp/social-workspace-live-20261013/deployment/public-verification-1791915000879.json)에서 SNS·PULSE·기존 로그인/메신저 등의 공개 파일 **125/125 SHA 일치**, health 200/ready, 익명 SNS API 401을 확인했다. 이 수치는 아래 four 브라우저의 125개 시나리오와 다르다. 검증을 위한 실제 세션·SNS 게시 생성은 각각 0이다.
- **Linux 후보와 HA 도구:** [후보 영수증](../../../../../.tmp/social-workspace-live-20261013/deployment/reviewed-candidate-receipt.json)의 앱 회귀 **867/867**, 호환성 **2/2**는 운영 데이터를 마운트하지 않은 실제 Linux 이미지 시험이다. [후계 rearm Linux QA](../../../../../.tmp/social-workspace-live-20261013/rearm/linux-qa-result-v1.json)는 별도로 Node 91·Python 34·기존 배포 회귀 126, **251/251**이며 실패·건너뜀 0, 소스 불변·네트워크 격리·보호 경로 접근 차단을 확인했다. HA 도구 시험은 실제 재활성화나 이번 릴리스의 강제 장애 전환 시험 완료를 뜻하지 않는다.
- **수집기와 계정 서버 반영:** 회사 수집기에 `https://synk.im` 허용 출처와 별도 검증 키를 초기 설정했다. [초기 설정 결과](../../../../../.tmp/social-workspace-live-20261013/deployment/tracking-initialization-1791915051016.json)의 실제 계정·추적 링크·사건 생성은 모두 0이다. 중앙 `synk-account`의 [배포 결과](../../../../../.tmp/social-conversion-talk-20261014/remote/deployment.json)는 **v57 ACTIVE**, 후보와 모듈 15개 SHA 일치·entrypoint 동치, OPTIONS 204·무인증 401, 검증 키 설정 존재와 사이트 수집 CORS 204를 확인했다. 키 값은 기록하지 않으며 회사 키를 회전하면 서버의 `SYNK_SOCIAL_VERIFICATION_KEY`도 함께 갱신해야 한다. 실제 가입·체험 사건을 만들어 시험하지 않았다.
- **웹사이트 공개 반영:** `af31faaacd2fd10f9a6a737cceb87c91dfb57ba3`의 Pages 배포가 완료됐다. [공개 HTTP 대조](../../../../../.tmp/social-website-20261014/public-http.json)는 배포 파일 **20/20 HTTP 200·SHA 일치**와 Pages built를 확인했다. [실제 공개 브라우저 기록](../../../../../.tmp/social-website-20261014/public-browser-deployed.json)은 일반 URL의 홈·SYNK ID·리듬·바람길 4화면에서 페이지/자산 오류 0, 수집기 요청·쓰기 시도 차단 건수 0을 확인했다. 추적 링크·가입·체험 사건을 만들지 않은 공개 화면 확인이며, 실제 전환 완료 왕복을 검증한 결과는 아니다.

- **새 흐름 실제 화면:** 임시 SQLite·합성 사용자·실제 회사 HTTP 서버와 메신저·Chromium으로 **43/43**을 통과했다. 신규 시나리오 36개와 공통 진입·오류·외부 요청·소스 고정 가드 7개다. 1440·390·320px 캡처 **12장**, [브라우저 기록](../../../../_ops/qa/social-workspace-launch-20261014/report.json)을 남겼다. 실제 휴대폰·공개 사이트 검증은 아니다.
- **확인한 왕복:** 화면에서 문의 생성 → 대화방·담당자·다음 행동·기한 입력 → 연속 등록에도 기존 업무 1개 → 메신저의 정확한 원문 메시지·업무 상세 → 기존 오늘 할 일 → 원문 링크로 해당 문의 선택·포커스 → 전체 목록 복귀를 확인했다. 새 업무 본문에는 사용자가 쓴 다음 행동과 내부 원문 링크만 있으며 댓글 작성자·문의 본문은 자동 복사하지 않았다.
- **입력·권한·모바일:** 입력 직후 포커스를 옮기기 전 갱신과 화면 이동에도 후속 업무 입력이 유지된다. 문의 버전이 바뀌면 등록 요청 0회로 차단하고, 명시적으로 다시 확인하면 작성한 행동을 지우지 않고 현재 버전을 사용한다. 읽기 전용 사용자에게 등록 폼을 제공하지 않으며, 원문 조회 권한 회수 시 선택된 문의를 제거한다. 업무 대화방 권한이 없으면 업무 내용도 노출하지 않는다. 390·320px에서 설정·입력·등록 버튼·원문 복귀의 가로 넘침과 사용 경로를 확인했다.
- **첫 설정의 실행 경계:** 계정 선택과 다섯 단계의 이동 버튼은 설정 저장·예약·발행을 하지 않는다. 이번 launch 검증의 외부 브라우저 요청, SNS 발행, Meta 호출, AI 호출은 각각 **0회**다. 브라우저 예외·콘솔·자산·SNS API 오류도 0이며 브라우저·임시 서버 종료와 시험 데이터 제거를 확인했다.
- **현재 관련 회귀:** 후속 업무 서비스·첫 설정·실제 HTTP 연결·기존 직접 업무 생성의 4개 시험 파일 **37/37**, 실패·취소·건너뜀 0. [TAP 원본](../../../../_ops/qa/social-workspace-launch-20261014/followup-tests.tap). 재시작·응답 유실 후 중복 방지, 현재 원문·대화방 권한, 다른 작성자의 등록 복구 입력 비공개, 원문 수정 뒤 기존 업무 조회, 기존 할 일·배정 알림을 포함한다. 별도 클라이언트·SNS 탐색 **69/69**도 통과했다. 이 숫자는 SNS 전체 시험 총계가 아니다.
- **기존 화면 회귀:** 기존 9개 화면과 연결 점검·예약 분산·댓글 답장·문구 비교의 별도 브라우저 실행 **125/125**, 캡처 **60장**을 다시 확인했다. [기존 four 기록](../../../../_ops/qa/social-workspace-four-20261013/report.json)은 2026-10-14 재실행 결과다. launch와 실행 전후 UI 5파일 해시가 같고 외부 브라우저 요청은 0이다. launch 43개와 이 125개는 별도 실행으로 보고하며 단일 고유 시험 총계로 합치지 않는다.
- **사이트 전환의 준비 검증:** 공개 번들의 동결 원문에 대한 공통 전환·가입 확인·portal 경합·Google/로그아웃 회귀 **141/141**의 [최종 시험](../../../../../.tmp/social-website-20261014/frozen-tests.tap)을 확인했다. 앞선 원문 시험 138개에 공통 모듈 3개를 포함한 결과이며 공개 사이트에서 발생한 전환 수가 아니다. 실제 운영 TALK v55 원문 15개 중 12개를 보존하고 3개 최소 수정·관측 모듈 1개를 추가한 서버 후보의 배포 전 시험은 별도 **53/53**이다. [후보 시험](../../../../../.tmp/social-conversion-talk-20261014/remote/candidate-tests.tap) · [파일 대조](../../../../../.tmp/social-conversion-talk-20261014/remote/candidate-manifest.json). 실제 v57 반영 근거는 위 배포 결과와 구분하며, 이 시험들은 앞의 SNS·클라이언트 검증과 합산하지 않는다.
- **당시 운영 확인과 제한:** 이 최초 배포 당시 실제 SNS 계정 인증·댓글 발송·게시와 실제 사용자 유입·전환 관측은 **0회**였다. 후속 계정 인증·댓글 읽기 결과는 위 Meta 연결 검증에 별도로 기록한다. Postiz는 사용자가 정한 추가 비용 없는 설치 준비 범위에서 멈췄으며 **새 VM 비용·구독·설치 0**, [정적 준비/가드 시험 10/10](../../../../../.tmp/social-workspace-live-20261013/postiz/README.md)만 확인했다. 이후 설치·계정 연결·채널별 첫 게시 및 공개 확인이 필요하다. 사이트는 공개 반영됐지만 유효한 추적 링크의 방문·동작 완료·서버 확인을 구분한 실제 흐름은 아직 확인하지 않았다. 문의는 현재 mailto 흐름에 실제 전송 완료 지점이 없어 미연결이다. Google 동의 후 다른 제품으로 바로 복귀해 중앙 계정 조회가 없으면 브라우저 가입 신고만 있고 서버 확인 가입은 없을 수 있다. 한 종류의 관측을 다른 종류의 실측 0으로 대신하지 않는다.

화면: [320px 업무 등록](../../../../_ops/qa/social-workspace-launch-20261014/launch-followup-submit-320.png) · [실제 업무 상세](../../../../_ops/qa/social-workspace-launch-20261014/launch-task-detail-1440.png) · [기존 오늘 할 일](../../../../_ops/qa/social-workspace-launch-20261014/launch-today-work-1440.png) · [문의 원문 복귀](../../../../_ops/qa/social-workspace-launch-20261014/launch-source-return-390.png) · [첫 사용 설정](../../../../_ops/qa/social-workspace-launch-20261014/launch-setup-1440.png).

<a id="sns-workspace-four-20261013"></a>
## 연결 점검·예약 분산·댓글 답장·문구 비교 · 2026-10-13 로컬 검증

[후속 네 기능](WORKSPACE.md#sns-workspace-four-20261013)을 기존 9개 화면에 연결했다. 아래 통합 시험·최종 검증 파일은 2026-10-13 구현 당시의 기록이며 브라우저 기록은 2026-10-14 현재 UI로 재실행했다. 임시 SQLite, 합성 계정, 가짜 Postiz·Meta 응답, 실제 HTTP 서버와 Chromium으로 검증했으며 실제 SNS 계정 연결·댓글 발송·공개 게시·유료 호출·운영 배포 결과가 아니다. 최신 추가 범위는 [실사용 연결 준비 검증](#sns-workspace-launch-20261014)을 따른다.

- **통합 시험:** SNS 전체와 알림·예약 실행·주간 정리·탐색·백업 회귀 30개 파일 **407/407**, 실패·취소·건너뜀 0. [TAP 원본](../../../../_ops/qa/social-workspace-four-20261013/integration-tests.tap). 외부 네트워크를 차단하고 loopback 요청만 허용했다. 별도 클라이언트·탐색 **82/82** 및 담당별 시험은 이 통합 범위와 겹치므로 합산하지 않는다.
- **실제 화면:** 9개 메뉴와 네 추가 흐름 **125/125**, 1440·390·320px 캡처 **60장**. [브라우저 기록](../../../../_ops/qa/social-workspace-four-20261013/report.json)의 예외·콘솔/CSP·자산·SNS API 오류·외부 요청은 모두 0이다. 실행 전후 UI 5파일 해시가 일치했고, root가 현재 파일도 다시 대조했다. 브라우저·임시 서버 종료와 시험 데이터 정리를 확인했다. 실물 휴대폰·실제 Meta 로그인별 인수 결과는 아니다.
- **댓글 답장:** 발신 계정·권한·원댓글과 소유 게시물·최종 문구를 확인한 미리보기만 전송한다. 동시 확인 버튼/서로 다른 문구/새 중복 키, 세션·계정 세대 변경, 만료, 수정·삭제·수동 기록·중첩 답글, 원댓글 작성자가 바뀐 경우를 확인했다. 합성 POST 후 응답 유실은 unknown으로 보존하고 원댓글 단위 재전송을 막는다. 실제 답장 식별자 조회에서 계정·부모 댓글·게시물·최종 문구를 대조한 뒤 원장을 복구하며 새 POST는 만들지 않는다. 전송 후 초안 수정에도 실제 전송 이력이 보존된다.
- **화면 경합 보완:** 전송 응답을 잃었을 때 로컬 대기를 정확한 attempt ID에 묶어 서버 기록으로만 해제한다. 이전 전송 성공 이력을 보고 새 미확인 요청을 해제하지 않는다. 원댓글 revision이나 답장 권한이 바뀌면 이전 최종 확인창을 폐기하며 초안은 보존한다. 독립 VM 재현에서 해당 상태의 전송 요청 0회를 확인했다.
- **문구 비교:** 불변 발행 원문, 동일 조건, 출처·단위·관측 지연, 실제 0·미확인·미지원·표본 부족, 중복 공개 주소와 충돌 원문을 확인했다. 같은 원본의 문구가 자체 추적 링크와 게시별 copy ID만 달라진 경우 3개 유효 표본으로 묶이고 실제 문구·목적지·UTM 차이는 나뉜다. 개별 발행 원문과 정확한 해시는 따로 남는다. 한국시간 날짜 경계, 24/72시간 창 미완료·90일 보존 경계, 게시 전후 사건, 재사용 링크, 브라우저 신고와 HMAC 서버 확인의 구분도 시험했다. 관측 데이터는 합성이며 실제 문구의 우열·전환 향상을 의미하지 않는다.
- **운영 점검·예약:** Postiz API와 계정 목록, Meta 계정 식별, 오래된 관측, 연결 세대 변경, 429 대기, 미점검 우선 순환을 확인했다. 예약은 한 시간 경계를 가로질러 호출량을 계산하고 개별 선택한 정시 예약만 움직인다. 독립 검토에서 뒤 예약이 만료 때문에 이동되지 않을 때 앞 분산안이 다시 과밀해지는 반례를 찾아, 최종 전체 배치 재검사로 적용을 차단했다. 미리보기 만료·권한 회수·예약/예산 변경과 중복 적용도 확인했다.
- **보존·반영 범위:** 기존 SQLite 전체 백업에서 점검·예약 미리보기·답장 원장과 중복 방지 기록을 복원했다. [현재 원문 해시와 최종 결과](../../../../_ops/qa/social-workspace-four-20261013/final-verification.json)를 보존한다. 아래 여섯 기능의 과거 동결 후보는 그대로 두었으며 이번 네 기능으로 다시 만든 배포 후보가 아니다. 다음 운영 반영 때 현재 부모 확인·새 후보 준비·Linux 인수·실제 계정별 시험이 필요하다.

화면: [모바일 답장 최종 확인](../../../../_ops/qa/social-workspace-four-20261013/reply-confirm-390.png) · [모바일 문구 비교](../../../../_ops/qa/social-workspace-four-20261013/copy-comparison-320.png) · [24시간 상담 비교](../../../../_ops/qa/social-workspace-four-20261013/copy-inquiry-window-1440.png).

<a id="sns-workspace-six-20261013"></a>
## SNS 후속 여섯 기능 · 2026-10-13 로컬 검증

[자동저장·템플릿·대량 작업·고객 검토·반복 편성·전환 연결](WORKSPACE.md#sns-workspace-six-20261013)을 기존 SNS·마케팅 9개 화면에 추가했다. 이번 결과는 임시 DB·합성 계정·가짜 제공자·실제 로컬 HTTP/Chromium으로 확인한 개발본이다. 운영 서버 반영, 외부 서비스 가입·계정 연결, 실제 SNS 공개 게시, 실제 고객 발송, 운영 사이트의 전환 계측, 유료 AI 호출은 실행하지 않았다.

- **최종 통합 시험:** SNS 서비스·클라이언트·HTTP·제공자·백업 및 관련 알림·예약·주간 정리·탐색 회귀 25개 파일 **335/335**, 실패·취소·건너뜀 0. [integration-tests.tap](../../../../_ops/qa/social-workspace-six-20261013/integration-tests.tap). 별도 [클라이언트·탐색 69/69](../../../../_ops/qa/social-workspace-six-20261013/client-tests.tap)와 복구 독립 재현 7/7은 같은 범위의 반복 확인이므로 합산하지 않는다.
- **최종 실제 브라우저:** 2026-10-13 16:32 KST 시작 실행에서 **129/129**, 9개 화면의 1440·390·320px 캡처 **57장**. [report.json](../../../../_ops/qa/social-workspace-six-20261013/report.json)의 예외·콘솔/CSP·자산·SNS API 오류 및 외부 요청은 모두 0이며, 의도한 오프라인 요청 취소 1건은 별도로 기록했다. 브라우저·회사 서버·도착 사이트 서버 종료와 임시 데이터 제거를 확인했다. 실물 휴대폰·다른 브라우저·공개 SNS 검증은 아니다. 최종 `public/social-workspace.js` SHA-256은 `75d20b6f648f1d3217ad92af45dd35dd75dbff99476a21ba79ea6301eee90153`이다.
- **복구·권한:** 원고 자동저장은 정식 저장·승인과 분리한다. 서버 복구본은 암호화하고 기기 복구본은 사용자·워크스페이스별로 나눈다. 로컬에만 있는 원고도 표시 전과 복구 클릭 때 서버에서 현재 계정·원본·파일 권한을 다시 확인한다. 충돌 후 늦은 조회, 계정 전환, 같은 사용자로 다른 워크스페이스 연결, 늦은 자동저장 응답을 재현했다. 권한이 회수된 원문의 노출과 이전 워크스페이스 편집 화면이 남는 문제를 수정했다. 정상 저장은 진행 중인 자동저장을 기다린 뒤 해당 복구본을 정리한다.
- **템플릿·대량 편성:** 템플릿 적용, 공통 문구 수정, 검토 요청, 승인, 일정 예약은 각각 미리보기와 명시적 적용을 거친다. 미리보기 DB·승인 기록 rollback, 최신 버전/원본/미디어 재검사, 잘못된 행 제외 선택, 중복 적용, 비동기 준비 중 세션·권한 철회, 카테고리 비중과 슬롯 점유·최소 재게시 간격을 확인했다. 승인한 대체 문구 전체와 실제 발행 문구를 보존한다.
- **고객 검토:** 회사 로그인 없이 해당 원고·계정·파일·일정만 열고 의견·승인·수정 요청을 남기는 전용 화면을 확인했다. 토큰은 해시만 저장하고 원본·연결·일정 변경 또는 폐기된 링크는 옛 버전으로 복구되지 않는다. 필수 검토 대기 중에는 실제 전송하지 않는다. 링크 만료와 받은 승인 효력을 구분하여 10월 13일 승인·16일 링크 만료·21일 예약의 같은 버전은 정상 발행하고, 만료된 링크의 열람·응답·파일 요청은 거절한다. 검토자 이름은 본인 인증이 아니다.
- **전환 기록:** 서로 다른 두 loopback origin에서 추적 링크 클릭→리디렉션→SDK 방문/체험/가입 신고와 HMAC으로 서명한 서버 확인 가입을 별도로 확인했다. 링크 클릭과 실제 방문은 다르며 브라우저 신고를 서버 확인으로 승격하지 않는다. 미연결 서버 수치를 0으로 표시하던 UI를 수정했고, 미확인·실측 0·실측 1을 구분한다. 정확한 출처, 재전송, 변조 서명, 기간 만료, 추가 개인정보 필드 거절을 시험했다. 예시는 합성 사건이며 실제 가입 효과가 아니다.
- **종료·백업:** 공개 요청 본문 수신 중 종료/취소하면 새 기록을 저장하지 않는다. 이미 저장된 고객 응답은 같은 요청 재시도에도 중복되지 않는다. 기존 백업에서 미디어·예약·템플릿·편성·검토·익명 추적 기록, 암호화된 복구 원문과 서명 키를 복원했다.
- **동결한 로컬 후보:** `.tmp/social-workspace-six-20261013/runs/20261013073453340-0c6e6a4d/`, manifest `2190c7c39f52ad1f34aa1e3a35f4f4511e36d8e76cded18e74ef2dae62c0216e`. source 947·image payload 550, SNS 전용 18·공유 실행 7파일이며 기준 로그인 후보의 나머지 900파일을 보존하고 무관한 공유 변경 3개를 제외했다. 후보 내부 25개 시험 파일도 **335/335**, Windows Node 24.18.0에서 통과했다. 준비→현재 원문 대조→후보 시험→최종 원문 대조까지 확인했으며 위 통합 시험과 겹치므로 합산하지 않는다. [최종 무결성](../../../../../.tmp/social-workspace-six-20261013/runs/20261013073453340-0c6e6a4d/final-local-verification.json) · [후보 시험](../../../../../.tmp/social-workspace-six-20261013/runs/20261013073453340-0c6e6a4d/qa/20261013073547533/result.json). 이전 SNS 후보와 증거는 보존했다. Linux 이미지 빌드·인수·운영 반영은 하지 않았으며 실제 후속 릴리스 때 현재 운영 부모부터 확인한다. [준비 범위](../../../../../.tmp/social-workspace-six-20261013/README.md).

화면 예시: [일괄 수정 미리보기](../../../../_ops/qa/social-workspace-six-20261013/bulk-edit-preview-1440.png) · [모바일 템플릿](../../../../_ops/qa/social-workspace-six-20261013/templates-390.png) · [고객 검토](../../../../_ops/qa/social-workspace-six-20261013/customer-public-review-390.png) · [서버 연결 전 미확인](../../../../_ops/qa/social-workspace-six-20261013/tracking-results-1440.png) · [서버 확인 가입 분리](../../../../_ops/qa/social-workspace-six-20261013/tracking-results-verified-1440.png).

<a id="sns-workspace-20261013"></a>
## SNS·마케팅 통합 메뉴 · 2026-10-13 로컬 검증

회사 공통 사이드바의 `SNS·마케팅`과 `/?tab=social` 아래에 9개 화면을 연결했다. [구현 범위와 연결 조건](WORKSPACE.md#sns-workspace-implementation-20261013)을 따른다. 외부 서비스를 아직 사용하지 않는다는 답변에 맞춰 계정 연결 없이 초안·승인·일정 계획·수동 인계가 가능하다. 현재 결과는 로컬 구현이며 운영 반영·실제 SNS 연결/게시·유료 AI 호출 결과가 아니다.

- **최종 통합 시험:** SNS 서비스·실제 HTTP·제공자 계약·원본 배포 규칙·AI 비용/중복 처리·백업 복원과 기존 주간 정리/알림/예약/탐색 회귀 19개 파일의 **253/253**, 실패·취소·건너뜀 0. 원본은 [integration-tests.tap](../../../../_ops/qa/social-workspace-20261013/integration-tests.tap)이다. 별도 [클라이언트·탐색 51/51](../../../../_ops/qa/social-workspace-20261013/client-navigation-tests.tap)은 통합 시험과 겹치므로 합산하지 않는다.
- **최종 실제 브라우저:** 15:15:50 KST 격리 회사 HTTP 서버·임시 SQLite·Chromium에서 **97/97**을 통과했다. 1440·390·320px의 화면 43장과 [report.json](../../../../_ops/qa/social-workspace-20261013/report.json)을 남겼다. 브라우저 예외·콘솔/CSP·정적 자산·SNS API 오류·외부 요청은 모두 0이다. 실제 마우스 dragstart/drop→정시 예약 한 건의 전후 비교→명시 적용, 모바일 날짜 입력, 색과 숫자가 다른 640×640/640×960 캐러셀 이동, 세로/가로/텍스트 미리보기, 실제 클립보드 내용·승인 파일 SHA-256 동일 다운로드·수동 주소/시각 기록을 확인했다. 임시 브라우저·서버를 종료하고 테스트 데이터를 제거했다. 실물 휴대폰 검증은 아니다.
- **검토에서 고친 문제:** 미리보기 inline style의 CSP 차단을 정적 CSS와 원본 비율 처리로 수정했다. 게시 형식 변경 때 이전 성과 분류가 남지 않게 했고, 신규 기본 형식·CSV·규칙에서도 YouTube 영상/Shorts·Instagram 릴스의 성과 형식을 정규화했다. 현재 발행 권한이 없는 사용자의 수동 인계 화면에 로컬 파일 주소가 원격 링크로 노출되던 분기를 막았다. 독립 재현과 최종 통합 시험에 반례를 포함했다.
- **게시 정확성:** 승인 버전·계정·예약별 중복 식별, 재시작/겹친 실행, 부분 성공, 결과 불명확 시 조회, 5분 이상 지난 일정의 확인 대기, 중단·권한 철회, 비동기 파일 준비 뒤 변경 감지를 시험했다. 공개 주소의 HTTP 확인과 사람이 실제 화면을 확인한 기록은 별개다. 느린 원본/댓글 수집 때문에 다음 발행 실행이 지연되지 않으며 종료·대기 함수는 현재 진행 작업까지 기다린다.
- **수동 인계·파일:** 승인 당시 문구·제목·파일을 고정하고 현재 초안으로 대체하지 않는다. GET/HEAD 다운로드에서 현재 세션/계정 권한·원래 담당자·현재 원본 승인·SHA-256을 확인한다. 승인 파일 변경·권한 철회·원본 변경 반례를 포함하며, 원격 미디어 주소는 자동 다운로드하지 않는다.
- **원본·백업:** 제작실/게시 묶음/PULSE의 현재 확정 원본에서만 규칙별 초안을 만들고 중복 이벤트와 오래된 버전을 막는다. 고장 난 원본은 다른 정상 원본 처리를 막지 않는다. SNS 미디어·예약·규칙·암호화된 제공자 설정을 기존 백업에서 같은 키로 복원하는 시험을 포함했다.
- **외부 호출 범위:** 제공자·Meta·AI는 모두 가짜 응답 또는 로컬 HTTP로 검증했다. 실제 서비스 가입·키 설정·자동 게시·댓글 수집·유료 AI 요청을 실행하지 않았다. TikTok은 수동 마무리이며 댓글 자동 읽기는 권한을 연결한 Instagram/Facebook Pages 범위다. 실제 제공자 계정과 권한 심사 결과는 별도 확인해야 한다.
- **동결한 로컬 후보:** `.tmp/social-workspace-20261013/runs/20261013061633147-74f678d7/`의 manifest `fb4ee2e4fa464a9e605bd2394852326be9e1def8ac21ce04b883891c70bfc576`. 로그인 3판 후보를 기준으로 SNS 실행 파일 9개와 검토한 공유 실행 7파일의 변경만 적용했다. source 931·image payload 541개이며 기준의 나머지 900파일은 같다. 공유 시험 4파일도 SNS 변경만 반영했고 무관한 변경 3개는 제외했다. 정확한 파일/해시·문법·현재 작업본 대조와 후보 자체의 **18개 시험 파일 249/249**가 Windows Node 24.18.0에서 통과했다. 이 시험은 위 통합 검증과 겹치며 합산하지 않는다. [무결성 결과](../../../../../.tmp/social-workspace-20261013/runs/20261013061633147-74f678d7/verification.json) · [후보 시험 결과](../../../../../.tmp/social-workspace-20261013/runs/20261013061633147-74f678d7/qa/20261013061731638/result.json).
- **남은 운영 확인:** Linux 이미지 빌드·인수·운영 반영은 하지 않았다. 다른 채팅에서 진행한 로그인 3판의 실제 운영 릴리스·이미지를 확인한 뒤 SNS 단독 후속 릴리스를 준비해야 한다. 기존 로그인 전용 배포 도구에 SNS를 섞어 실행하지 않는다. 실제 계정 연결 뒤 해당 SNS의 허용 형식·공개 게시·댓글 권한도 별도로 확인한다. [준비 도구와 범위](../../../../../.tmp/social-workspace-20261013/README.md)를 따른다.

화면 예시: [운영 현황](../../../../_ops/qa/social-workspace-20261013/overview-1440.png) · [모바일 날짜 변경](../../../../_ops/qa/social-workspace-20261013/calendar-move-390.png) · [캐러셀 미리보기](../../../../_ops/qa/social-workspace-20261013/preview-carousel-1440.png) · [수동 인계](../../../../_ops/qa/social-workspace-20261013/manual-handoff-1440.png).

<a id="server-latency-20261013"></a>
## 서버 접속 지연·반복 조회 수정 — 2026-10-13

공개 프록시의 HTTP/3 안내를 실제 TCP 연결 구성에 맞게 수정하고, 이전 브라우저 안내를 지우는 응답을 추가했다. 운영 릴리스 `e6ecc48f0992…`·이미지 `84512a28d8f2…`는13:55:37 KST 반영 확인을 마쳤다. HTTP/1.1·HTTP/2의 공개6검사가 모두 통과했다. 14:23:02 KST 새 백업·격리 복원·18.35분/18표본/3지역 정상 관측을 거쳐 HA `armed=true`·A epoch7 단일 writer·B 대기·복제 healthy를 최종 확인했다. 원키·계정/세션9표와 토큰7→7 보존, 임시 SSH 허용 복원도 통과했다. 새 강제 장애 전환 시험은 수행하지 않았다. [서버 원문](CLOUD-OPERATIONS.md#server-latency-20261013)과 [최종 운영 증거](../../../../../verification/server-latency-20261013/final-operation.json)를 따른다.

작업실 게시 기록·알림의 반복 조회를 줄이고, 링크 점검은25개마다 다른 요청과 취소 처리를 허용하되 현재 원문·권한을 다시 확인한다. HA 상태 GET은 기존 총시간 한도 안에서만 재시도한다. 현재 격리 브랜치의 앱3시험파일·HA3시험파일 합계129개가 실패·건너뜀0으로 통과했다. 게시400개 합성 점검은20,999.85→42.98ms, 같은 시험의 이벤트 루프 지연은21,004.69→13.86ms였다. 당시 운영의 게시0개·프로젝트5개에서21초가 재현됐다는 뜻은 아니다.

전후 공개 표본은 각각120개·오류0이며 중앙값26.22→28.59ms, 최대222.96→615.06ms였다. 지연 속도 개선을 주장하지 않는다. 과거8,033ms Node fetch 시간초과는 상세 단계 기록이 없어 원인 미확정이며 이번 HTTP/3 설정 오류와 인과관계가 입증되지 않았다. [검증·한계·원시 결과](../../../../../verification/server-latency-20261013/README.md)에 구분해 남겼다. 아래 기존 자동화·릴리스 시험 수치와 이번129개는 범위가 겹치므로 합산하지 않는다.

<a id="server-latency-prior-20261013"></a>
## 이전 서버 지연 수정과 운영 재검증 · 2026-10-13 13:25

작업실의 게시·성과·알림 반복 조회를 최적화하고 HA 상태 조회의 일시적 GET 오류를 기존 총시간 제한 안에서 재시도하도록 수정했다. 실제 운영 앱 `12aea0db4553…`·이미지 `73cd55624497…`와 세 호스트 node-agent `aaf76e2cdad3…`의 실행 대조가 통과했다. 400개 게시물을 넣은 합성 링크 점검은 20,999.85→42.98ms, 같은 시험의 이벤트 루프 지연은 21,004.69→13.86ms로 줄었다. 당시 운영 데이터는 성과 게시물 0개·프로젝트 5개였으므로 운영에서 21초 지연을 재현한 수치는 아니다. 근거는 `.tmp/server-latency-20261013/workroom-fix-verification.json`이다.

실제 Linux 시험은 앱 이미지의 운영 82개·호환 2개, HA 런타임 221개, 배포 절차 126개가 각각 통과했다. 최종 재활성화 후보는 `runtime-rearm/linux-qa-result-v4.json`의 Node 104개·Python 31개·배포 126개가 실패·건너뜀 없이 통과했다. 범위가 겹치므로 이 수치와 아래 기존 시험을 합산하지 않는다. 실제 GET 회복 로그, 최종 백업과 만료 세션만 정리한 격리 복원, 18.51분·18표본·3지역 정상 관측 및 13:25:05 KST 재활성화 후 확인은 [운영 기록](CLOUD-OPERATIONS.md#server-latency-prior-20261013)에 연결했다. 과거 토큰 14개와 현재 백업 9개의 차이는 원인 미증명으로 남기며, 이번 릴리스의 강제 장애 시험이나 모든 PC 접속 지연의 해소를 주장하지 않는다. 아래 자동화 기능별 검증과 이전 릴리스 인수는 당시 기록으로 보존한다.

<a id="workroom-production-20261013"></a>
## 작업실 자동화 운영 반영 · 2026-10-13

사용자의 전체 운영 반영 요청과 PULSE 배포 채팅 조정 승인에 따라, 로컬에서 검증한 1~35번 중 구현된 기능을 하나의 운영 릴리스로 반영했다. 사용자 제외 항목인 29·36번은 추가하지 않았다. 아래 각 기능의 ‘로컬 검증’은 당시의 시험 기록으로 보존하며, 현재 운영 반영 여부는 이 항목과 [운영 기록](CLOUD-OPERATIONS.md)을 따른다.

- **반영·실행 확인:** 운영 릴리스 `7b2ccbf0c170d117cb0543ffa66df2886cd9f19ef3becb57b54d5df972052303`, 실행 이미지 `8120a2016085a99ea4dd14e5e7dca40de1a52d9dd2ae2f0c53480d380b6049a1`. 최종 후보의 작업실 변경 47개 파일이 검증 원문과 모두 일치했다. 05:53 KST 독립 조회에서 실제 실행 컨테이너 healthy, 작업실 런타임 19/19 SHA-256 일치, 공개 정적 파일 5/5 바이트·MIME 일치, HTTPS health 200·ready=true, 보호 API 4개 비인증 401을 확인했다. 이는 단순 업로드나 준비 완료가 아닌 실행 중 운영 서버의 확인이다.
- **배포 후보 시험:** 최종 Linux 컨테이너의 운영 시험 3,202개, 백업 시험 20개, 호환 시험 2개가 모두 통과했다(합계 3,224, 실패·건너뜀 0). 이미지 내부 531개 파일 해시도 일치했다. 아래 Windows 로컬 3,599사례와 대상 범위가 다르므로 두 수치를 더하지 않는다. 원본 결과는 `.tmp/pulse-workspace-integration-20261013/rootqa/stage-progress-1791836813303.json`에 있다.
- **정기 점검:** 기존 `SYNK_COMPANY_BACKGROUND_JOBS_ENABLED=0`을 유지하고 `SYNK_COMPANY_WORKROOM_SCHEDULE_ENABLED=1`만 추가해 링크·주간 정리·자동화 상태 점검을 켰다. 관련 36/36 시험에서 기존 기본값·명시적 옵션·전체 점검 해제·유효하지 않은 설정과 실제 서버 기동 후 점검 시각을 확인했다. 이 36개는 다른 회귀 시험과 겹치므로 합산하지 않는다. 납품 파일 점검은 기존 별도 설정을 유지한다. PC 폴더 완성본 가져오기는 localhost 전용이며 운영 서버에서 PC 폴더를 읽지 않는다. 실SNS 성과 자동 수집은 계속 꺼짐이다.
- **데이터·권한 범위:** 기존 운영 데이터와 권한을 보존하는 통합 배포로 진행했다. 로컬 합성 프로젝트·검증 DB를 운영에 올리지 않았다. 이 채팅의 독립 검증은 읽기만 수행했으며, 고객 발송·SNS 게시·유료 AI 호출을 추가하지 않았다. 배포 채팅의 운영 화면 검증과 새 백업·격리 복구·HA 재활성화까지 확인해 마무리했다.
- **백업·복구·HA 최종 확인:** 새 원격 복구 사본 414,193,818바이트의 저장과 원본 대조를 완료하고, 같은 사본을 네트워크 없음·UID1000·공개 포트 없음으로 격리 복원·기동했다. 원키·계정 표 9개·새 소스·운영 설정 보존과 시험 컨테이너 정리를 확인했다. 첫 복원은 여유 공간 검사에서 중단됐고, 원격 원본과 검증 기록을 보존한 이전 임시 복원 사본만 정리한 뒤 통과했다. 최신 정상 관측 240.097초·5표본·3지역을 확인한 후 06:46:23 KST `armed=true`, A epoch7 단일 writer·B 대기·복제 정상·공개 HTTPS 200/ready를 확인했다. 새 controller invocation의 28.622초 관측에서 RECOVERED·재시작 0이다. 이번 릴리스에서 새 강제 장애·복귀 시험을 수행한 결과는 아니다. 원본은 `.tmp/pulse-workspace-integration-20261013/ha-compat/`의 `dr/backup-status-7b2-v5.json`, `dr/restore-7b2-v2.json`, `dr/binding-7b2-v1.json`, `natural-7b2-v6.json`, `arm-postcheck-7b2-v6.json`이며 [운영 기록](CLOUD-OPERATIONS.md#ha-current-20261012)을 함께 따른다.

- **로그인된 운영 화면:** 배포 채팅이 캡처한 실제 직원 화면에서 연결된 자동화 17개와 최근 점검 05:56 KST를 독립 대조했다. 꺼짐 2개는 24·72시간 성과 수집과 PC 폴더 완성본 자동 연결이며 위 설정 범위와 일치한다. 정상 점검 시각은 개별 프로젝트의 모든 업무가 완료됐다는 뜻이 아니다.
- **33번 실제 ZIP:** 운영 화면에서 내려받은 ZIP을 독립적으로 읽어 2개 항목의 CRC 무결성을 확인했다. 포함된 영상 1개(26,845,451바이트)는 원본·고객의 개별 다운로드와 SHA-256이 일치하며, 나머지 항목은 납품 안내다. 검증을 위해 ZIP을 다시 생성하거나 운영 데이터를 바꾸지 않았다. 배포 채팅의 내부 검증 프로젝트에서는 최종 수령 확인 후 새로고침 복원도 확인했다. 실제 고객의 수령이나 만족도로 확대하지 않는다.
- **35번 운영 읽기:** 기존 내부 검증 프로젝트에서 자료·최종본과 ‘이번 납품에 사용한 자료’ 영역이 열리고, 현재 납품 기준과 최종 파일·같은 원본 1개를 구분해 표시하는 것을 확인했다. 운영 사용 구분을 시험 목적으로 새로 저장하지 않았다. 실제 화면은 `production-material-usage.png`·`production-automation.png`다. 이번 운영 브라우저의 실제 폭은 825px이며 모바일 크기 재정의는 적용되지 않았다. 아래 로컬 390/320px 검증과 구분하고 실물 휴대폰 확인으로 표시하지 않는다.
- **관측한 운영 중단 이력:** 복원 검증 중 06:27과 06:33 KST에 HA 노드가 `reason=23`으로 보호 정지한 뒤 약 47초 만에 READY로 복구했다. 독립 저널은 06:33:17.484654→06:34:03.912952를 확인하며 `production-ha-transient.json`에 보존했다. 같은 시간의 내부·외부 감시 실패와 PC 접속 시간초과도 있어 PC만의 문제로 돌리지 않는다. 06:36:39 서버에서 공개 HTTPS 200·ready=true(403ms)를 확인했다. 요청 시간초과의 세부 API 원인은 해당 저널로 확정하지 못했다. 배포 후 무중단이나 시간초과 원인 수정 완료로 보고하지 않으며, HA 재활성화에는 마지막 비정상 표본 이후의 새 정상 관측을 사용한다.

독립 근거는 `verification/workroom-final-20261013/production-source-check.json`, `production-scheduler-tests.json`, `production-public-check.json`, `production-runtime-check.json`, `production-browser-check.json`, `production-delivery-zip-check.json`, `production-ha-acceptance.json`에 보존했다. 운영 입구는 [작업실 자동화 상태](https://workspace.synk.im/?tab=workroom&section=tools&tool=automation)다.

<a id="workroom-final-20261013"></a>
## 35. 사용 자료 구분과 작업실 전체 회귀·최적화 · 2026-10-13 로컬 마무리

35번만 기존 자료·사용 조건·오늘 할 일·자동화 상태에 연결하고, 지금까지 구현한 작업실 자동화와 공유 서버·메신저 시험을 실행했다. 29번과 36번은 추가하지 않았다. 격리 로컬 서버 `127.0.0.1:64046`에서 확인했으며 운영 배포·고객 발송·유료 AI 호출은 실행하지 않았다.

- **전체 회귀:** 기존 291개 시험 파일의 3,570사례 중 첫 실행 3,565통과·2실패·3건너뜀이었다. 실패 2개는 34번 추가 후에도 자동화 카드 16개를 기대하던 시험으로, 현재 17개와 권리 카드 존재를 검사하도록 고쳐 해당 6사례를 재실행해 통과했다. 최초 실패 로그는 보존했다. 신규 35번 서비스 10·HTTP 7·화면 12사례는 기존 실행 목록에 없으므로 중복 제외 최종 **294개 파일·3,599사례: 3,596통과, 미해결 실패 0, 건너뜀 3**이다. 전체 묶음을 다시 실행한 수치가 아니라 최초 전체 실행과 수정 후 관련 재검증을 합친 결과다.
- **건너뜀·범위:** 3개는 Windows 파일 심볼릭 링크 생성 권한 부족으로 실제 링크를 만들지 못한 검사다. 서비스의 경로·파일 검사 관련 나머지 시험은 실행했다. 배포·HA 전용 시험, 실제 Docker 빌드, 실물 휴대폰, 운영 서버·SNS 실게시·유료 AI는 범위 밖이다. 병행 작업의 로그인 디자인 변경은 보존했으며 이 기능 검증으로 별도 디자인 완료를 주장하지 않는다.
- **35번 저장·현재성:** 별도 암호화·현재 권한·Origin/CSRF·본문 크기·CAS 충돌·수신 도중 권한 변경·납품/자료 지문 변경·고객 화면 미노출·원문 보존·반복 저장·기록 한도·최종 파일 및 같은 원본의 사용함 고정을 검증했다. 새 묶음이나 바뀐 자료는 미정으로 재확인하며, 확인된 참고 자료만 34번 할 일에서 제외한다. 포트폴리오 조건은 유지한다.
- **발견한 표시 오류 수정:** 조회 전용 계정·보관 프로젝트에서 사용함인 원자료도 최종 납품 파일로 표시하던 P2를 수정했다. 실제 최종 파일 여부로 문구를 구분하고 원자료에는 변경 불가 이유를 표시한다. viewer·보관·실제 최종본·납품 없음 반례를 기존 화면 시험에 포함해 최종 12/12를 재검증했다. 독립 검토 근거는 `review-source.json`이다.
- **실제 화면:** 합성 프로젝트 `ce779b91-dcd0-420a-8fcf-e00973b783a9`에서 참고만 저장 시 할 일 **4→3**, 사용함·미정 변경 시 **4**, 참고만 복원 시 **3**을 확인했다. 새로고침 후 사용함1·참고만1·미정1과 최종 파일4 구분이 유지됐고 필터가 해당 자료만 표시했다. 메신저 할 일에서 정확한 이미지 사용 조건 article로 초점이 이동했다. 자동화 상태 17개·문제0·34번 대상8, 주간 정리·게시 묶음7·메신저 프로젝트 묶음 로딩을 확인했다. PC 기본825px·390px·320px에서 가로 넘침이 없고 구분 선택·저장이 보이며 콘솔 오류·경고는 0건이었다.
- **실제 ZIP 재검증:** 최적화된 서버에서 브라우저 버튼으로 ZIP을 내려받아 Windows Expand-Archive로 풀었다. 3개 실제 파일과 납품 안내·외부 링크 목록의 총5항목이며 영상·자막·이미지 SHA-256이 원본과 모두 일치했다. 외부 링크 파일을 가져오거나 고객 수령·마감을 처리하지 않았다.
- **최적화:** ZIP의 수동 JavaScript CRC 계산을 Node 내장 누적 CRC로 교체했다. 16MiB 합성 입력의 해당 계산 중앙값 **37.16ms→3.42ms**이며 전체 다운로드 속도나 PC 전체 성능 수치가 아니다. 스트리밍·크기/동시성 제한은 유지한다. 자료·사용 구분·권리 상태가 같은 자료를 중복 조립하던 경우를 기존 동기 조회 범위에 연결해 **한 조회 안 2회→1회**로 줄였고 다음 조회에서는 변경·권한을 즉시 다시 읽는 것을 시험했다. 새 타이머는 없다.
- **백업·패키징:** 신규 암호화 기록의 기존 키 백업복원, 서버 import 및 JS/CSS 포함을 확인했다. 최종 `usage-http-backup.log` 32/32(서비스10+HTTP7+백업/패키징15), 기존 UI 연결63/63·권리 회귀23/23·ZIP 회귀19통과/1건너뜀을 추가 확인했다. 위 최종 합계와 겹치므로 다시 합산하지 않는다. 격리 패키징 서버의 내부120검사도 별도 합산하지 않는다. 합성 예시를 만들 때 기존 프로젝트35개 해시 보존을 확인했다.

근거는 `verification/workroom-final-20261013/`의 `regression-final-result.json`, 원래 회귀 로그, 관련 재검증 로그, `review.json`, 다운로드 해시·브라우저 캡처·벤치마크다. 실제 고객 승인이나 사용 허락을 뜻하지 않는 로컬 합성 자료이며 운영 반영은 별도 요청 범위다.

<a id="client-archive-expiry-20261013"></a>
## 33·34. 최종 납품 ZIP과 사용기한 만료 예정 · 2026-10-13 로컬 검증

기존 프로젝트의 자료·최종본에 최종 파일 ZIP 준비·다운로드를, 등록된 사용 조건에 7일 전·당일·기간 경과 계산과 오늘 할 일·자동화 상태 연결을 추가했다. 기존 격리 로컬 서버 `127.0.0.1:64046`에서만 확인하며 운영 배포는 하지 않았다.

- **통합 시험:** `verification/client-archive-expiry-20261013/integration-tests.tap`의 96개 중 95개 통과·실패 0개·Windows 파일 심볼릭 링크 생성 권한이 없는 시험 1개 건너뜀. 건너뛴 항목을 통과로 계산하지 않는다. ZIP 서비스·HTTP, 권리 서비스·HTTP, 기존 자료·자동화 상태 회귀가 포함된다.
- **별도 검증 범위:** 관련 UI 시험 114/114, 패키징·회사/작업실/납품 백업 시험 15/15를 별도로 실행했다. 패키징 시험 내부의 복사된 파일만 사용하는 격리 서버 확인은 118개이며, 정적 파일 512개·서버 import 110개를 확인했다. 위 시험 묶음과 내부 확인 수는 서로 합산하지 않는다. Linux Docker 이미지 빌드·운영 배포 결과는 아니다.
- **실제 ZIP 다운로드:** 합성 프로젝트 `a83d24c0-1d9a-4738-b8c7-fe4bbf62ddf5`에서 브라우저 버튼으로 ZIP을 받고 Windows Expand-Archive로 풀었다. 영상·자막·이미지 원본 3개의 SHA-256이 모두 일치한다. ZIP은 이 3개와 납품 안내·외부 링크 목록의 총 5개 항목이며, 외부 링크 1개는 주소만 담는다. 근거는 `download-validation.json`이다. 기존 프로젝트 34개는 해시로 보존 확인했다.
- **권리 갱신·업무 연결:** 실제 권리 화면과 메신저 오늘 할 일의 대상 4건에서 한 자료를 기간 연장하면 3건으로 즉시 바뀌고 원래 날짜로 복원하면 4건으로 돌아왔다. 할 일의 **사용 조건 열기**를 누르면 해당 음악 자료의 정확한 article에 초점이 갔다. 자동화 상태의 연결 17개·34번 대상 5건(기존 합성 1+신규 4)·직접 확인 5건·문제 0건과 해당 예시 4건 표시를 확인했다. 서비스·HTTP 시험은 KST 7일 경계·당일 끝·다음 날 만료, 연장 뒤 할 일/자동화 상태 해제, 완료·보관 유지, 현재 소유·권한 변경, 숨김·삭제·교체·이전 자료 제외, 반복 조회의 중복·원문 변경 없음과 읽기 실패의 미확인 표시를 확인했다. 내부 확인 근거와 개인 초안은 업무 요약에 복사하지 않는다.
- **화면:** PC 1280px·CSS 390px·320px에서 페이지 가로 넘침이 없었다. 390px 권리 자료 카드, 320px 조건 편집 입력과 ZIP 3개 파일 준비를 확인했다. 기본 화면 폭 825px로 복원한 뒤에도 가로 넘침이 없고 마지막 브라우저 콘솔 오류·경고는 0건, 서버 health는 `ok:true, ready:true`였다. 근거는 `review.json`, `rights-from-task-1280.png`, `rights-390.png`, `rights-edit-320.png`, `zip-320.png`, `zip-1280.png`, `zip-final.png`다. 실물 휴대폰 확인은 아니다.
- **현재성·전송 경계:** ZIP 준비와 실제 전송에서 현재 직원 세션·CSRF·권한, 승인·납품 지문과 원본 파일 상태를 검사한다. `no-referrer` 정책으로 브라우저 기본 폼의 Origin이 `null`인 경우는 같은 출처 fetch metadata와 유효 세션·CSRF를 함께 확인하는 다운로드 경로로 처리했고 HTTP 회귀에 포함했다. 다른 출처를 허용하거나 기존 API의 일반 Origin 검사를 완화하지 않았다.
- **성능·보존:** ZIP은 파일 내용을 재압축하거나 통째로 버퍼에 담지 않고 스트림으로 보낸다. 100개/2GiB/동시 3개 한도를 적용하며 새 주기 타이머·외부 AI·외부 전송·자동 승인·수령·마감 처리는 없다. 권리 조건이 없는 프로젝트는 자료 목록을 조립하지 않고, 자동화 상태의 한 요청 안에서는 같은 권리 계산을 재사용한다. 암호화된 조건 기록·개인 재확인 날짜는 기존 전체 DB 백업에서 복구되는 것을 별도로 검증했다.

기능 근거·회귀 로그·다운로드 해시와 실제 화면은 `verification/client-archive-expiry-20261013/`에 두며 [브라우저 검증 요약](verification/client-archive-expiry-20261013/review.json)에서 범위를 확인한다. 로컬 예시는 `http://127.0.0.1:64046/?tab=workroom&section=clients&project=a83d24c0-1d9a-4738-b8c7-fe4bbf62ddf5&delivery=1`이다. 로컬 합성 상태를 실제 고객 승인·권리자 동의·실물 모바일 검증이나 운영 반영으로 해석하지 않는다.

<a id="client-completion-records-20261013"></a>
## 32. 프로젝트 완료 기록 PDF·CSV · 2026-10-13 로컬 검증

기존 수령 확인·마감 영역에 「완료 기록 모아 내려받기」를 연결했다. 명시적으로 준비·다운로드할 때 현재 저장 기록을 모으며 원문·개인 초안·고객 확인 상태는 변경하지 않는다.

- **시험:** 신규 서비스 17·렌더러 16·HTTP 14·UI 10개와 기존 마감·자료·사용 조건·프로젝트 화면·일정 UI 등을 포함한 기능 시험 194/194 통과. 패키징 3개 중 2개가 처음 실패해 원인을 수정했고, 해당 묶음 3/3 재실행을 통과했다. 서로 다른 최종 시험은 총 197개다. 전체 첫 실행과 수정 후 패키징 로그를 별도로 보존한다.
- **실제 다운로드:** 기존 격리 작업실에 합성 완료 프로젝트 1개를 추가했다. 현재 승인·최종 파일 1·수령 1·마감 1·처리된 고객 요청 2·처리된 장면 요청 1·사용 조건 3·조건 변경 이력 2를 준비해 실제 브라우저 버튼으로 PDF와 CSV를 내려받았다. 현재 포트폴리오 거절·철회와 과거 허용 이력을 구분하며 실제 고객 동의나 납품을 뜻하지 않는다.
- **PDF·CSV:** 실제 다운로드 PDF 6페이지를 모두 PNG로 렌더해 한글·줄바꿈·반복 머리말·페이지번호·여백을 직접 확인했다. 좌측 항목/우측 내용 배치로 같은 예시의 10페이지를 6페이지로 줄였다. PDF 추출 텍스트와 페이지 경계, CSV UTF-8 BOM·4열/134행의 파싱을 검사했다. CSV 수식 접두어는 작은따옴표로 보호한다. PDF 내장 폰트가 없는 문자는 코드로 명시하며 CSV에는 원래 문자를 유지한다. PDF/A나 암호화 PDF는 구현하지 않았다.
- **현재성·권한:** 직원 현재 열람 권한과 세션·역할·팀을 조회 시, 본문 수신 뒤, 렌더 후 다시 검사한다. 프로젝트 revision이 그대로여도 사용 조건만 바뀌면 지문 충돌로 파일을 보내지 않는다. 외부 주소·연락처 필드·내부 메모·처리 메모·개인 초안·초대/세션·파일 본문은 제외한다. 현재 승인본·납품 묶음·고객 확인이 바뀌면 과거 마감을 현재 완료로 표시하지 않는다.
- **성능·경계:** 새 주기 타이머가 없고 버튼을 누를 때만 실행한다. PDF는 별도 Worker에서 최대 2개, 기본 20초, 최대 250페이지/16MiB이며 CSV는 12MiB다. 준비 한도는 2,000행·전체 텍스트 100만 자·JSON 4MiB로 부분 문서를 만들지 않고 초과를 알린다. 긴 일반 영문에서 주소 제거 탐색이 느리던 경계를 보완했다. 실제 합성 보고서 PDF 생성 약 590ms, 동시에 보낸 health 5회 최대 19ms였으며 이 단일 로컬 예시 수치를 다른 프로젝트 성능으로 일반화하지 않는다.
- **화면:** PC 1280px·390px·320px에서 가로 넘침 없음, 모바일 버튼 높이 44px를 확인했다. 320px 화면에서도 PDF 다운로드를 완료했다. 화면 숨김·프로젝트/계정 전환의 늦은 응답은 버리고 재시도할 수 있으며 기존 입력과 초안은 건드리지 않는다. 최종 콘솔 오류·경고 0건. 실물 휴대폰 시험은 아니다.
- **보존·제공:** 기존 프로젝트 33개·납품 초안 5개·개인 날짜 1개·읽음 2개·개인 초안 9개·시작 양식 1개·개인 문구 1개·조건 문서 1개 모두 SHA-256으로 불변 확인. 합성 프로젝트와 그 조건 문서만 각 1개 추가했다. 다운로드 전후 8종 문서 해시도 동일하다. 제공되는 화면 파일 6개의 SHA-256은 현재 소스와 같다.
- **패키징:** PDFKit 고정 번들·SUIT·라이선스를 제품 내부에 넣고 Docker 복사 대상에 연결했다. 기존 `*-check.mjs` 제외 규칙 때문에 실제 납품/링크 점검 모듈이 빠지는 문제를 두 파일만 예외 허용해 수정했다. PULSE의 정상 `preview-view.mjs`를 로컬 실행기로 오판한 시험도 최상위 실행기만 검사하도록 고쳤다. 복사된 파일만 사용하는 격리 서버에서 PDF/CSV를 포함한 114개 확인과 import 그래프를 검증했다. Linux Docker 빌드나 운영 배포는 실행하지 않았다.

근거는 `verification/client-completion-records-20261013/`의 `benchmark.md`, `regression.txt`, `container-regression.txt`, `regression-summary.json`, `browser-checks.json`, `download-checks.json`, `live-checks.json`, `preservation.json`과 실제 내려받은 PDF/CSV·6장 PNG다. 로컬 주소는 `.tmp/workroom-publishing-20261011/completion-records-ready.json`이며 기존 `preview.mjs`와 같은 `preview-data`를 사용한다. 새 AI 호출·고객 발송·원본 영상 묶기·운영 반영은 없다.


<a id="client-replies-rights-20261012"></a>
## 30·31. 개인 답변 양식과 자료 사용 조건 · 2026-10-12 로컬 검증

기존 답변·메모/고객 진행 안내에 개인 문구 보관·재사용을, 프로젝트 자료·최종본에 「게시·공개 전 확인」을 연결했다. 29번 실제 작업시간 기록은 추가하지 않았다.

- **자동 시험:** 30번 서비스·HTTP 21/21, 신규 문구 UI 28개를 포함한 연결 UI 191/191, 31번 서비스 13·UI 17·HTTP 6와 기존 자료 40개를 묶은 76/76, 기존 관련 서비스/UI 123/123 통과했다. 실행 묶음끼리 겹치는 시험이 있으므로 단순 합산하지 않는다. 31번 최종 묶음에는 전체 index classic script 동시 컴파일, 다른 기능과의 전역·CSS 이름 충돌 방지, 최초 자료 이동의 지연 조회 재개가 포함된다.
- **개인 문구 실제 흐름:** 합성 고객 A에서 변수를 넣은 문구 보관 → 본문 검색 → 현재 이름·프로젝트·합의일 미리보기 → 기존 미전송 답변 뒤에 추가를 확인했다. 합의일이 없는 B에서 같은 개인 문구를 불러오면 현재 고객명으로 바뀌고 날짜 누락으로 삽입이 막힌다. 날짜 문장을 임시 편집해 삽입해도 저장 양식은 유지되며, 기존 진행 안내 뒤에도 문구가 추가되고 개인 초안에 보관된다. 고객 전송·프로젝트 원문 저장은 실행하지 않았다.
- **사용 조건 실제 흐름:** 자료별 범위·근거·확인일과 기간 제한 없음 저장, 과거 만료일 경고, 미확인 자료 구분, 현재 최종본의 담당자 동의 기록·철회와 이전 이력을 확인했다. 최종 예시는 자료 5개 중 허용 기록 1·기간 경과 1·미확인 3, 포트폴리오 거절·철회 기록이며 이력은 5개다. 모두 실제 고객이나 권리자의 동의가 아닌 명시된 로컬 합성 기록이다. 자료 위치 보기는 최신 기록을 확인한 뒤 해당 원본 카드에 초점을 보낸다.
- **권한·기록 경계:** 개인 문구와 내부 근거는 암호화 저장한다. 현재 담당자·역할·팀, CSRF/Origin, 요청 본문 수신 뒤 세션 변경, 저장 버전과 원본 식별 정보 변경, 한국 날짜 만료일 포함, 기록 이력 한도를 검증했다. 자료 교체·승인 철회·현재 최종 파일 누락에 이전 공개 동의를 승계하지 않는다. 등록한 파일 정보와 현재 납품 묶음을 대조하며 같은 외부 URL의 원격 바이트 변동은 감시하지 않는다. 조건 기록은 권리 판정이나 고객의 직접 승인을 대신하지 않는다.
- **발견·수정:** JSON 이스케이프가 많은 6,000자 문구의 잘못된 용량 거절, 충돌 복사 초안의 재선택 불가, 삭제 응답 중 새 입력 손실, 모바일 미리보기 뒤 검색란으로 초점이 돌아가던 문제를 수정했다. 최종 파일 부재에도 동의가 정상처럼 보이던 문제, 기존 creative-research와 새 전역/CSS 이름 충돌, 최초 자료 이동 때 부모 조회 중 요청이 빠지던 문제도 수정했다. 마지막 실제 전체 화면 콘솔 오류·경고는 0건이다.
- **PC·모바일:** PC와 CSS 390/320px에서 입력·조회·미리보기와 버튼을 확인했고 가로 넘침이 없었다. 문구 미리보기 성공 시 결과 영역에 초점이 가며, 320px 조건 저장/닫기 버튼은 전체 폭 세로 배치로 높이 44px 이상이다. 실물 휴대폰 검증은 아니다. `browser-checks.json`과 `replies-desktop.png`, `replies-mobile-390.png`, `replies-mobile-320.png`, `rights-desktop.png`, `rights-mobile-390.png`, `rights-mobile-320.png`가 근거다.
- **재시작·제공·보존:** 로컬 서버 재시작 후 개인 문구와 자료 조건이 유지됐다. 제공 파일 9개의 SHA-256이 현재 소스와 같고 API 조회/미리보기 전후 8종 업무 문서 해시도 같았다. 원래 프로젝트 31개·납품 초안 5개·개인 날짜 1개·읽음 2개·개인 초안 6개·시작 양식 1개를 모두 보존했다. 합성 프로젝트 2개, 그 개인 초안 3개, 개인 문구 1개, 사용 조건 문서 1개만 추가했다. 새 예약 타이머·외부 AI·외부 발송·공개·운영 배포는 없다.

근거는 `verification/client-replies-rights-20261012/`의 벤치마킹·권리/관련 회귀·API·브라우저·보존 기록과 `verification/client-reply-templates-20261012/`의 backend/frontend 회귀 결과다. 로컬 예시의 비밀값 없는 프로젝트 주소는 `.tmp/workroom-publishing-20261011/replies-rights-ready.json`의 `projects[].url`로 확인하며 로그인 시작 토큰은 공유하지 않는다. 실행기는 기존 `preview.mjs`, 데이터는 기존 격리 `preview-data`를 그대로 사용한다.

<a id="client-search-20261012"></a>
## 28. 프로젝트 통합검색 · 2026-10-12 로컬 검증

기존 상단 검색과 `Ctrl+K`, 고객 프로젝트·자료 라이브러리에 통합검색을 연결했다. 현재 열람할 수 있는 프로젝트의 저장된 프로젝트 기록·메모·메시지·장면 의견·파일 이름/연결 제목·납품 안내를 검색하고 프로젝트와 자료 종류로 좁힌다. 기존 채널·메뉴 찾기도 같은 창에 유지한다. 29번 실제 작업 시간 기록은 사용자의 요청에 따라 추가하지 않았다.

- **자동 시험:** 서비스·HTTP·기존 프로젝트 회귀 52/52, 검색·자료·단계 화면·새 소식·초안·진행 안내 UI 회귀 147/147, PULSE 이력 타깃·기존 초대 내비게이션 17/17 통과했다. 별도 `record=1` 계약 재검증 19개는 앞의 backend 시험과 겹치므로 합산하지 않는다.
- **권한·원문:** 전용 읽기 POST에서 로그인·Origin·CSRF와 요청 본문 수신 뒤의 현재 권한을 다시 확인한다. 개인 초안·삭제/비공개 자료·현재 대상이 없는 과거 자료는 제외하고, 파일 본문이나 외부 웹페이지는 읽지 않는다. 검색어는 주소/조회 이력에 저장하지 않으며 인덱스·예약 작업·AI 호출을 추가하지 않았다. 실제 원문 클릭 직전에도 현재 검색 결과를 다시 확인한다.
- **실제 화면:** 한글 1글자 안내, 결과 없음, 전체/프로젝트/종류 필터, 20건+11건 페이지 이동과 중복 없음, Escape/`Ctrl+K`, 기존 메뉴 찾기를 확인했다. 문의·내부 메모·자료·납품 안내는 작업실의 해당 원문을 열고, 프로젝트 검색만 `record=1`로 기록 영역을 펼친다. 일반 프로젝트 진입의 기존 위치는 유지한다. 개인 미전송 글은 검색되지 않으며 검색창을 열고 닫아도 작성 중인 입력이 남았다.
- **발견한 문제와 수정:** 장면 화면에 최근 3개만 보이는 오래된 의견은 전체 PULSE 이력의 정확한 기록 ID로 열도록 보완했다. 4개 의견 중 첫 의견을 검색해 새 창에서 원문과 초점을 확인했다. 문의 이동 뒤 위쪽 새 소식·개인 초안이 늦게 그려지면 위치가 밀리던 문제도 실제 화면에서 재현했다. 두 비동기 paint 뒤 활성 원문 위치를 확인하도록 연결했고, 사용자가 직접 스크롤/입력하면 자동 위치 보정을 멈춘다. 후행 카드 갱신 후 문의 위치가 화면 밖에서 top 약 377px로 돌아오는 것을 확인했다. 임시 진단 로그는 제거했다.
- **PC·모바일:** PC와 CSS 390/320px 반응형에서 검색·필터·원문 버튼을 확인했고 가로 넘침은 없었다. 검색 전환과 필터는 44px 이상이다. 실물 휴대폰 검증은 아니다. 실제 캡처와 검사 기록은 `desktop.png`, `mobile-390.png`, `mobile-320.png`, `old-review-original.png`, `browser-checks.json`에 보관한다.
- **제공·부하·보존:** 제공된 12개 파일의 SHA-256이 현재 소스와 같고, 검색 API 조회 전후 업무 문서 해시가 같았다. 프로젝트 31개인 합성 로컬 작업실에서 전체 검색 3회는 약 13.34~32.09ms, 응답은 각 12,087바이트였다. 단일 기기의 소수 표본으로 운영 성능 보장은 아니다. 원래 프로젝트 30개·납품 초안 5개·개인 다시 확인 날짜 1개·읽음 기록 2개·개인 초안 5개·시작 양식 1개를 모두 보존했다. 로컬 예시 프로젝트 1개와 그 입력 보존 시험용 개인 초안 1개만 추가됐다.

근거는 `verification/client-search-20261012/`의 `benchmark.md`, `backend-regression.json/.txt`, `frontend-regression.json/.txt`, PULSE 시험 결과, `local-api-checks.json`, `source-before.json`, `source-after.json`, `preservation.json`과 화면 캡처다. 운영 배포·외부 고객 발송은 하지 않았다.

<a id="client-deadline-overlaps-20261012"></a>
## 27. 여러 프로젝트의 기한 겹침 · 2026-10-12 로컬 검증

기존 `/api/client-workflow`가 한 번 읽은 현재 권한의 프로젝트 자료로 날짜별 겹침을 계산한다. 한국 시간 오늘부터 30일 뒤까지 양 끝 날짜를 포함하고, 서로 다른 프로젝트 2개 이상인 날만 표시한다. `buildClientSchedule`의 현재 완료·대기 상태와 원문 주소를 재사용하며 합의일·내부 목표일·확인 점검일을 구분한다.

- **자동 시험:** 순수 계산 14개·서비스 5개, 전용 HTTP 6개, 신규 UI 10개 통과. UI와 기존 오늘 할 일 회귀 묶음 95개, 계산/서비스와 기존 workflow·다시 확인 날짜·프로젝트 묶음 회귀 47개도 통과했다. 각 실행은 겹치는 시험을 포함하므로 합산한 고유 시험 수가 아니다. 25~27번 backend 통합 90개 결과도 별도로 보존한다.
- **경계:** 같은 프로젝트의 여러 기한 제외, 같은 이름·다른 프로젝트 구분, 한국 날짜 자정과 윤년/연말, 완료·보관·마감·일정 점검 꺼짐 제외, 과거 승인·납품이 새 시안의 기한을 숨기지 않는지, 현재 계정/팀/담당·검토 권한 반영을 확인했다. 날짜 미입력·기한 경과·기간 이후·조회 실패를 ‘겹침 없음’과 구분한다.
- **연결·부하:** 기존 조회에서 프로젝트 projection은 한 번만 읽는다. 새 HTTP 요청·타이머·AI 호출·할 일 저장이 없고, 단순 확인 시 프로젝트/초안/개인 기록은 변경하지 않는다. 5,000개 합성 projection의 계산도 확인했으나 운영 성능 보장은 아니다. 오늘 처리할 할 일 수에 기한 겹침을 더하지 않으며, 확인 시각만 바뀌면 DOM을 다시 만들지 않는다.
- **원문·표시:** workroom 원문은 기존 호스트 이동 경로, PULSE 시안·기획 원문은 검증된 동일 출처 링크를 사용한다. 오래된 세션 응답 차단, 잘못된 원문 링크·중복 데이터 거절, 제목 이스케이프와 실패 후 이전 목록 제거를 시험했다. 독립 UI 검토에서 추가 실제 결함은 발견하지 못했다.
- **실제 화면:** 26번의 두 합성 프로젝트에 합의한 전달일 10월 26일을 저장했다. 기존 예시를 포함한 겹침 5일·프로젝트 6개와 26일의 프로젝트 4개/기한 5개를 확인했고, 고객 합의 기한과 내부 목표일은 별도 유형으로 표시됐다. 한 프로젝트의 합의일을 27일로 옮기자 26일이 3개/4개로 줄었고, 원문 링크는 해당 프로젝트의 일정 카드를 펼쳤다. 최종 예시는 다시 26일로 두었다.
- **PC·모바일:** 390/320px에서 가로 넘침이 없고, 작았던 원문 링크를 최소 44px로 넓혔다. 최종 브라우저 오류·경고는 0건이다. 화면/갱신/이동 근거는 `browser-checks.json`, `desktop-overview.png`, `desktop.png`, `mobile-390.png`, `mobile-320.png`에 보관한다.
- **제공 파일·보존:** 최종 제공 파일 11개의 SHA-256이 현재 소스와 일치했다. 기존 업무 조회 3회는 약 32.10~45.61ms, 각 148,959바이트였고 조회 전후 프로젝트·초안·개인 기록·양식 해시는 같았다. 이 기기의 단일 로컬 표본이며 운영 부하 시험은 아니다. 원래 프로젝트 27개·납품 초안 5개·개인 날짜 1개·읽음 기록 2개를 모두 보존하고 합성 프로젝트 3개만 추가했다. 근거는 `verification/workroom-25-27-20261012/served-source.json`과 `source-after.json`이다.

근거: [독립 모듈·서비스 19개](verification/client-deadline-overlaps-20261012/test-result.json), [연결·회귀 결과](verification/client-deadline-overlaps-20261012/integration-result.json), [정규화된 실행 요약](verification/client-deadline-overlaps-20261012/integration-summary.txt), [25~27 backend 통합](verification/workroom-25-27-20261012/backend-regression.json), [기능별 선정 근거와 검증 목표](verification/client-drafts-20261012/benchmark.md). 실제 고객 효과 측정과 운영 배포는 수행하지 않았다.

<a id="client-startup-templates-20261012"></a>
## 26. 내 프로젝트 시작 양식 · 2026-10-12 로컬 검증

기존 제작 시작 설정에 개인 암호화 양식을 연결했다. 필수 자료 이름·필수 여부, 날짜 간격, 확인 기간, 납품 규격만 보관하며 기존 세 가지 기본 유형도 유지한다. 현재 프로젝트 설정과 편집한 시작 초안에서 만들 수 있고, 미리보기와 적용 사이에 프로젝트/양식 버전이 바뀌면 다시 확인한다.

- **시험:** backend 35개, UI 31개 통과. 개인 권한·암호화·동시 수정/삭제·본문 수신 중 권한 회수·기존 설정 보호·주말/음수 간격·부분 양식·오래된 응답과 새 입력 보존을 확인했다. 25~27번 관련 backend 통합은 90개 통과했다.
- **실제 화면:** 기본 숏폼에서 자료명과 납품 항목을 편집해 첫 프로젝트에 저장한 뒤 개인 양식으로 만들었다. 프로젝트 납품 메모가 제외됐고, 새 프로젝트의 기준일을 10월 12일→19일로 옮기자 첫 시안 14일→21일, 납품 준비 19일→26일로 계산됐다. 명시적으로 적용한 뒤 양식 이름 변경·재접속과 세 영역의 기존 설정 보호를 확인했다.
- **원문:** 적용된 자료와 규격의 ID는 새로 생성됐고, 자료는 미수령·미확인, 납품 규격은 미확정 상태다. 실제 자료·고객 메시지·시안·승인·수령·원본 이력은 복사되지 않았다. 개인 양식만 암호화 저장되며 원래 27개 프로젝트와 기존 초안/개인 날짜/읽음 기록은 보존했다.
- **화면:** PC·390/320px에서 날짜와 양식 관리·편집을 확인했다. 가로 넘침이 없으며 좁은 화면의 양식 관리 버튼은 세로로 배치한다. UI 기능 시험과 별도로 실제 화면 근거를 저장했다.

근거는 `verification/client-startup-templates-20261012/`의 backend/UI 시험·`browser-checks.json`·`fixture-before.json`·`fixture-after.json`·`preservation.json`·화면 캡처다. `fixture-after.json`은 양식 적용 직후의 보존 증거이며, 이후 27번 화면 시험에서는 이 두 합성 프로젝트의 합의한 전달일만 변경한다. 새 AI·외부 발송·예약 작업·운영 반영은 없다.

<a id="client-drafts-20261012"></a>
## 25. 작성 초안 자동 보관·복원 · 2026-10-12 로컬 검증

프로젝트 기록·답변/메모·후속 연락·진행 안내의 입력을 본인 계정별 암호화 초안으로 보관한다. 보관·삭제에 버전 비교와 내용 없는 삭제 기록을 사용하며, 복원 직전 현재 권한·원문/초안 버전을 다시 확인한다. 고객 전송·프로젝트 원문 저장은 별도의 기존 동작이다.

- **시험:** backend 45개, UI 117개 통과. 계정/프로젝트/권한 변경·동시 저장·서버 보관 실패·삭제 충돌·입력 중 늦은 응답·정식 저장 후 해당 초안 정리를 확인했다. SQLite/WAL 평문 비노출과 기존 백업/복원도 시험했다.
- **실제 화면:** 답변·프로젝트 메모와 날짜·후속 연락·진행 안내를 자동 보관하고 새로고침/창 닫기 후 다시 열어 미리보기→선택 복원을 확인했다. 첫 세 초안의 자동 보관 전후 프로젝트 revision 1과 본문 해시는 같고 메시지는 0건이었다. 명시적 프로젝트 저장 후에는 그 초안만 정리되고 나머지는 유지됐다. 이후 서버 재시작 뒤에도 세 초안이 남았다.
- **독립 검토 보완:** 다른 창에서 삭제된 초안과 충돌하면 현재 글을 대조한 뒤 명시적으로 새 초안을 보관할 수 있도록 했다. 권한 회수 시 개인 메모리뿐 아니라 선택한 프로젝트 원문/입력 DOM도 제거한다. 두 재현 경로의 회귀 시험과 수정 재검토를 마쳤다.
- **화면·범위:** PC·390/320px에서 가로 넘침 없이 표시됐고 모바일 보관/복원 버튼은 최소 44px다. 첨부 파일·비밀번호·담당/검토자·단계·승인/확인 체크는 보관하지 않는다. 실제 고객에게 보낸 메시지는 없으며 운영 배포도 하지 않았다.

근거는 `verification/client-drafts-20261012/`의 backend/UI 시험·`autosave-source-unchanged.json`·`fixture-before.json`·`fixture-after.json`·`browser-checks.json`·화면 캡처·`benchmark.md`다. 25~27번의 기존 원문 보존과 제공 소스 대조는 `verification/workroom-25-27-20261012/`에 함께 둔다.

<a id="client-lifecycle-ui-20261012"></a>
## 고객 프로젝트 전체 흐름 · 2026-10-12 로컬 화면 검증

24번 후속으로 한 합성 프로젝트에서 고객·제작자·검토자의 실제 화면을 왕복했다. 시작점은 기존 프로젝트 생성 API로 만든 접수 상태이며, 원접수 양식 가져오기를 이번 브라우저 시험에서 다시 수행한 것은 아니다. 이후 모든 업무 변경은 실제 화면으로 진행했다.

- **착수·제작:** 시작 유형의 자료·일정·납품 규격을 적용하고 고객이 기획·규격을 각각 확인했다. 고객 이미지 업로드 → 필수 자료 연결 → 제작자가 원본을 열고 사용 가능 확인 → 착수 준비 완료 → 첫 시안 전달을 확인했다.
- **수정·승인:** 고객이 재생 위치에서 의견 1건을 취합 제출했다. 소식의 확인함은 요청을 완료하지 않았다. 색상을 바꾼 v2를 전달한 뒤 별도 검토자가 검토 통과, 고객이 최신 v2를 최종 승인했다. v1 화면에서는 새 시안 안내와 이전 시안 승인 차단이 유지됐으며 내부 검토만으로 고객 승인이 생기지 않았다.
- **납품·마감:** 승인 시안을 최종 파일로 연결해 3초·16:9·MP4·수량 1개를 점검했다. 영상 재생·사용 안내 저장·직접 확인·명시적 고객 표시를 마친 뒤 고객이 실제 다운로드·수령 확인, 제작자가 마감을 확정했다. 준비 단계에서는 고객에게 최종본이 없었고 다운로드만으로 수령 확인이 생기지 않았다. 마감 뒤에도 다시 다운로드할 수 있었다.
- **원본·보존:** 두 번의 실제 고객 다운로드는 모두 302,269바이트이며 수정 시안 원본과 SHA-256이 같았다. 참고 이미지·v1·v2·최종본의 저장 파일도 원본과 일치했다. 기존 프로젝트 26개·납품 초안 4개·개인 다시 확인 날짜 1개·개인 읽음 문서 1개의 원문 해시를 보존했다. 별도 합성 프로젝트·납품 초안·읽음 문서가 각각 1개 추가됐다.
- **발견한 문제와 수정:** 수령 확인 후에도 고객 상단에 파일 확인 요청이 남는 안내 오류를 수정했다. 현재 파일 묶음의 수령이 확인되면 **수령 확인을 마쳤어요 / 납품 파일·기록 다시 보기**를 표시한다. 새 파일 묶음·시안에는 이전 수령을 승계하지 않으며 내부 마감 상태를 고객에게 노출하지 않는다. 관련 시험 **24/24**, PC와 390/320px 실제 표시·기록 이동·가로 넘침 없음을 확인했다.

근거는 `verification/client-lifecycle-ui-20261012/`의 `browser-checks.json`, `final-state.json`, `file-integrity.json`, `preservation.json`, `test-results.json`, `served-source.json`과 화면 캡처다. 로컬 고객 `/pulse-app/`에 **로컬 확인용 · 전체 흐름 점검**의 연결을 유지하고, 직원 로그인은 기존 로컬 확인 계정으로 복원한다. 합성 직원은 별도 팀이므로 기존 계정에 접근 권한을 추가하지 않는다. 전체 SNS 자동화·실물 휴대폰·운영 배포·실제 고객 효과 시험은 이번 결과에 포함하지 않는다.

<a id="client-project-news-20261012"></a>
## 24. 프로젝트별 확인하지 않은 새 소식 · 2026-10-12 로컬 검증

23번 프로젝트 상단에 기존 `notificationEvents`와 개인 `clientNotificationReads`를 연결했다. 직원 인증 GET `/api/client-projects/:id/news`와 POST `/api/client-projects/:id/news/read`는 현재 담당·검토 권한, 보관 여부, 본인 작성 제외, 최신 세션과 원문 접근 범위를 확인한다. POST는 명시한 한 소식의 개인 확인 기록만 저장하며 프로젝트 본문을 수정하지 않는다.

- **시험 269/269:** 기존 화면·단계 계획 13파일 192개, 알림·HTTP·PULSE 3파일 27개, 새 소식 UI 28개, 기존 단계별 화면 UI 21개, 고객 프로젝트 전체 흐름 1개. 권한 회수·계정/프로젝트 전환·오래된 응답·실패 표시·조회 중 확인함·원문 이동·기존 개인 알림과 읽음 기록 공유를 검증했다.
- **고객 프로젝트 전체 흐름:** 격리 DB와 실제 HTTP로 접수 → 착수 → 고객 기획 확인·자료 → 제작 → 수정 → 내부 검토 → 고객 승인 → 최종본 납품·다운로드 → 고객 수령 → 마감을 완주했다. 단계별 소식 조회·확인 전후 프로젝트와 업무 상태가 같고, 검토자의 읽음은 별개이며 파일 3개와 접수 원문 6개가 보존됐다. 전체 SNS 자동화 운영 시험으로 확대 해석하지 않는다.
- **실제 화면:** 새 합성 예시의 미확인 소식 6건 중 한 건의 **확인함**만 눌러 5건으로 줄였다. 원문을 보는 것만으로는 읽음 처리되지 않았다. 미처리 고객 문의 4건·승인 시안 1개·프로젝트 revision 9와 본문 SHA-256이 그대로였으며, 다른 프로젝트의 읽음 기록은 바뀌지 않았다. 새 소식 갱신 뒤 미저장 답변과 선택한 합성 영상 파일을 유지했고 전송·저장하지 않았다. PULSE 취향 원문과 고객이 입력한 분위기를 실제로 확인했다.
- **PC·모바일:** 기본 PC와 390/320px에서 목록·더보기·개별 원문 안내를 확인했다. 가로 넘침 없이 표시되며 모바일의 다시 확인·원문·확인함·더보기 버튼은 최소 44px다. 기존 프로젝트 화면의 입력·파일·영상·초점 보존 범위는 UI 회귀 시험으로 함께 확인했다.
- **보존·범위:** 서버 재시작 후 기존 프로젝트 25개·납품 초안 4개·개인 다시 확인 날짜 1개의 본문 해시를 보존했다. 합성 예시 프로젝트 1개와 그 소식의 개인 확인 기록 1개만 추가됐다. 새 타이머·AI 호출·고객 발송은 없으며, 기존 프로젝트 조회·화면 복귀·수동 확인 시 갱신한다.

증거는 `verification/client-project-news-20261012/`의 시험 로그·원문 전후 해시·브라우저 확인·PC/모바일 캡처·제공 파일 대조·`benchmark.md`에 저장한다. 로컬 시작 정보의 `projectNewsUrl`로 **로컬 확인용 · 프로젝트 새 소식**을 연다. 운영 배포·실물 휴대폰 시험·실제 업무 시간 절감 측정은 이번 범위가 아니다.

<a id="client-project-screen-20261012"></a>
## 23. 프로젝트 단계별 화면 자동 정리 · 2026-10-12 로컬 검증

기존 고객 프로젝트를 상단 현황과 단계별 접기·펼치기로 정리했다. 기존 `projectGroups`의 첫 작업·이유·건수를 그대로 사용하고, 모든 단계에서 활성 누락·미처리 요청을 별도로 표시한다. 꺼진 점검의 미설정 값은 경고로 만들지 않고 보관한 프로젝트는 기록으로 구분한다.

- **시험 213/213:** 기존 프런트엔드 12파일 175개, 순수 화면 계획 17개, 신규 UI 통합 21개. 단계·보관·권한·오래된 응답, 원문 이동, 입력과 파일 보존, 미디어 복구 범위, 검색, 자동 펼침과 수동 선택 분리를 확인했다.
- **실제 화면:** 납품 단계의 기존 누락 2개가 상단에 남고 접힌 원문 이동이 정상 동작했다. 기존 프로젝트 첫 할 일은 정확한 요청 원문을 열었다. 프로젝트 왕복과 새로 불러오기 뒤 수동 펼침·미저장 입력·선택한 합성 영상 파일이 유지됐다. 파일을 전송하거나 프로젝트를 저장하지 않았다. 납품 영상은 3초 재생 후 새로 불러오기와 비동기 패널 재조회가 끝나도 3초 위치로 복원됐다.
- **모바일:** 390/320px에서 목록 기본 접힘, 프로젝트 선택 후 목록 접힘·현황 초점 이동과 가로 넘침 없음을 확인했다. 입력 즉시 검색 결과를 좁히며 상세 폼은 재생성하지 않는다.
- **보존·범위:** 재시작 후 기존 25개 프로젝트·납품 초안 4개·개인 다시 확인 날짜 1개의 문서 본문 SHA-256이 작업 전과 동일했다. 제공 중인 화면 파일 5개가 소스와 일치했다. 새 API·예약 작업·AI 호출·외부 발송은 없다.

증거는 `verification/client-project-screen-20261012/`의 시험 로그·원문 전후 해시·브라우저 확인·화면 캡처·제공 파일 대조에 저장한다. 로컬 시작 정보의 `projectScreenUrl`로 연다. 운영 배포·실물 휴대폰 시험·실제 업무 시간 절감 측정은 이번 범위가 아니다.

<a id="client-materials-20261012"></a>
## 22. 프로젝트 자료·현재 최종본 모아보기 · 2026-10-12 로컬 검증

기존 고객 프로젝트에 **프로젝트 자료·최종본 → 자료 모아보기**를 연결했다. 직원 인증 GET `/api/client-projects/:id/materials`는 현재 프로젝트 접근 권한, PULSE 공개 범위, 착수 자료의 확인 지문, 현재 승인 시안에 연결된 납품과 수령 기록을 읽는다. 별도 저장소·타이머·외부 수집·AI 호출은 없다.

- **시험 293/293:** 관련 백엔드 9파일 98개, 프런트엔드 12파일 175개, PULSE 원문 이동 2파일 20개. 신규 자료 전용 시험은 44개다. 최신 권한·팀/계정/프로젝트 전환, 읽기 전용, 중복 파일 관계, 최신 승인·수령 판정, 삭제 파일·유효 HTTPS 링크, 다운로드, 입력·초점 보존, 응답 중 다른 화면 이동과 접수 원문 이동을 확인했다. 마지막 접수 원문 경로 수정 후 신규 백엔드 19개도 다시 통과했다.
- **실제 화면:** 새 합성 프로젝트에 자료 8개를 구성했다. 같은 이미지의 참고·콘셉트·장면 연결 3개가 한 파일로 모인다. 장면명 검색, 결과 없음, 영상+현재 최종본 필터, 납품 원문 초점 이동과 실제 PULSE 참고/콘셉트 탭을 확인했다. 과거 수령 확인을 새 납품에 승계하지 않고, 이전 납품에 수령 미확인 문구를 잘못 표시하지 않는다.
- **다운로드·원본:** 실제 최종 영상 다운로드 311,445바이트가 기존 원본의 SHA-256과 일치했다. 자료 API가 제공한 로컬 파일 7개는 원래 인증 경로로 모두 열렸고 화면 자산 5개는 저장된 소스와 일치했다. 파일 삭제·권한 회수에 따른 차단은 격리 HTTP 시험에서 확인했다.
- **표시·부하:** PC 1280px와 390/320px 화면에서 확인했고 좁은 화면은 버튼을 한 열로 배치한다. 자료 카드 가로 넘침이 없고 모바일 버튼 높이는 최소 44px다. 로컬 25개 프로젝트 자료 API를 한 번씩 조회한 응답은 약 1.89~59.47ms였다. 운영 동시 부하 시험이나 실제 업무 시간 절감 측정은 아니다.
- **보존·재시작:** 서버 재시작 후 기존 프로젝트 24개·납품 초안 4개·개인 날짜 문서 1개의 본문 해시가 작업 전과 일치했다. 새 자료 예시 프로젝트 1개만 추가했으며, 자료 모아보기 자체는 원본을 수정하지 않는다.

근거: `verification/client-materials-20261012/`의 `backend-tests.txt`, `backend-final-tests.txt`, `frontend-tests.json`, `pulse-source-tests.json`, `source-before.json`, `local-verification.json`, `browser-checks.json`, PC·모바일 캡처, `benchmark.md`. 같은 로컬 서버의 시작 정보 `materialsUrl`로 열 수 있다. 운영 배포·고객 실제 발송은 이번 범위에 포함하지 않았다.

<a id="client-progress-update-20261012"></a>
## 21. 고객 진행 안내·확인 요청 묶기 · 2026-10-12 로컬 검증

기존 고객 프로젝트에 **고객 진행 안내 → 진행 안내 준비**를 연결했다. 직원 인증 GET `/api/client-projects/:id/progress-update`는 현재 프로젝트 접근 권한을 다시 검사하고, 완료·현재 상태·고객 요청·합의 일정의 네 부분으로 안내문을 구성한다. 새로운 저장소·타이머·AI 호출·외부 발송은 없다. 작성 문구는 브라우저 메모리에만 유지된다.

- **시험 333/333:** 서버·상태 계산 14파일 183개와 화면 11파일 150개. 현재 권한·팀·계정 전환, 읽기 전용, 내부 정보 제외, 최신 기획/규격/시안/장면/납품 수령 증거, 수정문구 보존, 오래된 초안 복사 차단, 복사 실패를 확인했다. 기획 승인 뒤 조건만 바뀐 경우와 수령 완료 뒤 기본 안내의 중복 요청도 보완했다.
- **실제 화면:** 기존 합성 시작 설정 프로젝트에서 안내문 생성, 직접 수정, 실제 클립보드 일치, 수정본 유지, 명시적인 최신 초안 교체와 재복사를 확인했다. 1280px PC와 390/320px 화면을 확인했으며 좁은 화면에서는 버튼을 한 열로 배치했다. 페이지·카드 가로 넘침이 없고 모바일 버튼 높이는 약 46px다.
- **원본 보존:** 재시작 후 기존 프로젝트 24개·납품 초안 4개·개인 다시 확인 날짜 문서 1개의 본문 해시가 작업 전과 일치했다. 24개 프로젝트 안내 API를 모두 조회하고 서버가 제공한 화면 자산이 현재 파일과 일치하는지 확인했다. 새 합성 프로젝트도 추가하지 않았다.
- **조회 부하:** 실제 로컬 프로젝트 24개를 한 번씩 요청했을 때 응답 시간은 약 3.24~26.34ms였다. 이 기기의 단일 로컬 확인이며 운영 부하·동시 접속 성능을 보장하지 않는다. 안내 준비·복사 때만 읽고 상시 점검은 추가하지 않는다.

근거: `verification/client-progress-update-20261012/`의 `backend-tests.txt/json`, `frontend-tests.json`, `source-before.json`, `local-verification.json`, `browser-checks.json`, `source-hashes.json`, `desktop.png`, `mobile-390.png`, `mobile-320.png`, `benchmark.md`. 기본 주소는 시작 정보의 `progressUpdateUrl`이며 로컬 서버를 실행 상태로 두었다. 운영 배포·고객 실제 발송·업무 시간 절감 효과는 이번에 검증하지 않았다.

<a id="project-startup-recheck-20261012"></a>
## 19·20. 시작 설정·개인 다시 확인 날짜 · 2026-10-12 로컬

기존 고객 관리/착수/일정/PULSE 납품 규격에 시작 설정을 연결하고, 기존 오늘 할 일의 프로젝트 카드에 개인 날짜를 연결했다. 서버에는 `client-startup`, `client-task-rechecks`를 추가했으며 20번은 기존 전체 `items/projectGroups`를 보존하고 개인 표시용 목록을 별도로 반환한다. 현재 권한·CSRF·프로젝트 버전·내용 지문을 검사한다. 새 외부 호출·AI·예약 타이머는 없다.

- **총 359/359 통과:** 백엔드 20개 파일 205개, 프런트엔드 9개 파일 154개. 실패·취소·건너뜀 0. 날짜/주말/잘못된 입력/권한 회수/동시 수정/원자적 적용/기존 영역 보호/승인 미생성/내용 지문/개인 격리/날짜 도래/담당자 변경/원문·고객 알림 보존/전체 자동화 16개 유지/계정 변경/작성·초점·스크롤 보존을 검증했다.
- **19번 실제 화면:** 숏폼 광고 기준일 10/16(금), 월~금 계산으로 첫 시안 10/20·납품 준비 10/23을 만들었다. 자료 이름을 바꾸고 영상 20초·별도 자막으로 편집해 세 영역을 저장했다. 기존 착수 목록과 일정에 나타나며 PULSE 규격표에서도 협의 중 v1·20초·9:16·자막 파일 별도를 확인했다. 합의 납기 10/26, 시안 0개, 고객 규격 요청/확인 없음은 그대로다. 인터뷰 유형은 다른 신규 합성 프로젝트에서 적용 없이 미리보기했다.
- **20번 실제 화면:** 내일 저장 → 별도 목록에서 원래 10/26 기한 확인 → 지금 다시 보기 → 모바일 직접 날짜 10/15 저장을 확인했다. 새 합성 고객 문의를 추가하자 기존 항목이 변경 안내와 함께 다시 나타났다. 이를 확인한 뒤 기존 문의만 다시 10/15로 정해 추가 문의는 오늘 목록에 남겼다. 화면에서 실제 확인한 동작이며 날짜 도래·신규 연체는 고정 시계 시험으로 검증했다.
- **발견 후 수정:** 날짜 대화창을 연 뒤 새로운 원문 지문으로 바뀌어도 사용자가 처음 본 지문으로 저장하게 했다. 또 기한이 없는 변경/장면 항목에서 프로젝트 합의 납기가 지나도 미뤄지는 문제를 실패 시험으로 재현하고 수정했다. 수정 뒤 최종 회귀를 통과했다.
- **표시 검사:** PC, 390px, 320px에서 시작 설정과 날짜 입력을 확인했다. 320px의 시작 카드 client/scrollWidth는 250/250, 페이지 320/320; 날짜 대화창은 258/258, 메신저 프레임 304/304로 가로 넘침이 없었다. 실제 휴대폰 시험은 아니다. PULSE 새 탭의 0px 표시 문제로 DOM에서 규격을 확인했으며 PULSE 스크린샷은 인수 근거로 사용하지 않는다.
- **보존·성능:** 기존 프로젝트 **21개·납품 초안 4개** 해시 보존, 합성 예시 3개만 추가했다. 서버 재시작 후 24개 프로젝트 전체·4개 납품 초안·개인 날짜 레코드 해시가 동일했다. 현재 원문 항목 20개 중 오늘/대기 목록 19개·개인 보류 1개이며 자동화 상태는 전체 20개를 유지한다. 재시작 뒤 최종 자동화 상태 5회 조회는 약 **18~33ms**였다. 소규모 로컬 측정이며 운영 성능 보장은 아니다.

근거는 `verification/project-startup-recheck-20261012/`의 `backend-tests.txt`, `frontend-tests.txt`, 각 시험 요약, `preview-source-before.json`, `final-state.json`, `new-request-resurfaced.json`, `browser-checks.json`, 화면 캡처와 `benchmark.md`다. 시작 정보의 `startupUrl`·`recheckUrl`을 사용한다. 로컬 서버는 실행 상태로 두며 운영 배포·외부 고객 발송·실제 생산성 효과 검증은 이번 범위에 포함하지 않았다.

<a id="project-task-groups-20261012"></a>
## 18. 프로젝트별 할 일 묶기 · 2026-10-12 로컬

기존 `client-workflow`의 권한을 통과한 항목을 프로젝트 ID로 묶고, 오늘 할 일과 자동화 상태에 같은 우선순위를 연결했다. 원문 항목은 한 번씩만 표시하고 나머지는 펼쳐 보며, 고객·내부 대기를 실제 처리할 일과 구분한다. 기존 자동화 16개·직접 확인 목록·60초 주기·조회 범위 내 계산 재사용·화면 부분 갱신을 유지했다. 새 외부 호출·예약·업무 테이블은 없다.

- 서버·순수 함수·기존 업무/자동화 회귀 **75/75**, 프론트 관련 **109/109** 통과. KST 날짜·유효하지 않은 기한·안정 정렬·중복·원문 링크·완료/재개·담당/검토 권한 회수·보관/복원·다시 시작·고객 비노출·원문 실패→복구·구버전 응답·펼침/포커스/스크롤·동시 요청과 세션 변경을 확인했다.
- 실제 기존 로컬 작업실에서 문의 2건+고객 대기 1건인 새 합성 예시의 문의 1건을 완료했다. **3→2개**, 다른 문의가 첫 행동으로 바뀌고 펼친 고객 대기는 유지됐다. 같은 결과를 자동화 상태에서 확인했다. 원문 열기는 실제 해당 프로젝트·메시지로 이동했고 요청 카드에 초점이 맞았다.
- PC·390px·320px에서 카드와 원문 버튼을 확인했다. 오늘 할 일의 프레임 내부 너비는 각각 374/304px이며 가로 넘침이 없었다. 내부 검토 대기를 고객 대기로 표시하던 문구를 실제 응답 형태 기준으로 고쳤다. 자동화 문제/직접 확인 목록은 프로젝트 카드보다 먼저 배치했다.
- 기존 **19개 프로젝트·4개 납품 초안** 해시 보존. 새 합성 프로젝트 2개만 추가했고 기존 예시를 처리하지 않았다. 미리보기 서버를 다시 시작한 뒤에도 완료 상태·묶음·첫 행동·원문 링크가 동일했고 예시를 초기화하지 않았다. 검증 시 **13개 프로젝트·16개 할 일 항목**, 대기 전용 1개가 표시됐다. 현재 항목 수는 실제 처리와 날짜에 따라 달라진다.
- 로컬 API 재조회는 화면 검증 중 5회 약 **43~50ms**, 재시작 뒤 최종 5회 약 **51~64ms**였다. 기존 성능 개선을 보존했는지 확인하는 소규모 재측정이며 보편적인 응답속도 보증은 아니다. 전체 자료를 매분 별도로 복제하거나 AI로 재분석하지 않는다.

증거: `verification/project-task-groups-20261012/`의 원문 해시, `final-state.json`, `frontend-tests.txt`, `browser-checks.json`, PC/모바일 캡처. 시작 정보의 `projectGroupsUrl`로 확인한다. 운영 배포·실물 휴대폰·실제 고객 업무의 생산성 효과는 이번 범위에 포함하지 않았다.

## 작업실 로컬 성능 점검·개선 · 2026-10-12

같은 로컬 작업실에서 자동화 상태 조회의 반복 계산, 예약 점검이 다른 요청을 기다리게 하는 구간, 납품 파일 검사 메모리, 화면 새로고침을 측정하고 개선했다. 상태 조회 한 번 안에서만 같은 원문 계산을 재사용하고 다음 조회는 현재 원문·권한을 다시 읽는다. 예약 점검은 사용자 사이에 다른 요청을 처리하며 중복 실행과 종료 중 점검을 제어한다. 화면은 조회 중 카드 DOM을 유지하고 완료 시 자동화 패널만 교체한다. 60초 점검 주기는 그대로다.

| 측정 조건 | 개선 전 | 개선 후 |
| --- | ---: | ---: |
| 기존 로컬 예시 19개 프로젝트, 상태 API 20회 중앙값 | 146.18ms | 48.71ms |
| 합성 100개 프로젝트·10명 예약 점검 중 동시 HTTP 응답 중앙값 | 167.84ms | 11.95ms |
| 같은 합성 조건의 예약 점검 총 시간 중앙값 | 167.24ms | 53.26ms |
| 100MiB 파일 2개 최초 검사 시 추가 파일 버퍼 | 200MiB | 2.10MiB |
| 같은 대형 파일 조건의 최대 이벤트 루프 지연 중앙값 | 54.8ms | 27.3ms |

[실제 API 전](verification/local-performance-20261012/preview-api-before.json)·[후](verification/local-performance-20261012/preview-api-after.json), [프로젝트 증가 측정 조건·재현](verification/local-performance-20261012/automation/README.md), [최종 계산 결과](verification/local-performance-20261012/automation/comparison.json), [대형 파일 측정·한계](verification/local-performance-20261012/inspector/README.md), [대형 파일 최종 수치](verification/local-performance-20261012/inspector/final-compare.json). 합성 원문·시각·권한을 고정한 전후 자동화 응답 전체 해시가 일치했다. 시간은 이 PC의 표본이며 운영 서버나 모든 미디어에서의 보장값이 아니다. 파일 버퍼는 서버의 전체 메모리나 FFprobe 자식 프로세스 메모리와 다르다.

파일 검사는 전체 영상을 메모리에 올리던 방식을 1MiB 단위 비동기 읽기로 바꿨다. 시험 중 원래 코드에서도 Windows 파일 내용 변경에 크기·시간·식별정보가 그대로인 경우를 재현했다. 최초 FFprobe 검사 전후에는 내용을 다시 해시하고, 변경 직후 1초 안의 파일은 캐시 재사용 전에도 내용을 대조하도록 보완했다. 오래된 변경 없는 파일은 기존 식별정보 캐시를 사용한다. 추가 내용 검증 때문에 두 대형 파일의 최초 총 검사 시간은 **252.9→306.7ms**로 늘었고, 안정된 파일의 반복 조회는 약 4~7ms였다. 최근 변경 파일의 즉시 재조회는 추가 읽기가 필요하다. [최초 실패 로그](verification/local-performance-20261012/initial-test-failure.txt)와 원래 코드 재현·동일 시간 강제 시험의 설명은 파일 측정 문서에 있다.

실제 브라우저 프로필에서 전체 앱 `shell` 재생성과 날짜 표시 계산 비용을 확인해 패널만 갱신하고 날짜 형식 객체를 재사용했다. 같은 개선된 서버에서 화면 변경 직전 5회의 새로고침 완료 중앙값은 200.9ms, 변경 후는 85.4ms였고 50ms 초과 긴 작업은 3건→0건이었다. [화면 변경 직전](verification/local-performance-20261012/browser-before-panel-optimization.json), [변경 후](verification/local-performance-20261012/browser-after.json), [전 CPU 프로필](verification/local-performance-20261012/browser-refresh-before.cpuprofile), [후 CPU 프로필](verification/local-performance-20261012/browser-refresh-after.cpuprofile). 초기 서버 변경 전 표본은 152.3ms여서 표본 변동이 있으며 소수 측정의 비율을 보장값으로 쓰지 않는다. 브라우저 검사 연결이 중단된 구간은 [별도 기록](verification/local-performance-20261012/browser-interrupted.json)으로 보존하고 비교에서 제외했다. 실제 자동 갱신 경로에서 펼침·포커스·스크롤과 공통 메뉴 DOM을 보존했고 16개 카드·콘솔 경고/오류 없음도 확인했다([상태 보존](verification/local-performance-20261012/browser-preserved-state.json), [최종 화면](verification/local-performance-20261012/final-screen.png)).

관련 23개 시험 파일 **333개 중 332개 통과·실패 0·Windows 파일 symlink 권한 제한 1개 생략**. 디렉터리 junction 차단은 실제 통과했다. 이후 화면 최적화의 신규 4개를 포함한 클라이언트 **27개 모두 재통과**했다. 중복 제외 현재 범위는 337개 중 336개 통과·1개 생략이다. [통합 시험](verification/local-performance-20261012/final-tests.txt), [범위](verification/local-performance-20261012/test-files.json), [화면 후속 시험](verification/local-performance-20261012/automation/client-render-tests.txt). 점검 중 권한·원문 변경, 알림 읽음 상태, 중복 호출, 취소·종료, 오류 격리, 대형 파일 변경·경로 교체를 포함한다. 별도 코드 검토에서도 재현 가능한 추가 회귀는 발견하지 못했다.

1분 점검 주기를 포함한 마지막 약 71초 관찰에서 서버 프로세스의 CPU 사용은 전체 16논리코어 용량 대비 평균 **0.071%**(1코어 기준 1.136%), 최대 작업 집합 메모리는 **62.09MiB**였다. health 응답 70회 모두 성공했고 중앙값 2.41ms·95백분위 10.68ms였다. 화면 갱신 확인 몇 회를 포함한 관찰이며 엄격한 유휴 조건은 아니다. 브라우저·FFprobe 자식 프로세스와 다른 앱은 포함하지 않으므로 PC 전체의 렉 여부를 단정하지 않는다. [관찰 전](verification/local-performance-20261012/preview-before.json)·[후](verification/local-performance-20261012/preview-after.json), [재현 스크립트](verification/local-performance-20261012/observe-preview.ps1). I/O 값은 파일·네트워크·파이프 전송량이며 물리 디스크 사용량이 아니다. Node 측정 항목은 [perf_hooks](https://nodejs.org/api/perf_hooks.html)와 [process.cpuUsage](https://nodejs.org/api/process.html#processcpuusagepreviousvalue)를 참고했다.

같은 데이터·64046 포트의 실행 서버를 재시작했고 프로젝트 19개·납품 초안 4개 원문 해시가 유지됐다. 실제 예약 점검과 17번 최근 정상 점검 시각이 갱신되며 제공 중인 화면 소스도 현재 파일과 일치한다([최종 확인](verification/local-performance-20261012/final-state.json)). **로컬 반영만 완료했으며 운영 서버에는 반영하지 않았다.**

## 자동화 상태 11~17번 연결 확장 · 2026-10-12 로컬

기존 10번 **내 작업실 → 제작 도구 → 자동화 상태**에 11~17번을 연결했다. 1~9번과 함께 총 16개 카드이며 10번은 이 상태 화면이다. 11~16번은 현재 원문을 읽은 시각과 실제 승인·수령·설정·검토 기록을 구분하고, 현재 요청한 고객 확인과 담당자 처리 대기를 표시한다. 아직 설정하지 않은 과거 프로젝트·요청하지 않은 고객 확인·자기 제출 장면의 검토는 할 일로 만들지 않는다. 17번은 현재 프로젝트·승인 시안·규격·파일 지문에 해당하는 자동 실행 시도·정상 완료·실패·지연·장기 실행을 연결한다. 규격 확인 요청 중에는 고객 대기로만 표시하고 예약 검사 누락으로 알리지 않는다.

관련 **21개 시험 파일 295개 모두 통과, 실패·생략 0**. [통합 시험](verification/automation-health-clients-20261012/final-tests.txt), [시험 범위](verification/automation-health-clients-20261012/test-files.json). 현재 담당자/검토자 권한, 다른 프로젝트 오류 격리, 점검 중 권한 회수·원문 변경, 이전 규격 오류 제외, 예약 꺼짐과 무대상, 동일 오류 중복 방지·정상 복구, 조회 시 원본·검사 기록 무변경, 기존 11~17·오늘 업무·주간·마린 연결을 포함한다. 전체 스캔 원문 오류는 일부 미확인으로 표시하며 과거 알림을 해결됐다고 단정하지 않는다.

별도 합성 서버의 실제 브라우저에서 **17번 검사 실패 → 자동화 상태 문제 1건 → 기존 메신저 내부 알림 1건 → 정상 검사 → 해당 오류·알림 해제**를 확인했다. 담당자의 직접 파일 확인은 복구 후에도 남는다. [오류 화면](verification/automation-health-clients-20261012/failure.dom.txt), [알림 발생](verification/automation-health-clients-20261012/notification-active.dom.txt), [알림 해제](verification/automation-health-clients-20261012/notification-recovered.dom.txt), [정상 검사 시각](verification/automation-health-clients-20261012/recovered.dom.txt). 이 예시는 검사 응답을 주입한 합성 시험이며 실제 파일 재생 검사나 고객 승인 결과로 확대하지 않는다. 시험 서버는 종료했다.

기존 격리 작업실에서 11~17번 카드에 각 예시가 연결되고, 17번 원문 바로가기가 정확한 프로젝트와 납품 카드에 포커스를 주는 것을 확인했다([원문 이동](verification/automation-health-clients-20261012/source-route.json)). 열린 화면의 자동 갱신에서 확인 시각이 바뀌어도 펼침·포커스·스크롤 위치를 유지했다([기록](verification/automation-health-clients-20261012/automatic-refresh.json)). 1280·390·320px 모두 가로 넘침이 없었고 브라우저 경고·오류는 없었다. [PC 11~13](verification/automation-health-clients-20261012/client-cards-desktop.png), [PC 14~17](verification/automation-health-clients-20261012/client-cards-14-17-desktop.png), [390px](verification/automation-health-clients-20261012/cards-390.png), [320px](verification/automation-health-clients-20261012/cards-320.png), [측정값](verification/automation-health-clients-20261012/responsive.json).

같은 데이터·64046 포트로 최종 재시작 후 health 200, 현재 소스 제공, 프로젝트 19개·납품 초안 4개 원문 해시 보존과 실제 17번 예약 점검의 정상 완료 시각을 확인했다([최종 상태](verification/automation-health-clients-20261012/final-state.json)). 로컬 실행기와 시작 정보의 기본 진입점을 `automationUrl`로 바꿨고 각 기존 예시 링크도 유지한다. **운영 배포·실제 고객 발송·유료 AI 호출은 하지 않았다.** 로컬 서버가 꺼져 있으면 자동 점검·알림도 멈추며 서버 자체 중단의 외부 감시는 포함하지 않는다.

## 고객별 납품 규격·파일 누락 점검 · 2026-10-12 로컬

17번을 기존 **고객 관리 → 프로젝트 → 최종본 납품 준비**에 연결했다. PULSE에서 고객이 현재 확인한 납품 규격에 준비 파일을 연결하면 수량·길이·표시 비율·파일 형식·별도 자막 누락과 자막 시간 구조를 자동 대조한다. 현재 파일 내용의 SHA와 규격·승인 시안을 묶어 직접 확인을 기록하고, 원본이 달라지면 이전 확인을 다시 요구한다. 남은 점검은 담당자의 기존 **오늘 할 일·주간 정리**로 연결한다. 영상 내용·언어·번인 자막·소리는 직접 확인하며, 외부 링크 파일은 자동으로 내려받지 않는다. 기존 납품 준비를 거치지 않은 과거 직접 납품은 미점검으로 구분하고 누락 알림을 만들지 않는다.

관련 **49개 시험 파일 573개 중 571개 통과·실패 0·환경 제한 2개 생략**. [통합 시험 로그](verification/client-delivery-check-20261012/final-tests.txt)와 [시험 범위](verification/client-delivery-check-20261012/test-files.json). 생략은 Windows가 파일 symlink 생성을 허용하지 않아 실행하지 못한 기존 자막 제공·신규 검사 경계 2개이며 디렉터리 junction 차단은 실제 통과했다. 이후 재생 중 자동 갱신 보호 2개를 추가하고 납품 완료 조회 안내를 보완해 **해당 44개 시험 모두 재통과**했다([후속 로그](verification/client-delivery-check-20261012/followup-tests.txt)). 중복을 제외한 현재 범위는 575개 중 573개 통과·2개 생략이다.

검사에는 정상/손상 MP4·WebM·PNG·JPEG·SRT·VTT, 회전/SAR, 중복 파일 수량 제외, 영상 길이 오차 0.1초·표시 비율 오차 1%, 규격 변경·같은 크기 파일 변조·직접 확인 토큰 무효화, 검사 중 권한·세션·초안 변경, 고객 비공개, 오늘·주간 연결, 기존 백업·복구를 포함한다. 실제 로컬 MP4로 발견한 moov-at-end 오판을 수정했다. FFprobe는 검증한 파일 핸들을 탐색 가능하게 읽고 외부 파일·네트워크 프로토콜을 허용하지 않는다. 구버전 도구나 읽을 수 없는 형식은 검사 불가·직접 확인으로 구분한다. 자동 검사는 전체 재생 품질 보증이 아니다.

실제 브라우저에서 합성 프로젝트의 **별도 SRT 추가·확정 영상 항목 연결 → 길이 3초·16:9·MP4·파일 수량 통과 → 각 파일 직접 확인 → 최종 영상·자막 2개 명시적 등록 → 고객 PULSE 화면의 최종 파일 확인·다운로드**를 완료했다. [준비 완료](verification/client-delivery-check-20261012/staff-ready.dom.txt), [고객 납품 화면](verification/client-delivery-check-20261012/customer-delivered.dom.txt), [다운로드 원본 바이트·SHA 일치](verification/client-delivery-check-20261012/customer-downloads.json). 합성 영상은 실제 브라우저에서 3초 끝까지 재생되어 ended=true·error=null을 확인했다([재생 상태](verification/client-delivery-check-20261012/staff-playback.json)). 실제 고객의 내용 검수나 음질 평가 결과로 확대하지 않는다.

기본 예시는 **30초·9:16 영상 2개와 별도 자막**에 3초·16:9 영상 1개만 연결해, 수량·별도 자막 누락과 길이·비율 불일치 4개 및 직접 확인 1개를 남겨 두었다. 완료한 시험 프로젝트는 오늘 할 일에서 빠지고 기본 예시만 1건 남는다. **납품 준비 열기 → 정확한 프로젝트의 납품 카드 포커스**를 확인했다([오늘 할 일](verification/client-delivery-check-20261012/today-after-delivery.dom.txt), [이동 기록](verification/client-delivery-check-20261012/today-route.json)). 주간 연결은 서비스·HTTP 시험으로 확인했다.

PC 1280px와 390·320px 작업실에서 페이지 가로 넘침이 없었으며, 320px 파일 매핑 선택 입력도 화면 안에 있었다. [PC](verification/client-delivery-check-20261012/staff-pending-desktop.png), [390px](verification/client-delivery-check-20261012/staff-pending-390.png), [320px](verification/client-delivery-check-20261012/staff-pending-320.png), [320px 파일 연결](verification/client-delivery-check-20261012/staff-mapping-320.png), [측정값](verification/client-delivery-check-20261012/responsive.json). 입력·확인 체크·영상/음성 재생 중 자동 화면 갱신을 미루고 진행 중 응답도 해당 작업을 덮어쓰지 않는다. 입력 없는 열린 화면에서 마지막 검사 시각이 05:36:15→05:37:15로 실제 60초 갱신됐고 브라우저 경고·오류는 없었다([자동 갱신 기록](verification/client-delivery-check-20261012/automatic-refresh.json)).

같은 데이터·포트로 재시작 후 health 200, 기존 합성 프로젝트 19개·납품 초안 4개 원문 해시 불변, 준비/납품 미디어 3개 원본 바이트 일치와 정적 소스 일치를 확인했다([최종 상태](verification/client-delivery-check-20261012/final-state.json)). 기존 1~16번과 동시 작업의 PULSE 제작 기능을 보존했다. 로컬 시작 정보 `.tmp/workroom-publishing-20261011/preview-ready.json`의 `deliveryCheckUrl`로 기본 예시를 연다. 서버가 켜져 있으면 60초마다 검사하고 화면 조회·파일 준비 변경에서도 현재 원본을 재검사한다. **운영 배포·실제 고객 발송·유료 AI 호출은 수행하지 않았다.**

## 제작 일정·고객 확인 지연 점검 · 2026-10-12 로컬

16번을 기존 **고객 관리 → 프로젝트 → 제작 일정·고객 확인 지연 점검**, **PULSE 직원 요약**, **오늘 할 일**, **주간 정리**에 연결했다. 내부 목표일 5개와 현재 기획·납품 규격·시안·장면의 확인 대기를 원문에서 계산한다. 남은 제작일을 입력하면 한국 날짜와 달력일/월~금 기준으로 예상 완료일을 표시한다. 합의한 납품일과 내부 예상일은 분리하며, 공휴일은 별도 반영하지 않는다.

관련 39개 시험 파일 **462/462 통과**, 실패·취소·건너뜀 0. [최종 시험 로그](verification/client-schedule-20261012/final-tests.txt). 16번 전용 55개에는 한국 자정·연말·주말 계산, 미입력과 0일 구분, 현재 버전 대기만 계산, 같은 시안·장면 대기 중복 제거, 승인·완료·점검 꺼짐·보관 상태, 권한·CSRF·변경 번호·허용 필드, 설정 이력 보존, 고객 응답의 내부 일정 제외, 오늘 할 일·주간 정리, 입력 중 자동 응답 폐기와 계정·권한 변경을 포함한다. HTTP 시험으로 재시작·기존 백업 복구 뒤 설정과 업로드 원본 바이트 보존을 확인했다. 원문 이동에서 실제 남은 기획·영상 의견을 가리키도록 고쳤고, PULSE 직원 링크의 review/history 탭이 유지되는 회귀시험도 추가했다.

실제 로컬 브라우저의 합성 프로젝트에서 **남은 제작일 2→3일·평일 기준 저장 → 예상일 10월 15일·합의일 10월 19일 유지 → 고객 PULSE 시안 승인 → 현재 고객 확인 완료·대기 0건 → 해당 일정의 오늘 할 일 제외**를 확인했다. 기본 예시는 기획·시안 확인 대기 2건과 납기 위험을 남겨 두었다. **제작 일정 열기 → 정확한 프로젝트의 일정 카드 포커스**, PULSE 영상 원문 링크의 영상 탭, 직원 요약의 오늘 확인 0건도 확인했다. 고객 화면에는 내부 일정 요약이 없다. 입력 없이 열린 화면에서 마지막 확인 시각이 05:09:24→05:10:24로 바뀌는 실제 60초 갱신도 확인했다([기록](verification/client-schedule-20261012/automatic-refresh.json)). [저장 후 기록](verification/client-schedule-20261012/staff-settings-saved.dom.txt), [고객 승인](verification/client-schedule-20261012/customer-approved.dom.txt), [직원 확인 완료](verification/client-schedule-20261012/staff-after-approval.dom.txt), [오늘 할 일](verification/client-schedule-20261012/today-after-confirm.dom.txt).

PC 1280px 및 작업실·PULSE 직원 화면 390·320px에서 가로 넘침이 없었다. 320px에서는 목표일 입력도 직접 펼쳐 확인했다. [기본 일정 화면](verification/client-schedule-20261012/staff-desktop.jpg), [작업실 390px](verification/client-schedule-20261012/staff-390.png), [320px 설정](verification/client-schedule-20261012/staff-settings-320.png), [PULSE 320px](verification/client-schedule-20261012/pulse-staff-320.png), [측정값](verification/client-schedule-20261012/responsive.json).

같은 격리 데이터와 포트로 재시작한 뒤 `/api/health` 200, 두 프로젝트 원문·설정 이력 불변, 정적 파일 9개의 소스 일치, 시안 영상 2개의 원본 바이트 일치를 확인했다. [최종 상태](verification/client-schedule-20261012/final-state.json). 기본 예시는 확인 항목 5개·고객 대기 2건·설정 이력 1개, 별도 시험은 확인 항목 0개·대기 0건·설정 이력 2개다. 기존 1~15번과 모델·스타일·규격·의견 취합·미리보기 제작 기능의 동시 변경을 보존했다.

로컬 시작 정보 `.tmp/workroom-publishing-20261011/preview-ready.json`의 `scheduleUrl`로 연다. 점검은 현재 조회에서 계산되고 해당 고객 관리 화면이 열려 있으면 60초마다 갱신한다. 사용자가 입력하거나 확인 체크를 남기는 동안에는 자동 갱신을 미룬다. 운영 배포·고객 자동 발송·유료 AI 호출은 수행하지 않았다.

## 장면별 수정 요청·반영 누락 확인 · 2026-10-12 로컬

15번을 기존 **고객 관리 → 프로젝트 → 장면별 수정 요청·반영 확인**, **PULSE 장면 구성**, **오늘 할 일**, **주간 정리**에 연결했다. 기존 고객의 장면 수정 의견을 원문으로 사용하며 요청 당시·현재·반영 제출 버전을 함께 표시한다. 담당자 제출, 지정 검토자의 내부 검토, 고객의 현재 장면 확인을 구분한다.

관련 35개 시험 파일 **406/406 통과**, 실패·취소·건너뜀 0. [최종 시험 로그](verification/client-scene-requests-20261012/final-tests.txt). 15번 전용 48개에는 현재 직원·검토자·고객 권한과 CSRF, 프로젝트 리비전, 직접 확인과 새 장면 버전, 검토 전 고객 확인의 소급 금지, 자기 검토 금지, 장면·자료·담당자·검토자 변경 후 재확인, 추가 수정, 중복 처리 방지, 내부 메모·이력·비공개 장면의 고객 응답 제외, 오늘 할 일·주간 정리 연결, 작성 중 입력 보존과 늦은 응답 방어를 포함한다. HTTP 시험에서는 재시작·기존 백업 격리 복구 뒤 요청 이력과 업로드 PNG 원본 바이트 보존도 확인했다.

실제 로컬 브라우저의 합성 프로젝트에서 **PULSE 장면 v1의 제품명을 수정해 v2 저장 → 요청은 미완료 유지 → 담당자 수정 시작 → v2 선택·직접 확인 후 반영 제출 → 고객 확인 대기 → 고객이 PULSE의 ‘수정된 장면 v2 확인’ → 남은 요청 0개·고객 확인 완료 1개**를 확인했다. 프로젝트는 제작 중으로 유지되며 최종 영상 승인은 바뀌지 않았다. 고객 화면에는 내부 검토 메모가 없었다. [직원 완료 기록](verification/client-scene-requests-20261012/staff-done.dom.txt), [고객 완료 화면](verification/client-scene-requests-20261012/customer-done-desktop.png).

완료 요청은 **내 할 일**에서 빠지고 미완료 기본 예시 2개는 남았다. **장면 수정 요청 열기 → 정확한 프로젝트의 장면 요청 카드 포커스**까지 확인했다. [오늘 할 일 기록](verification/client-scene-requests-20261012/today-after-confirm.dom.txt). 주간 정리 연결과 지정 검토자 왕복은 HTTP 시험으로 확인했다. PC 1280px 및 직원·고객 390·320px에서 가로 넘침이 없었다. [PC 기본 예시](verification/client-scene-requests-20261012/staff-pending-desktop.png), [직원 390px](verification/client-scene-requests-20261012/staff-pending-390.png), [직원 320px](verification/client-scene-requests-20261012/staff-pending-320.png), [고객 390px](verification/client-scene-requests-20261012/customer-done-390.png), [고객 320px](verification/client-scene-requests-20261012/customer-done-320.png), [측정값](verification/client-scene-requests-20261012/responsive.json).

동시에 추가된 모델·스타일 선택과 통합하면서 14번의 객체 전후 표시를 읽을 수 있게 고쳤고, 과거 기준에 없던 빈 선택은 가짜 변경으로 세지 않도록 했다. 새 기획 필수 항목인 ‘메시지를 믿을 근거’에 맞춰 시험용 정상 기획을 보충했다. 기존 로컬 데이터와 고객 확인·자료 검토·기준 이력은 덮어쓰지 않았다. 따라서 근거가 비어 있는 예전 13번 합성 예시에는 새 기획 누락 항목이 표시된다. 14번 완료 예시는 기준 이력 1개·변경 없음으로 유지된다.

같은 격리 데이터·포트를 유지하고 재시작 뒤 `/api/health` 200, 정적 파일 8개의 원본 바이트 일치, 11·12번 납품·마감 예시와 13·14번 원본 기록 보존을 확인했다. [최종 상태](verification/client-scene-requests-20261012/final-state.json). [로컬 장면 요청 관리 열기](http://127.0.0.1:64046/?tab=workroom&section=clients&project=d13619ca-5395-49f9-9e09-ac417a1a4509&requests=1). 기존 실행기 `.tmp/workroom-publishing-20261011/preview.mjs`와 시작 정보의 `sceneRequestsUrl`을 사용한다. **운영 배포·실제 고객 발송·유료 AI 호출은 하지 않았다.** 실제 업무에서의 누락 감소 효과는 아직 측정하지 않았다. [사용법·설계 근거](WORKSPACE.md#장면별-수정-요청반영-확인--2026-10-12-로컬).

## 제작 중 변경사항·재확인 관리 · 2026-10-12 로컬

14번을 기존 **고객 관리 → 프로젝트 → 제작 중 변경사항·재확인**, **PULSE 제작 설계·장면 구성**, **오늘 할 일**, **주간 정리**에 연결했다. 고객이 확인한 기획과 합의 일정·조건·공유 자료를 비교 기준으로 저장하고, 이후 변경 전후와 재검토할 장면·일정·조건을 표시한다. 고객의 최신 기획 확인과 담당자의 영향 검토를 구분하며, 담당자가 명시적으로 갱신할 때까지 이전 기준을 보존한다.

관련 31개 시험 파일 **351/351 통과**, 실패·취소·건너뜀 0. [최종 시험 로그](verification/client-changes-20261012/final-tests.txt). 신규 50개에는 직원·고객 권한과 CSRF, 최신 역할·리비전·변경 묶음 검증, 추가 편집 후 재확인, 20회 넘는 기획 저장 후에도 최초 기준 보존, 비공개 전환·삭제 자료명과 내부 검토 메모의 고객 응답·복사용 문구 제외, 확인·갱신 중복 차단, 현재 담당자의 오늘 할 일·주간 정리, 작성 중 입력·계정 전환·충돌 방어를 포함한다. 실제 HTTP 시험에서 서버 재시작·기존 백업 격리 복구 후 기준·검토 기록과 업로드 PNG 원본 바이트가 유지되는 것도 확인했다.

실제 로컬 브라우저의 별도 합성 프로젝트에서 **30초→60초·화면 문구 변경 표시 → 고객의 제작 설계 v2 확인 → 정확한 장면 링크 → 기존 두 장면을 각 30초·현재 기획 기준으로 저장 → 제작 조건 원문 60초로 수정 → 일정 유지·조건 변경 반영 검토 → 남은 확인 0개 → 명시적 비교 기준 갱신 → 기준 이후 변경 없음**을 확인했다. 프로젝트는 제작 중으로 유지되고 기준 이력 1개가 남았다. 고객 화면에는 내부 메모가 없으며 기준 갱신 전까지 전후 비교가 유지됐다. [직원 검토 완료](verification/client-changes-20261012/staff-reviewed.dom.txt), [갱신 후](verification/client-changes-20261012/staff-clean.dom.txt), [고객 확인 후](verification/client-changes-20261012/customer-confirmed.dom.txt), [고객 기준 갱신 후](verification/client-changes-20261012/customer-clean.dom.txt).

**내 할 일 → 변경사항 열기 → 정확한 프로젝트의 변경사항 카드 포커스**를 확인했다. 기준 갱신을 마친 시험 프로젝트는 오늘 할 일에서 빠지고 미완료 기본 예시는 남았다. [오늘 할 일 기록](verification/client-changes-20261012/today-after-advance.dom.txt). 주간 정리 연결은 HTTP 시험으로 검증했다. 고객 발송은 실행하지 않았다.

PC 1280px와 직원·고객 **390·320px**를 확인했고 문서와 주 작업 영역에 가로 넘침이 없었다. 고객 단계 메뉴의 가로 스크롤은 유지한다. [PC 기본 예시](verification/client-changes-20261012/staff-pending-desktop.png), [직원 390px](verification/client-changes-20261012/staff-pending-390.png), [직원 320px](verification/client-changes-20261012/staff-pending-320.png), [고객 390px](verification/client-changes-20261012/customer-confirmed-390.png), [고객 320px](verification/client-changes-20261012/customer-confirmed-320.png), [측정값](verification/client-changes-20261012/responsive.json). 모든 모바일 입력 저장이나 실제 업무 시간 절감까지 측정한 것은 아니다.

같은 격리 데이터와 포트를 유지했다. 서버 `/api/health` 200, 변경된 정적 파일 8개 응답의 원본 바이트 일치, 11~13번의 준비/완료 예시 보존을 확인했다. 기본 14번 예시는 변경 2개·남은 확인 5개, 별도 시험 예시는 기준 갱신 완료로 저장됐다. [최종 상태](verification/client-changes-20261012/final-state.json). [로컬 변경사항 관리 열기](http://127.0.0.1:64046/?tab=workroom&section=clients&project=4d41d77a-3d93-4090-a794-6d1fcad5f6c7&changes=1). 기존 실행기 `.tmp/workroom-publishing-20261011/preview.mjs`와 시작 정보의 `changesUrl`을 사용한다.

이번 결과는 **합성 계정·격리 데이터의 로컬 확인**이다. 운영 배포·실제 고객 발송·유료 AI 호출·새 정기 실행기는 추가하지 않았다. 변경의 실제 제작 영향은 담당자가 판단하며, 이 기능이 일정·비용·계약·장면 원문을 자동 변경하거나 고객 기획 확인을 대신하지 않는다. [사용법·설계 근거](WORKSPACE.md#제작-중-변경사항재확인-관리--2026-10-12-로컬).

## 제작 착수 전 필수 자료·확정사항 누락 확인 · 2026-10-12 로컬

13번을 기존 **고객 관리 → 프로젝트 → 제작 착수 전 확인**, **PULSE 제작 설계**, **오늘 할 일**, **주간 정리**에 연결했다. 프로젝트별 필요한 자료와 확인일을 정하고, 기존 자료를 연결해 도착·사용 가능·제외 상태를 구분한다. 제작 기획 필수 항목과 현재 기획의 고객 확인, 합의한 전달일·제작 조건을 함께 계산하며 준비 완료만으로 제작 단계는 바꾸지 않는다.

관련 27개 시험 파일 **301/301 통과**, 실패·취소·건너뜀 0. [최종 시험 로그](verification/client-kickoff-20261012/final-tests.txt). 13번 전용 41개에는 직원·고객 권한과 CSRF, 현재 리비전, 원본 변경 후 재확인, 비공개 자료·내부 메모·확인 지문의 고객 응답 제외, 담당자가 제외한 항목의 고객 재제출 거부, KST 확인일과 중복 없는 오늘 할 일, 주간 일정, 작성 중 입력·계정 변경·늦은 응답 방어를 포함한다. 실제 HTTP 시험에서 서버 재시작·기존 백업 격리 복구 후 준비 기록과 업로드 PNG 원본 바이트가 유지되는 것도 확인했다.

실제 브라우저의 별도 합성 프로젝트에서 **고객이 기존 로고 자료 선택 → 제출 → 도착·담당자 확인 대기 → 직원 화면 새로 불러오기 → 로고·화면 문구의 사용 가능 확인 → 남은 확인 2→0개·착수 준비 완료**를 확인했다. 제작 단계는 일정·내용 협의로 유지됐다. 고객 화면도 준비 완료와 자료 사용 가능 상태를 표시했다. [직원 완료 화면](verification/client-kickoff-20261012/staff-ready-desktop.png), [직원 카드 기록](verification/client-kickoff-20261012/staff-ready.dom.txt), [고객 완료 화면](verification/client-kickoff-20261012/customer-ready-desktop.png), [고객 화면 기록](verification/client-kickoff-20261012/customer-ready.dom.txt).

**내 할 일 → 착수 준비 열기 → 정확한 프로젝트 카드** 이동을 확인했다. 완료 뒤 새로고침하면 시험 프로젝트가 빠지고 미완료 기본 예시만 남았다. 여러 고객 업무를 구분할 수 있도록 할 일 제목에 프로젝트 이름을 포함했다. PULSE 담당자 링크도 현재 프로젝트의 제작 설계와 준비 카드를 열었다. 기본 예시의 요청 문구에는 아직 없는 로고와 담당자 검토만 남은 화면 문구를 구분해 표시하며 이미 받은 문구는 재전송할 필요가 없다고 안내한다. 고객 발송은 실행하지 않는다. 주간 정리 연결은 서비스 시험으로 검증했다.

1280px PC 화면을 직접 확인했고, 직원·고객 **390·320px에서 문서 가로 넘침이 없고**, 직원 주 작업 영역의 scrollWidth와 clientWidth가 같았다. [직원 390px](verification/client-kickoff-20261012/staff-pending-390.png), [직원 320px](verification/client-kickoff-20261012/staff-pending-320.png), [고객 390px](verification/client-kickoff-20261012/customer-ready-390.png), [고객 320px](verification/client-kickoff-20261012/customer-ready-320.png), [측정값](verification/client-kickoff-20261012/responsive.json). 고객 상단 단계 메뉴는 의도한 가로 스크롤을 유지한다. 모든 세부 입력을 모바일에서 저장하는 시험이나 실제 사용자 시간 절감 측정까지 한 것은 아니다.

검증 중 로컬 서버가 최신 PULSE 설치 모듈을 제공하지 않아 멈추던 상태는 최신 코드로 재시작해 해결했다. 최종 `/api/health` 200과 관련 JS/CSS 9개 실제 응답·원본 바이트 일치를 확인했다. 기본 13번 예시는 미완료 2개, 별도 UI 시험 예시는 준비 완료 0개로 저장됐고 기존 11번 준비/납품 예시와 12번 수령 대기/마감 예시를 보존했다. [최종 상태](verification/client-kickoff-20261012/final-state.json).

이번 결과는 **합성 계정·격리 데이터의 로컬 확인**이다. [로컬 착수 준비 열기](http://127.0.0.1:64046/?tab=workroom&section=clients&project=2cd92e59-4b01-4e64-a5e9-f99c4fe8d5e5&kickoff=1). 기존 실행기 `.tmp/workroom-publishing-20261011/preview.mjs`와 시작 정보의 `kickoffUrl`을 사용한다. 운영 배포·실제 고객 발송·유료 AI 호출·별도 정기 실행기는 추가하지 않았다. 자료 내용의 실제 제작 적합성은 담당자가 직접 판단한다. [사용법·설계 근거](WORKSPACE.md#제작-착수-전-필수-자료확정사항-누락-확인--2026-10-12-로컬).

## 납품 후 고객 수령 확인·마감 점검 · 2026-10-12 로컬

12번을 기존 **고객 관리 → 프로젝트 → 수령 확인·마감 점검**, **오늘 할 일**, **주간 정리**에 연결했다. 고객이 현재 최종 파일 묶음과 사용 안내를 명시적으로 확인하면 수령 기록을 남기고, 담당자가 남은 문의·수정·후속 연락을 정리한 뒤 마감을 확정한다. 다운로드만으로 수령을 기록하지 않으며 마감 후에도 고객의 파일 접근을 유지한다.

관련 20개 시험 파일 **230/230 통과**, 실패·취소·건너뜀 0. [통합 시험 로그](verification/client-closeout-20261012/tests.tap). 고객·직원의 현재 권한, CSRF, 리비전과 파일 묶음 일치, 중복 확인, KST 확인일, 담당자별 오늘 할 일, 주간 기록, 신규 파일·문의·연락 발생 후 재점검, 내부 정보의 고객 응답 제외를 확인했다. 실제 HTTP에서 수령·마감 후 서버 재시작과 기존 백업의 격리 복구를 거쳐 기록·미디어 원본 바이트가 유지되는 것도 확인했다. 마지막 안내 문구를 실제 고객 버튼 이름에 맞춘 뒤 [관련 22개 시험](verification/client-closeout-20261012/final-followup.tap)을 다시 통과했으며 통합 결과와 합산하지 않는다.

실제 로컬 브라우저의 합성 시험 프로젝트에서 **최종 영상·SRT 다운로드 → 수령 확인 대기 유지 → 파일과 안내 확인했어요 → 확인란 선택 → 수령 확인 남기기 → 직원 새로 불러오기 → 마감 가능 → 담당자 확인란 선택 → 프로젝트 마감 확정 → 마감 완료**를 확인했다. 수령 확인 전에 내려받은 영상·자막과 마감 후 다시 받은 자막은 원본 바이트와 일치했다. 고객 화면이 내부 마감 기록 없이 수령 확인과 파일을 유지함을 확인했다. [고객 수령 화면](verification/client-closeout-20261012/customer-confirmed.png), [고객 화면 기록](verification/client-closeout-20261012/customer-confirmed.dom.txt), [직원 마감 기록](verification/client-closeout-20261012/staff-closed.dom.txt).

사용자가 직접 확인할 기본 예시 **로컬 확인용 · 납품 후 수령 확인**은 파일 2개·수령 미확인·확인일 경과 상태로 남겼고, 별도 **로컬 시험 · 고객 수령과 마감 왕복**에는 실제 UI로 마친 결과를 보존했다. 재시작 뒤 두 상태, 기존 11번의 준비 중 예시·납품 완료 예시, 서버 준비 상태와 변경된 JS/CSS 6개의 실제 응답·원본 일치를 확인했다. [최종 상태](verification/client-closeout-20261012/final-state.json).

고객 PC 화면은 캡처 후 직접 검토했다. 마지막 브라우저 재연결이 시간 초과되고 직원 탭의 화면 폭이 0으로 보고돼 **12번 직원 화면의 최종 캡처와 390·320px 반응형 검증은 완료하지 못했다**. 앞선 11번의 모바일 결과를 12번의 증거로 사용하지 않는다. 실제 오늘 할 일·주간 정리 연결은 서비스·HTTP 시험으로 확인했으며 이번 브라우저 흐름에서 해당 메뉴 왕복까지 재검증하지는 않았다. 파일 바이트 일치는 영상 전체 시청·음성 청취·자막 타이밍 승인을 뜻하지 않는다.

이번 결과는 **합성 계정과 격리 데이터의 로컬 확인**이다. [로컬 수령·마감 확인](http://127.0.0.1:64046/?tab=workroom&section=clients&project=5a5c4d36-2f17-4914-913b-6f92aaf59e24&closeout=1)을 열거나 기존 실행기 .tmp/workroom-publishing-20261011/preview.mjs로 다시 시작한다. 시작 정보의 closeoutUrl도 같은 입구다. 운영 배포·실제 고객 발송·새 AI 호출·별도 정기 실행기를 추가하지 않았다. [사용 흐름과 설계 근거](WORKSPACE.md#납품-후-고객-수령-확인마감-점검--2026-10-12-로컬).

## 고객 승인 후 최종본 납품 준비 · 2026-10-12 로컬

11번을 기존 **고객 관리 → 프로젝트 → 최종본 납품 준비**에 연결했다. 최신 고객 승인 시안과 준비 기록을 연결하고, 필수 파일 누락·직접 확인·사용 안내를 준비한 뒤 담당자가 명시적으로 등록할 때만 기존 최종본과 고객 알림에 반영한다. 준비 기록은 별도 `clientDeliveryDrafts` 문서에 보관하며 기존 고객 프로젝트의 공개 본문·변경 번호·알림을 준비 저장만으로 바꾸지 않는다.

관련 16개 시험 파일의 통합 실행은 **158개 통과·실패 0·1개 건너뜀**이었다. 이후 전달 문구 복사와 납품 완료 표시의 마지막 UI 수정에 대해 **25/25개 UI 시험**을 다시 통과했다. 두 실행에는 UI 시험이 중복되므로 합산하지 않는다. [통합 시험 로그](verification/client-delivery-20261012/tests.tap), [최종 UI 시험 로그](verification/client-delivery-20261012/ui-final.tap).

- **서비스 19개 통과:** 최신 승인 기준, 필수 파일과 직접 확인, 권한·역할 변경, 프로젝트와 준비의 동시 변경, 새 승인 시안의 확인 미승계, 명시적 등록, 중복 등록 차단, 여러 파일 등록 중 실패의 전체 취소, 기존 프로젝트 버전 상한을 확인했다. 1~12개 파일 용도와 승인 시안별 최대 40개 파일 기록, 제외한 항목 보존, 안내 길이와 수정 안내 유지도 포함한다.
- **최종 UI 25개 통과:** 작성 중 입력·선택 파일 유지, 승인 변경·계정 이동·권한 철회·늦은 응답, 충돌 복구, 저장하지 않은 변경과 고객 표시 버튼의 분리, 파일 종류·크기 안내와 명시적 표시 확인을 점검했다. 전달 문구 복사와 납품 뒤 준비 버튼을 닫고 납품 기록을 보여 주는 동작도 포함한다.
- **실제 HTTP 7개 통과:** 직원 인증·CSRF·현재 프로젝트 권한, 준비 저장·업로드·고객 접근 차단과 명시적 등록 후 자막 제공을 확인했다. 업로드 전 검사에 파일 이름이 빠지던 연결을 수정했다.
- **미디어 11개 통과·1개 건너뜀:** MP4·WebM·PNG·JPEG는 기존 미디어 검사를 사용하고 SRT·VTT의 UTF-8·확장자와 본문 일치·256 KiB 스트림 상한·중단 업로드 정리·보안 응답·HEAD/Range·전송 직전 권한 재검사를 확인했다. 자막은 유효한 원본 바이트를 보존한다. Windows 환경에서 파일 심볼릭 링크 생성 권한이 없어 해당 거부 시험 1개를 건너뛰었으며 통과로 세지 않았다.
- **백업·복구 7개 통과:** 회사 단독 백업, 통합 백업과 `cloud-volume` 격리 복구에서 여섯 파일 형식·원래 키·준비 기록을 대조했다. 승인 원본의 중복 제거, 제외한 자막의 파일 보존, 누락·위험 경로에서 완료 백업 차단도 확인했다. 실제 준비 API로 파일·안내를 저장하고 복구한 뒤에도 고객 화면·고객 알림·직원 알림·원문 프로젝트가 같고, 등록 전 자막은 고객 접근이 차단됨을 확인했다.
- **기존 고객 업무 회귀 26개 통과:** 기존 승인·문의·시안·최종본 흐름을 함께 확인했다.

실제 로컬 브라우저에서 **승인 시안 선택 → 필수 SRT 업로드 → 두 파일 직접 확인 저장 → 납품 등록 가능**을 확인했다. 사용자가 확인할 기본 예시는 고객 표시 전 상태로 남겼다. 별도 합성 시험 프로젝트에서 명시적 확인 후 최종본 2개를 등록하고, 고객 라운지의 납품 화면과 자막 다운로드를 확인했다. 내려받은 자막 바이트는 업로드 원본과 일치했다. 전달 문구 복사는 화면의 성공 안내까지 확인했으며 운영체제 클립보드 바이트 일치까지 입증하지는 않았다. [고객 납품 화면 기록](verification/client-delivery-20261012/customer-delivery.dom.txt).

1280·390·320px에서 문서 가로 넘침이 없고 모바일 납품 카드의 표시 중인 버튼이 화면 안에 있음을 확인했다. [PC 화면](verification/client-delivery-20261012/ready-desktop.png), [390px](verification/client-delivery-20261012/ready-mobile-390.png), [320px](verification/client-delivery-20261012/ready-mobile-320.png), [측정값](verification/client-delivery-20261012/responsive.json). 기존 브라우저 연결에서 실패했던 화면 캡처는 재연결 후 저장했다. 서버 재시작 후에도 준비 중 예시와 납품 완료 시험 기록이 유지되며 `/api/health`가 준비 완료를 반환했다. 기존 후속 연락 시험의 시간 의존 실패는 고정 시계와 토큰 만료 시계를 맞추는 시험 픽스처 수정으로 해결했고 운영 코드는 바꾸지 않았다.

자동 검사는 실제 내용·재생·소리·합의 규격·자막 타이밍·외부 자료 다운로드를 대신하지 않는다. 최종본 등록은 고객 인수 완료와 구분한다. 준비만 저장했을 때 고객 상태가 유지되는 경계와 현재 권한을 재확인하며, 외부 이메일·메신저 발송이나 AI 호출은 추가하지 않았다. [사용 흐름과 재사용한 설계 근거](WORKSPACE.md#고객-승인-후-최종본-납품-준비--2026-10-12-로컬).

이번 결과는 **합성 계정과 격리 데이터의 로컬 검증**이다. 운영 배포·실제 고객 공개·실사용 시간 절감은 아직 확인하지 않았다. 기존 `127.0.0.1:64046` 서버와 1~10번 예시를 보존했다. `.tmp/workroom-publishing-20261011/preview-ready.json`의 `deliveryUrl` 또는 [로컬 납품 준비](http://127.0.0.1:64046/?tab=workroom&section=clients&project=5ef370f6-4bcc-4f14-93e7-58206255e6d4&delivery=1)에서 확인하며 `preview.mjs`로 다시 연다. 새 정기 작업이나 외부 발송은 추가하지 않았다.

## 자동화 상태·누락 확인 · 2026-10-12 로컬

사용자가 승인한 **10번**을 기존 **제작 도구 → 자동화 상태**, 제작 데스크 바로가기, **마린 → 자동화 상태 확인해줘**, **메신저 → 내 업무 → 알림**에 연결했다. 1~9번의 현재 담당 원문을 읽어 실행·예약·꺼짐·오류와 직접 확인을 구분한다. 원본을 고치거나 예약을 다시 실행하는 별도 자동화는 만들지 않았다.

- 서비스·상태/알림·실제 HTTP·UI·마린·메신저·기존 게시/주간 예약 관련 23개 시험 파일 **317/317 통과**, 실패·취소·건너뜀 0. [최종 시험 로그](verification/automation-health-20261012/tests.txt). 대상 없는 과거 실패의 오경보 제외, 미래 예정·0 관측값·유예 시간·꺼짐·부분 실패, 소유/배정/현재 권한, 오래된 전달 오류, 읽음/해결 분리, 재시작 중복 방지, 실제 해결 후 재발, 권한 회수·일시정지 후 재표시, 세션/화면 이동 중 늦은 응답을 확인했다.
- 실제 브라우저에서 **내부 알림 1건 → 자동화 상태 → 오류가 난 정확한 게시 묶음 → 링크 다시 확인**을 열었다. 합성 HTTP 404를 200으로 바꾸자 문제 **1→0건**, 직접 확인 **14→15건**으로 바뀌고 메신저 알림은 **아직 알림이 없어요**로 해제됐다. 읽음만 처리했을 때 오류는 유지됐다. 사람이 확인해야 하는 영상·자료 점검은 완료로 바뀌지 않았다. 합성 예시의 상태 전이이며 실제 공개 사이트의 장애·복구 증거는 아니다.
- 마린의 「자동화 상태 확인해줘」에 **처리 문제 0건 · 직접 확인 15건**이 표시되고 같은 상태 화면으로 이동했다. [마린 화면](verification/automation-health-20261012/marin.jpg), [알림](verification/automation-health-20261012/notification.jpg), [해결 후 알림](verification/automation-health-20261012/notification-resolved.jpg).
- 1280·390·320px에서 문서·주 작업 영역 가로 넘침 0, 상태 카드 9개, 최종 브라우저 경고·오류 0. 60초 자동 갱신 전후 시각이 01:17→01:18로 바뀌면서 **#main 스크롤 958px·펼친 목록·포커스**가 유지됐다. 긴 목록은 첫 3건과 나머지 펼치기로 표시한다. [PC 결과](verification/automation-health-20261012/desktop-resolved.jpg), [상태 카드](verification/automation-health-20261012/status-cards.jpg), [390px](verification/automation-health-20261012/mobile-390.jpg), [320px](verification/automation-health-20261012/mobile-320.jpg), [측정·흐름 기록](verification/automation-health-20261012/browser-result.json).

서버 실행 중 60초마다 확인해 기존 메신저 내부 알림을 갱신한다. 같은 문제는 반복 생성하지 않고 현재 원문·권한을 다시 확인한다. 권한 회수·일시정지·조회 실패는 실제 해결로 처리하지 않는다. 원문 본문을 알림 저장소에 복사하지 않으며 기기 푸시·외부 게시·고객 발송·추가 AI 호출·Codex 예약 작업은 없다. 같은 서버의 전원/프로세스 종료를 외부에서 감지하지는 않는다. [사용 범위·설계 근거](WORKSPACE.md#자동화-상태누락-확인--2026-10-12-로컬).

같은 격리 데이터와 포트 `127.0.0.1:64046`를 유지했다. 시작 정보 `.tmp/workroom-publishing-20261011/preview-ready.json`의 `automationUrl`이 새 입구이며 `preview.mjs`로 다시 연다. 기존 합성 링크 응답 파일에서 404 예시 하나만 정상 응답으로 바꿔 해결 흐름을 확인했다. 실제 SNS 성과 수집은 꺼짐으로 표시한다. **운영 배포는 보류**하며 로컬 서버가 실행되는 동안 사용한다.

## 주간 업무·성과 자동 정리 · 2026-10-12 로컬

사용자가 이어서 진행하도록 승인한 **9번**을 기존 **제작 도구 → 주간 정리**, 제작 데스크 바로가기, **마린 → 지난주 정리해줘**에 연결했다. 본인이 현재 볼 수 있는 기록을 완료·게시, 해당 주 게시물의 72시간 성과, 현재 남아 있는 문제, 다음 주 일정·진행 중인 제작 실험 기획으로 모은다. 선택 기간은 KST 월요일~일요일의 완료된 최근 52주다. 확정본은 실제 제작 완료 시각을 추정하지 않고 **확정본 등록**으로 표시하며, 과거의 미완료 상태와 현재 문제를 혼동하지 않는다.

- 최종 서비스·실제 HTTP·UI·마린·게시/고객/메신저 연결·예약·백업 관련 **224/224 통과**, 실패·취소·건너뜀 0. [시험 로그](verification/weekly-summary-20261012/tests.txt). KST 주 경계, 현재 소유·배정·채널 권한, 계정 전환·권한 철회, 재개방한 업무, 비공개 원문 제외, 0/미확인/72시간 대기 구분, 부분 실패, 주간 중복 예약 방지, 종료·재시작, 월요일 기본 주 갱신을 확인했다.
- 실제 로컬 화면에서 **이전 주 선택 → 항목 펼치기 → 정확한 메신저 원문**, **다음 주 고객 일정 → 해당 연락 카드**, **현재 자료 오류 → 해당 게시 묶음의 링크 확인**을 열었다. 마린의 「지난주 정리해줘」 응답과 주간 정리 버튼 이동도 확인했다. 예시 주 10/5~10/11의 완료·게시 12, 성과 4, 현재 문제 8, 다음 주 준비 7건은 **합성 로컬 기록**의 집계이며 실제 업무 실적·SNS 성과를 입증하지 않는다.
- PC 1280px와 모바일 390·320px에서 문서·주 작업 영역 가로 넘침 0, 최종 경고·오류 0. [PC 화면](verification/weekly-summary-20261012/weekly-1280.jpg), [390px](verification/weekly-summary-20261012/weekly-390.jpg), [320px](verification/weekly-summary-20261012/weekly-320.jpg), [사용 흐름·측정 기록](verification/weekly-summary-20261012/browser-result.json).
- 실제 사용에서 발견한 메신저 원문 동작의 라벨 누락, 모바일 날짜 잘림, 자동 갱신 시 스크롤 초기화를 수정했다. 최종 화면에서는 **60초 자동 갱신 전후 #main 스크롤 1641.5px와 펼친 항목이 유지**되고 집계 시각만 갱신됐다. 직접 주를 바꿀 때는 새 기간의 처음부터 표시한다.

서버 실행 중 매주 월요일 지난주 정리를 준비하고, 꺼져 있었으면 재실행 시 가장 최근 완료된 주를 준비한다. 저장하는 주간 기록은 사용자·주·준비 시각만이며 원문 본문을 복제하지 않는다. 화면을 읽을 때 현재 권한과 원본으로 다시 집계하고, 주간 화면이 보일 때만 60초 갱신한다. 미래의 매주 실행 성공이나 고정 시점 보고서 스냅샷을 보증하지 않는다. [사용 범위·설계 근거](WORKSPACE.md#주간-업무성과-자동-정리--2026-10-12-로컬).

기존 격리 서버 `127.0.0.1:64046`와 1~8번 예시를 보존하고 주간 합성 예시만 추가했다. 시작 정보 `.tmp/workroom-publishing-20261011/preview-ready.json`, 실행기 `preview.mjs`, 주간 예시는 `seed-weekly.mjs`다. 사용자 요청대로 **운영 배포·외부 게시·고객 발송은 하지 않았다**. 새 AI 호출·Codex 정기 작업도 없다.

## 게시·자료 링크 오류 자동 확인 · 2026-10-11 로컬

사용자가 승인한 **8번**을 기존 **게시 준비·성과 → 링크 접속 확인 → 오늘 할 일 → 정확한 원본**으로 연결했다. 준비한 묶음의 자료 링크와 활성 게시 기록을 새로 확인하고, 서버 실행 중 마지막 검사 후 6시간이 지난 대상부터 한 번에 최대 10개씩 순차 확인한다. HTTP 응답 확인·접속 오류·직접 확인 필요를 구분하고 시각·응답 코드를 원본에 저장한다. 로그인·봇 차단을 삭제된 콘텐츠라고 단정하지 않으며 자동 검사는 기존 직접 점검을 완료시키지 않는다.

- 최종 서비스·실제 HTTP·UI·오늘 할 일·백업과 관련 게시 흐름 **274/274 통과**, 실패·취소·건너뜀 0. 저장된 원본만 검사, CSRF·현재 권한·세션 철회, URL 교체 중 늦은 결과 폐기, 최신 묶음 선택, 같은 요청 합치기, 60초 재확인 제한, 6시간 재확인, 중지·재개, 서버 재시작, 원본 URL 해시·최근 관찰 이력의 실제 백업/복원을 포함한다. [시험 기록](verification/publication-links-20261011/tests.txt).
- 로컬 브라우저에서 **오늘 할 일의 자료 오류 → 해당 묶음 → 링크 다시 확인 → HTTP 200**을 처리했다. 자료 오류 항목은 남은 직접 점검으로 돌아갔고, 작성 중인 게시 제목·점검 메모와 자료 직접 확인의 미확인 상태는 유지됐다. **게시 오류 → 해당 성과 기록 → HTTP 403 직접 확인 필요**로 바뀌면 오류 할 일만 사라졌다. 오류 할 일 **2→1→0개**, 전체 오늘 할 일 **8→8→7개**를 수동 새로고침 없이 확인했다. 이는 합성 응답으로 검사한 상태 전이이며 실제 SNS 장애·복구 근거가 아니다. [사용 흐름 기록](verification/publication-links-20261011/browser-result.json).
- 1280·390·320px에서 문서·주 작업 영역 가로 넘침 0, 최종 브라우저 경고·오류 0. [PC 링크 화면](verification/publication-links-20261011/links-error-1280.png), [390px](verification/publication-links-20261011/post-link-390.png), [320px](verification/publication-links-20261011/post-link-320.png), [직접 확인 필요](verification/publication-links-20261011/post-manual-320.png). 일반 점검 버튼 진입 시 첫 조회가 생략되던 경로, 점검 저장 뒤 재검사 제한 버튼, 비활성 게시 기록을 조회하던 경로를 보완하고 회귀 시험에 포함했다.
- 실제 HTTPS 프로브로 공개 예시 `https://example.com/`의 **HTTP 200 응답**을 1회 확인했다. 그 밖의 로컬 예시는 합성 200·404·403이며 실제 게시·재생·자료 다운로드·사용자 콘텐츠 권한 확인을 의미하지 않는다. 프로브는 공개 HTTPS, DNS/IP 고정·리디렉션 재검증, 전체 8초·64KiB 제한을 사용하며 쿠키·인증 헤더를 보내지 않는다.

벤치마킹의 공식 도구 5곳·사용 사례 3건과 적용 근거는 [기존 작업실 안내](WORKSPACE.md#게시자료-링크-접속-점검--오늘-할-일--2026-10-11-로컬)에 모았다. 사용자 요청대로 **운영 배포·SNS 게시·고객 발송은 하지 않았다**. 기존 격리 서버 `127.0.0.1:64046`에서 인박스·링크 타이머를 실행하며 링크 응답은 전용 합성 프로브를 사용한다. 기존 1~7번 예시는 보존했다. 시작 정보 `.tmp/workroom-publishing-20261011/preview-ready.json`, 실행기 `preview.mjs`, 예시와 응답 전환은 같은 폴더 `seed-links.mjs`·`link-responses.json`에 있다. 새 AI 호출·Codex 정기 작업은 없다.

## 고객 후속 연락 자동 연결 · 2026-10-11 로컬

사용자가 승인한 **7번**을 기존 **고객 관리 → 다음 연락일 → 오늘 할 일 → 내부 후속 연락**으로 연결했다. 현재 담당자에게 한국 시간 기준 오늘·지난 연락일만 표시하고, 결과 메모와 다음 날짜 예약 또는 연락 종료를 한 번에 저장한다. 고객 문의 처리와 별개이며 고객에게 보이는 다음 할 일·대화에는 내부 결과를 넣지 않는다.

- 서비스·실제 HTTP·UI·오늘 할 일·마린과 기존 고객 업무 회귀 시험 **194/194 통과**, 실패·취소·건너뜀 0. [시험 기록](verification/client-follow-up-20261011/tests.txt). KST 자정, 재배정·권한 철회, 미래/보관 제외, 반복 조회 무기록, 중복 저장 충돌, 정확한 링크, 내부 기록 비공개, 실제 통합 백업 복원 뒤 예약일 재등장을 포함한다.
- 실제 로컬 브라우저에서 합성 프로젝트의 **오늘 할 일 → 정확한 연락 카드 → 내일로 예약 → 다른 지난 연락 종료**를 처리했다. 전체 오늘 할 일은 **7→6→5개**, 고객 후속 연락은 **3→2→1개**였다. 미래 일정은 빠지고 종료된 연락의 결과·작성자·시각은 남았다. 새로고침 후 이력도 보존됐다. [사용 흐름 기록](verification/client-follow-up-20261011/browser-result.json), [PC 연락 화면](verification/client-follow-up-20261011/follow-up-1280.png), [390px](verification/client-follow-up-20261011/follow-up-390.png), [320px](verification/client-follow-up-20261011/follow-up-320.png).
- 1280·390·320px에서 가로 넘침 0, 최종 브라우저 경고·오류 0. 독립 검토에서 발견한 **409 뒤 오래된 일반 폼으로 최신 값을 덮을 수 있던 문제**, **저장 중 늦은 목록 조회가 결과를 되돌리던 문제**, 실제 모바일 확인에서 발견한 **초기 로딩 재렌더가 바로가기 초점을 지우던 문제**를 수정했다. 작성 중인 입력과 계정·프로젝트 이동은 보존하며, 새 날짜 표시는 입력 DOM을 교체하지 않는다.

이전 추천에서 **2026-10-11** 직접 읽은 [HubSpot 후속 업무](https://knowledge.hubspot.com/tasks/create-tasks), [Asana 날짜 규칙](https://help.asana.com/s/article/setting-dates-in-rules), [문의 기록은 있지만 다시 연락을 놓친다는 사용자 경험](https://www.reddit.com/r/smallbusiness/comments/1reuvvi/inquiries_and_then_follow_up_how_to_manage_them/)을 같은 목적의 근거로 재사용했다. 공식 도움말 2개·사용자 스레드 1개(작성자 경험과 관련 응답 1개, 2026-02~03)의 제한 표본이다. **고객 기록과 기한을 평소 보는 업무에 연결하는 장점**을 기존 다음 연락일·오늘 할 일·내부 이력에 적용했다. 인기·만족도 전수 비교나 실제 고객 누락 감소 효과를 입증한 결과는 아니다.

사용자의 **로컬 우선 확인** 요청에 따라 운영 배포·고객 자동 발송은 하지 않았다. 기존 격리 서버 `127.0.0.1:64046`에 합성 고객 예시를 추가했으며 원래 게시 자동화 예시를 보존했다. 확인용 시작 정보는 `.tmp/workroom-publishing-20261011/preview-ready.json`, 실행기는 같은 폴더 `preview.mjs`다. 신규 AI 호출이나 Codex 예약 작업은 없다.

## 최종본 기준 게시 전 점검 · 2026-10-11 로컬

사용자 요청의 **6번**을 기존 **게시 준비·성과 → 준비한 게시 묶음 → 게시 전 점검**과 **오늘 할 일**에 연결했다. 영상 버전과 정확한 게시 묶음에 기술·자막 검사, 전체 시청·청취·게시문 사실·소재 사용권·자막 내용·자료 링크의 직접 확인을 모은다. 남은 항목을 먼저 보여 주고 완료·해당 없음과 검사 근거는 접어 둔다. 검사 결과는 생성 당시 측정값이며 직접 검토와 구분한다.

- 서비스·실제 HTTP·클라이언트·오늘 할 일·메신저·백업·기존 게시/작업실 관련 **224/224 통과**, 실패·취소·건너뜀 0. 새 영상·원고·자막 묶음의 확인 미승계, 같은 묶음 재사용, 확인자·시간·메모, 기술 오류의 수동 해제 금지, 권한 철회·읽기 전용·CSRF·동시 revision 충돌, 서버 재시작, 일반/통합 백업의 실제 복원을 포함한다. [시험 로그](verification/publication-review-20261011/tests.txt).
- 격리된 로컬 화면에서 **기존 완성본 → 새 묶음 → 직접 확인 저장 → 수정 필요 사유 필수 → 점검 완료 → 오늘 할 일의 게시 주소 기록**을 확인했다. 저장 중 채널 영상의 재생 시간이 계속 진행했고 별도 게시문 초안은 유지됐다. 오늘 할 일의 **남은 점검 확인**이 정확한 묶음을 여는 것도 확인했다.
- 같은 제작 건에 합성 MP4를 새 버전으로 실제 업로드했다. 이전 묶음은 **이전 버전 + 점검 완료** 기록을 보존하고, 새 버전 묶음은 직접 확인 5개가 모두 미확인으로 시작했다. 링크가 없는 항목은 시스템 해당 없음으로 별도 표시했다. 이는 합성 자료의 상태 전이 시험이며 실제 콘텐츠의 품질·사용권 승인이나 전체 소리 청취 완료를 입증하지 않는다.
- PC 1280px와 모바일 390·320px의 문서·주 작업 영역 가로 넘침 0, 최종 검증 탭의 경고·오류 로그 0. [PC 화면](verification/publication-review-20261011/review-1280.jpg), [390px](verification/publication-review-20261011/review-390.jpg), [320px](verification/publication-review-20261011/review-320.jpg), [화면 검증 기록](verification/publication-review-20261011/browser-result.json).
- 독립 검토와 실제 UI 확인에서 발견한 **점검 저장 중 다른 묶음 이동 경합**, **숨긴 기존 영상 재생**, **메신저의 새 점검 종류·링크 허용 누락**을 수정하고 관련 회귀를 포함해 위 224개를 통과했다. 기존 개인 파일 점검·품질 운영 기록은 영상 버전과 직접 연결되지 않으므로 새 묶음의 확인으로 복사하지 않는다.

설계 근거는 앞선 추천에서 본 내용을 **2026-10-11** 다시 확인했다. [Frame.io/Workfront의 검토 연결](https://blog.frame.io/2026/03/31/new-in-frame-io-workfront-integration-improvements-for-share-builder-pdfs-and-zoom-pan/)과 [Planable의 확인자·시각 및 승인 취소](https://help.planable.io/hc/en-us/articles/28043963146140-Approving-content/)를 참고해 같은 제작 흐름 안에 확인과 재검토를 배치했다. [수정 의견 수집 경험 스레드](https://www.reddit.com/r/VideoEditors/comments/1ucmlwj/editors_whats_the_most_annoying_part_of_client/)의 응답자 2명은 이메일 요약·통화 또는 Notion 정리/알림을 사용한다고 설명한다. 검토할 대상을 한곳에 모으는 편의를 채택하되, 해당 기능의 효과가 검증된다는 뜻은 아니다. 공식 서비스 2곳·사용자 스레드 1개 응답 2명의 제한 표본이며 후기 화면은 약 3개월 전으로 표시돼 정확한 게시일은 확정하지 않았다. 인기·평점 전수 비교나 생산성 개선율을 주장하지 않는다. 버전·묶음별 확인 미승계는 이 근거를 바탕으로 정한 SYNK의 설계다.

사용자 **「이것도 우선 로컬로 확인할게」** 요청대로 같은 격리 확인용 서버 `127.0.0.1:64046`를 유지했다. **운영 반영·외부 게시·외부 수집·새 AI 호출 없음**. 실행기는 `.tmp/workroom-publishing-20261011/preview.mjs`, 현재 시작 정보는 같은 폴더의 `preview-ready.json`이다.

## 72시간 성과에서 다음 기획 · 2026-10-11 로컬

사용자 요청의 **5번**을 기존 **게시 준비·성과 → 게시 후 성과 → 콘텐츠 기획**에 연결했다. 72시간에 확인한 지표와 비교 가능한 이전 기록으로 회고·실험 후보를 만들며, 선택한 실험은 기존 기획의 **이번 편 제작 실험**에 보관한다. 제작자용 성과 기록을 영상 대사·시청자 행동이나 내용의 사실 근거에 자동으로 섞지 않는다.

- 최종 서비스·실제 HTTP·클라이언트·기획 엔진·게시 준비/인박스/오늘 할 일/백업 관련 **444/444 통과**, 실패·취소·건너뜀 0. 현재 권한·CSRF·타인/뷰어 차단, 0/미확인, 같은 계정·형식·출처·단위·관측 조건, 이전 게시물 3편, 반복 조회 무저장, 원본 보존, 교체 취소·응답 경합을 포함한다. 10개 시리즈에서 제작 실험 메모가 생성 대사·시청자 행동을 바꾸지 않는 것도 검사했다. [시험 로그](verification/publication-learning-20261011/tests.txt).
- 격리된 로컬 예시에서 **회고 → 첫 3초 실험 선택 → 기존 기획 → 구성안 저장 → 기획함에서 재열기**를 직접 확인했다. 실험·수치·출처는 별도 단락에 남고 시청자용 대사에는 섞이지 않았다. 작성 중인 기획의 **유지 / 교체**도 확인했다. [저장 결과](verification/publication-learning-20261011/saved-plan-1440.png).
- 성과 화면에서 좋아요 **0**을 새로 기록한 뒤 새로고침 없이 회고가 **확인된 지표 4개 → 5개**로 갱신됐다. 비교 가능한 지표는 4개로 유지됐고, 작성 중인 게시 제목도 유지됐다. 목표 시각보다 이른 관측 입력은 거절되고 입력이 남는 것도 확인했다.
- PC 1440px, 모바일 390·320px에서 회고 카드, 320px에서 저장 기획의 제작 실험이 가로 넘침 없이 표시됐다. [PC](verification/publication-learning-20261011/learning-1440.png), [실험 선택](verification/publication-learning-20261011/learning-experiments-1440.png), [모바일](verification/publication-learning-20261011/learning-320.png), [검증 기록](verification/publication-learning-20261011/browser-result.json).

2026-10-11 앞선 추천에서 확인한 [Metricool Posts Library](https://help.metricool.com/posts-library-u05cj)의 분석에서 다음 콘텐츠로 이어가는 기능과 [분석 도구를 중복 사용하는 부담에 관한 사용자 글](https://www.reddit.com/r/socialmedia/comments/1u41dk6/is_my_analytics_viewing_overkill/)을 이번 연결의 근거로 재사용했다. 공식 도움말 1개·사용자 스레드 1개(작성자와 응답자 2명, 2026-06 게시)의 제한 표본이다. 별도 성과 대장을 늘리지 않고 현재 원본에서 다음 실험으로 이어지도록 적용했으며, 실제 시간 절감·콘텐츠 성과 개선을 입증한 것은 아니다.

사용자 요청대로 **운영 미반영·공개 게시 없음**이다. 로컬 데이터의 비교 3편과 대상 1편은 합성 수치다. 외부 수집을 차단한 격리 서버를 같은 `127.0.0.1:64046`에서 유지하며, 실제 SNS 수집 결과나 사용자의 콘텐츠 품질 승인으로 보고하지 않는다. 이번 연결은 새 AI 호출이나 정기 Codex 작업을 만들지 않는다.

## 게시 다음 할 일 자동 연결 · 2026-10-11 로컬

사용자 요청의 **4번**을 기존 **내 작업실 → 내 할 일 → 오늘 할 일**에 연결했다. 완성본·채널별 묶음·게시 기록·24/72시간 관측의 현재 상태에서 다음 행동을 계산한다. 별도 할 일이나 알림을 중복 저장하지 않으며, 기존 마린의 오늘 할 일 답변에도 같은 원본 상태를 합산한다. 새 AI 호출은 없다.

- 실제 로컬 화면에서 **확정본 도착 → 영상 확인·게시 준비 → 두 채널 묶음 → Shorts 게시 주소 등록 → 24시간 수치 보완 → 조회수 0 기록**을 처리했다. 단계별 오늘 할 일은 **3→4→5→5→4개**, 새 확인용 완성본 도착 후 **5개**였다. Shorts 처리 뒤 Reels는 남고, 기록을 마친 24시간 항목과 아직 미래인 72시간 항목은 목록에 없다. 각 바로가기가 정확한 원본·묶음·보완칸을 열었다.
- 수동 새로고침 없이 새 완성본이 나타났고, 작성 중이던 메시지 초안과 포커스는 유지됐다. 시험 초안은 전송하지 않고 비웠다. 최종 서버 재시작·브라우저 새로고침 뒤 5개 상태를 확인했다. 1440·390·320px에서 부모/메신저 가로 넘침 0, 최종 브라우저 경고·오류 로그 0. [실제 화면 기록](verification/publication-workday-20261011/browser-result.json), [PC](verification/publication-workday-20261011/today-1440.jpg), [390px](verification/publication-workday-20261011/today-390.jpg), [320px](verification/publication-workday-20261011/today-320.jpg).
- 최종 소스로 서비스·실제 HTTP·클라이언트·마린·메신저와 기존 게시 준비/인박스/성과/백업을 함께 검사해 **325/325 통과**, 실패·취소·건너뜀 0. 권한 철회·타인/뷰어 차단·반복 조회 무기록·원본 보존·중복 방지·조회 실패 표시·늦은 응답·입력/선택/모달 보존을 포함한다. [시험 로그](verification/publication-workday-20261011/tests.txt).
- 검토에서 발견한 **실제 성과 ID(64자리 해시) 링크 차단**, **이전 묶음에 연결된 형식 미지정 기록의 복구 충돌**을 고쳤다. 형식이 모호한 기존 기록은 원래 묶음과 주소로 보완하고, 시각·기존 수치는 보존한다. 여러 기록은 각각 구분하며 수정할 수 없는 기록의 복구 업무는 표시하지 않는다. 보완 후 남은 규격만 최신 묶음으로 연결한다.
- 이번 결과는 합성 계정·영상·가상 게시 주소·합성 수치를 사용한 **로컬 검증**이다. 사용자의 「이것도 우선 로컬로 확인」 요청에 따라 운영 배포·실제 SNS 게시·실계정 수집은 하지 않았다. 기존 확인용 서버를 유지하며 외부 수집/기존 예약은 끄고 로컬 인박스만 실행한다. 자동 목록 갱신은 회사 통합 화면에서 오늘 할 일이 보일 때 작동하며, 운영 푸시나 아침 정기 요약을 추가한 것은 아니다.

이번 확장은 **2026-10-11** 확인한 [Asana 날짜 규칙](https://help.asana.com/s/article/setting-dates-in-rules), [Metricool 상태 알림](https://help.metricool.com/types-of-notifications-in-metricool-ynqf8), [승인 대기·상태 탐색 불편에 대한 사용자 스레드](https://www.reddit.com/r/socialmedia/comments/1shocsl/the_real_bottleneck_at_our_agency_isnt_content/)의 작성자·응답자 경험을 참고했다. 공식 서비스 2곳·사용자 스레드 1개(경험 2개)의 제한 표본이며, 후기의 정확한 게시일은 검색/열람 상대 날짜가 달라 확정하지 않았다. **현재 상태와 다음 행동을 한곳에 보여 주는 장점**을 원본 단계별 목록과 바로가기로 적용했다. 시간 경과만으로 승인하거나 게시를 실행하지 않는다. 인기·평점 전수 비교나 실제 업무 시간 절감 효과를 입증한 결과는 아니다.

## 완성본 자동 가져오기 · 2026-10-11 로컬

사용자 요청의 **3번**을 기존 **작업실 → 제작 도구 → 게시 준비·성과**에 연결했다. 제작자가 최종 확정 시 `tools/완성본등록.mjs`로 영상·선택 자막·게시문을 계정별 지정 폴더에 전달하면, 실행 중인 로컬 서버가 자동 등록하고 게시 초안을 준비한다. 모든 영상 렌더러의 종료 이벤트에 연결한 상태는 아니며, 파일만 복사한 미완성 작업은 가져오지 않는다.

- 실제 로컬 화면에서 자동 가져오기를 켠 뒤 전달 명령을 실행했다. 수동 스캔·새로고침 없이 도착했고, **게시 준비에 넣기 → 기존 초안 유지/교체 → 영상·자막·게시문 불러오기 → 두 채널 ZIP 생성·다운로드 → 변환 영상 재생 완료(3초)**를 확인했다. 동일 자료 재전달은 기존 완성본을 재사용했다. 합성 계정·테스트 패턴 영상이며 실제 콘텐츠의 시청·청취 승인 근거가 아니다.
- 자동 도착 시 작성 중인 게시문과 포커스를 보존했다. 실제 `.main` 스크롤을 보정하지 않던 문제를 고친 후 재확인한 입력칸 위치 변화는 **0.19px 미만**이었다. 1440·390·320px 가로 넘침 0, 브라우저 경고·오류 로그 0. [확인 기록](verification/publication-inbox-20261011/browser-result.json), [PC 화면](verification/publication-inbox-20261011/inbox-1440.jpg), [390px 화면](verification/publication-inbox-20261011/inbox-390.jpg), [320px 화면](verification/publication-inbox-20261011/inbox-320.jpg).
- 최종 변경 후 전달 도구·인박스 서비스·HTTP·클라이언트·백업과 기존 게시 묶음·성과·작업실 회귀 **134/134 통과**, 실패·취소·건너뜀 0. 확정 표시·원본 변경·해시·중복·동시 전달·재시작·DB 롤백·계정/세션 철회·중지·실제 5초 자동 스캔·원격 설정 거절을 포함한다. Windows 파일 심볼릭 링크 생성 권한은 없어 그 하위 시나리오를 실행하지 못했고, 디렉터리 junction 차단은 실제 확인했다. [시험 로그](verification/publication-inbox-20261011/tests.txt).
- 표준 백업을 실제 복원해 설정·전달 기록·게시 초안·등록 영상 SHA 보존과 재스캔 중복 방지를 확인했다. **아직 가져오지 않은 전달 폴더와 `.partial`은 백업 대상이 아니다.** 제작 원본은 원래 위치에 보존된다.
- 사용자의 **「이것도 우선 로컬로 확인」** 요청에 따라 같은 격리 미리보기를 유지했다. 로컬 인박스 확인만 5초 간격으로 켰으며 외부 수집·SNS 게시·운영 배포는 실행하지 않았다. 사용법과 제작 마감 명령은 [작업실 안내](WORKSPACE.md#확정된-완성본-자동-가져오기--로컬)에 있다.

설계 참고는 **2026-10-11** 공식 서비스 3곳과 실제 사용자 스레드 4개를 확인한 제한 표본이다. 후기의 상대 날짜·검색 색인이 달라 정확한 게시일은 확정하지 않았으며, 인기·평점 전수 비교나 최고 서비스 판정으로 해석하지 않는다.

| 근거 | 적용한 장점과 확인 결과 |
| --- | --- |
| [Adobe Media Encoder Watch Folder](https://helpx.adobe.com/media-encoder/desktop/encoding-quick-start-and-basics/overview-media-encoder-user-interface.html), [AE 제작자의 전달 과정 경험](https://www.reddit.com/r/AfterEffects/comments/1wow7x3/help_media_encoder_hot_folder_ae/) | 제작 마지막에 한 번 전달하면 기존 작업으로 이어지는 방식. 확정 명령 이후 자동 도착과 초안 연결을 확인했다. |
| [Frame.io Watch Folders](https://updates.frame.io/introducing-watch-folders-for-mac-os-60866), [사용 경험](https://www.reddit.com/r/editors/comments/1tpopov/frameio_is_good_again/), [폴더·버전 불편 경험](https://www.reddit.com/r/editors/comments/1p5mcd4/frameio_frustrations/) | 지정 폴더와 등록 상태를 눈에 보이게 유지하고, 기존 버전·입력 내용을 보존한다. 화면 도착·초안 교체 확인·동일 원본 재사용으로 검증했다. |
| [Dropbox 충돌 설명](https://help.dropbox.com/organize/conflicted-copy), [폴더 충돌 사용자 경험](https://community.dropbox.com/en/discussion/860619/why-were-conflicted-copies-of-my-folders-created-on-some-connected-devices) | 같은 완성본의 중복과 덮어쓰기를 피한다. UUID·파일 해시로 재전달을 구분하고 원본·기존 초안을 보존한다. |

완료 표시와 준비 폴더의 마지막 이름 변경은 위 서비스가 같은 방식으로 구현했다는 주장이 아니라 SYNK의 파일 전달 설계다.

## 게시 준비·성과 연결 · 2026-10-11

기존 **작업실 → 제작 도구**에 완성본 저장 → 채널별 게시 묶음 → 게시 주소·시각 등록 → 24·72시간 성과를 연결했다. 숨겨 둔 제작 보드·검토실 메뉴는 복원하지 않고 기존 영상 저장·파일 권한을 재사용했다. 기술 검사는 실제 영상 시청·청취에 의한 품질 판단을 대신하지 않는다.

- 격리된 합성 계정과 테스트 패턴 영상으로 **브라우저 9개 확인 항목 통과**: 기존 작업실 진입, 실제 업로드·변환, 두 채널 영상이 든 ZIP 다운로드, 생성 영상의 브라우저 재생 시간 진행, 게시 준비의 1440·390·320px, 게시 등록과 두 확인 시점, 미지원 수치의 수동 기록·관측 시각, 성과 화면의 1440·390·320px, 새로고침 뒤 자료 복원. 페이지 오류 0, 외부 요청 0. [실행 결과](verification/publication-20261011/browser-result.json), [PC 준비 화면](verification/publication-20261011/prepare-entry-1440.png), [모바일 성과](verification/publication-20261011/checkpoint-390.png).
- 신규 서비스·HTTP·클라이언트·백업과 기존 제작 점검·작업실·백업 회귀를 함께 실행해 **106/106 통과**, 실패·취소·건너뜀 0. 실제 FFmpeg 변환·원본 해시 보존·ZIP 파일·인증된 영상 Range 재생·타인 차단, 재시작/동시 수집·관측 창·권한 철회·중지, 미지원 null/확인0·수동 보완 출처·비교 조건, 등록된 원본/변환본 백업을 포함한다. [전체 시험 로그](verification/publication-20261011/tests.txt). 최종 서버/게시 묶음 서비스 독립 검토에서 명백한 P0~P2 문제는 발견하지 못했다.
- 현재 확인 범위는 **로컬 소스와 격리 시험**이다. 운영 DB에 시험 자료를 등록하지 않았고 실제 SNS 게시·실제 24시간 경과·실계정 수집·공개 서버 반영을 입증한 결과는 아니다. 최초 브라우저 실패는 동적 시험 포트와 서버 Origin의 불일치였으며 시험 주소를 맞춰 해결했다. 운영 서버의 Origin 검사를 완화하지 않았다.
- 사용자가 **「우선 로컬 결과만 확인할게요」**를 선택해 운영 반영을 보류했다. `.tmp/workroom-publishing-20261011/preview.mjs`로 별도 확인용 DB·계정·영상·합성 성과를 준비하고 Codex 브라우저에서 기존 작업실의 새 화면을 열어 확인했다. 이 미리보기는 외부 수집과 기존 예약 실행을 끈 상태이며, 위 3번 확인을 위해 로컬 완성본 자동 가져오기만 켰다. 실행 주소·PID는 같은 폴더 `preview-ready.json`에 있으며 일회용 시작 토큰을 외부 공유하지 않는다. 재개 시 이 로컬 미리보기와 실제 운영 상태를 구분한다.

기존 흐름 확장을 위한 설계 근거는 **2026-10-11** 확인했다. 공식 기능 3개 서비스와 아래 사용자 후기 3개 스레드의 경험 진술 5개를 선택한 제한 표본이며, 인기·평점 전수 비교나 최고 서비스 판정은 아니다. 창업자·판매자의 자사 도구 홍보는 채택 근거에서 제외했다.

| 원문 근거 | 채택한 장점과 SYNK 적용 | 확인할 결과 |
| --- | --- | --- |
| [Metricool 네트워크별 편집](https://help.metricool.com/multiposting-edit-per-social-network-85out), [영상 편집·크기 조정](https://help.metricool.com/edit-images-and-videos-while-scheduling-your-content-wputz), [Later 게시 흐름](https://later.com/social-media-scheduler/) | 한 원본에서 채널별 결과로 이어지는 연속 작업. SYNK는 승인한 원본을 유지하며 세 영상 규격·게시문·자막을 실제 파일로 묶고 생성물 재생을 연결했다. | 원본 선택부터 ZIP 수신까지 다른 관리 화면 없이 완료, 결과 영상의 실제 재생. |
| [Buffer Insights 공식 도움말](https://support.buffer.com/en-us/articles/using-insights-in-buffer-x4gLauQU5a), [Metricool 대 Buffer 경험 비교](https://www.reddit.com/r/SocialMediaManagers/comments/1vmlbty/thoughts_on_metricool_vs_buffer/)의 양쪽 사용 경험 1개(열람 화면에 약 2개월 전으로 표시, 정확한 날짜 미확정) | 단순한 게시 흐름과 게시물별 분석을 같은 장소에서 확인하는 편의. SYNK에서는 해당 콘텐츠의 24·72시간 결과, 미지원 값, 같은 계정의 비교 표본을 연결했다. | 조회수 0과 미확인 구분, 지표별 관측 시각·출처 확인, 결과 재열기. |
| [Metricool 대 Buffer](https://www.reddit.com/r/DigitalMarketing/comments/1pznl70/metricool_vs_buffer/)에서 일정 날짜 오류·분석 기능 경험 2개(2025-12-30~2026-01-02), [예약 도구 불편](https://www.reddit.com/r/SocialMediaMarketing/comments/1tkbwzm/what_is_the_most_annoying_thing_about_social/)에서 복잡한 화면·실제 게시 화면과 자르기 불일치 경험 2개(2026-05-22) | 날짜와 상태를 명확히 하고 미리보기만으로 완료를 판정하지 않는 방향. SYNK는 KST 게시 시각, 예정·실제 관측 시각, 늦은 수집과 놓친 시점, 다운로드한 실제 변환 파일을 구분한다. | 시간대가 다른 브라우저에서도 같은 예약 시각, 놓친 시점의 과거 수치 위조 없음, 320px 사용 가능. |

## Studio·SHIFT 사내 작업실 통합 · 2026-10-02

Studio의 사내 제작 기능을 기존 제작 데스크·제작 도구로 정리하고 SHIFT 실습을 **AI 업무 연습**으로 연결했다. 새 외부 기업 고객 공간은 만들지 않았다. 회사·공유모델104개, 합성 계정 실제Chrome32항목, desktop132개·실제Electron 라이브러리87항목·다운로드4항목을 통과했다. 계정별 선택 저장·초안/커서·3종 실습 완료/TXT 수신·모바일 크기를 확인했으며 기존 로그인으로 로컬4191의 새 화면을 확인했다. 늦은 계정 응답의 로그인 복원과 없는 연습 유형을 추천했다는 설명도 수정했다. [변경·백업·한계·검증 원문](verification/workroom-practice-20261002/README.md).

## 공통 최적화·작업실 제작 도구 · 2026-10-02

기존 작업실의 **제작 도구**에 **게시 전 점검 / 자막 검사 / 승인 제작 자료**를 연결했다. 시청자 가치·스토리·브랜드·출처·반응 등9항목은 작업별 개인 기록으로 저장한다. 파일 규격 읽기·자막 처리는 브라우저에서 수행하며 원본을 업로드하거나 덮어쓰지 않는다. 승인 자료15개·서체OFL3개·외부 사용권 안내4곳을 제공한다. 기존 소재함·트렌드·메신저·계정 자료를 보존하며 주요 메뉴와 같은 체크 화면을 반복하지 않는다.

- 관련22검사 파일 **229/229 통과**. 최종 화면 마감 후 작업실/이동/게시 점검 **60/60 재통과**. 권한·개인 격리·동시 수정·보관/복원·늦은 요청·파일 취소, 실제HTTP/로그인/CSRF/허용 파일, 자막 형식/원문 유지, 정적 재검증·SQL 최신성·기존 메신저/조직/SYNK ID/백업·준비 상태를 포함한다. 최종 검수에서 발견한 옛 체크가 새 양식에 따라오는 문제는 별도 재현·수정·회귀 **52/52**로 닫았다. 마지막 실제 앱에서도 새 복사 양식의 빈 체크9개·완료 체크0개를 확인했다. 해당 수정 후 전체230개를 다시 실행한 것으로 표현하지 않는다.
- 격리 크루에서PNG/MP4 규격 읽기→9항목 메모 저장→재열기→보관/복원→새로고침, Markdown 실제 수신, 유효/잘못된 자막→원고 복사·정리본 실제 수신/차단, 마스코트 검색·서체/OFL 조건·SVG 실제 수신을 확인했다. SVG의SHA256은 승인 원본과 같다. 열람 계정의 저장 제한·타인 기록 비노출·로그아웃 시 자막 비우기도 실제 확인했다.
- 최종 정식4191·실제 계정에서PC1280×720와 세 도구390×844/320×740를 다시 확인했다. 가로 넘침0·자료 미리보기 깨짐0·콘솔 경고/오류0. 자료 사용 조건 모달은390/320에서도 범위 안에 들어온다. 임시 viewport는 해제했다. [화면·측정 JSON·검사·완료 대조](verification/creator-tools-20261002/README.md).
- 동일 기존39개 공개 정적 자산의 첫 전송 본문1,698,519→1,000,103bytes(약41.1% 감소), 조건부 재요청39/39가304. 압축·준비문·formatter 재사용과 폴링 겹침 방지이며 HTML/API/개인 파일의no-store·현재 권한 재확인을 유지한다. 화면 전체 로딩/직원 생산성 개선율로 표현하지 않는다. [성능 원시 비교](verification/optimization-20261002/README.md).
- 외부 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-10-01T22-05-50-771Z` **COMPLETE** 확인 후 공식 실행기로 적용했다. 기존 회사 문서(creative research 포함)/자격증명·메신저6테이블·Drive/데모/key/integration 전후해시 동일,1계정·5방·메시지/파일0 유지. 마지막health는ok:true/ready:true이며 새 합성 점검 기록은 운영에 저장하지 않았다. 현재PC 로컬 반영이다.

## 홈 이름 통일 · 2026-10-01

상단 이동 버튼과 로고 링크의 접근성 이름을 **홈**으로 통일하고 홈 준비 화면·현재 사용 안내에도 같은 명칭을 적용했다. 정적 파일로 실행 중인4191에 반영했다. 기존 홈/화면 이동 검사26/26 통과(`verification/home-label-tests.txt`), 실제 계정의 홈→마케팅 왕복과 대화 유지, 상단 **홈** 표시·예전 명칭 비노출·콘솔 경고/오류0을 확인했다. 화면 `verification/home-label-live.png`.

- 후속 로고 연결: 홈 왼쪽 위 **싱ㅋ**를 실제 `/?tab=home` 링크로 만들고 공통 메뉴 로고도 같은 주소로 연결했다. 일반 클릭은 기존 화면 이동 기능을 사용해 전체 페이지 새로고침을 막고, 수정 키로 여는 링크는 브라우저 기본 동작을 유지한다. 기존 네 메뉴 검사에서 로고 링크와 메뉴 버튼을 구분하도록 수정 후26/26 통과(`verification/brand-home-link-tests.txt`). 실제 메뉴 로고 클릭→홈 이동, 홈 로고의 Enter 이동·키보드 초점 표시·기존 대화 유지와 콘솔 경고/오류0 확인. 화면 `verification/brand-home-link-live.png`. 정적 파일로4191에 반영했다.

## 회사 안내 단순화·한눈에 보기 · 2026-10-01

사용자의 후속 요청에 따라 **운영·공간 / 회사·브랜드**를 회사 안내에서 제외했다. 중복 카드·바로가기·전체 문서 접기 목록을 없애고 **한눈에 / 직원 안내 / 학생 복지 / 수업 기준 / 상담 안내**로 정리했다. 첫 화면은 세 영역의 핵심을 두 항목씩 보여 주며, 분야 안에서는 항목·내용·조건을 비교하고 필요한 원문만 연다. 관련 원문17개를 유지하며 제외한 파일은 삭제하지 않았다. 핸드북·학생 복지·커리큘럼·주간 교안은 요약이 먼저 나오고 전체 원문으로 전환한다.

- 최종 관련 자동 검사 **64/64 통과**, 실패·취소·건너뜀0. `verification/company-guide-clean-tests.txt`. 안내8개 검사에서 17문서/4분야·제외 분야 비노출·요약과 실제 원문 제목 일치·현재 복지7개/직원 미정3개, 활성4역할/비로그인/권한 철회/임의 파일 차단, HTML·위험 링크 탈출, 검색·발췌·분류 복귀, 늦은 응답·계정 전환, 코드 제목 제외·인용문 표·원문 링크, 첫 화면3영역6항목·요약/전체 전환을 확인했다. 기존 홈·메뉴·데모·작업실·서버 회귀 포함.
- 격리 일반 크루에서 직원 복지6항목·학생 혜택7가지·수업 기준6항목·상담4문서, 학생 복지 요약→전체 원문→목차 이동, 「6개월 이상」 검색2문서/강조→읽기→검색 유지 복귀를 CUA로 확인했다. 강사 원문 앞에 옛20분 표를 사용하지 않는 안내가 보인다. 실제 운영 계정에서도 새 첫 화면·학생7가지·요약 읽기·복귀를 확인했다.
- PC1280px·실제1133×704px는 세 영역을 나란히 읽는다. 554×704px에서는 핵심6항목과 각 적용 상태가 첫 화면에 보인다. 390px·320px에서는 세 영역을 세로로 읽는다. 스크롤바를 제외한 문서/스크롤 너비는554px에서539/539,390px에서375/375,320px에서305/305로 가로 넘침0.390px 원문의337px 표 영역 안에서480px 표만 자체 스크롤된다. 테스트 크기 설정은 해제하고 검증 탭·서버를 종료했다.
- 새로고침 중 초기 resize가 app.js의 상태 선언보다 먼저 실행될 때 발생한 기존 마린의 ReferenceError를 상태 준비 여부 확인으로 수정했다. 최종 관련 검사 재통과 및 실제 운영 탭 콘솔 경고·오류0을 확인했다. 복지·규정 원문과 시행 예정/미정 표시는 보존했고 새 규정·혜택 지급을 만들지 않았다.
- 정확한 운영 프로세스 경로 확인 후 중지, 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T19-06-56-539Z`의 **COMPLETE** 확인 뒤 공식 숨김 실행기로4191 재시작, ready:true 확인. 회사 문서/자격증명·메신저6테이블·Drive 설정·그래프 데모의 전후 해시 동일. 회사1계정·팀0·채널34개·업무 프로필0, 메신저1계정·방5개·메시지/파일0 유지. 일회용 시작 링크는 소비 후 임시 파일을 삭제했다. 현재 PC 로컬 반영이다.

화면: `verification/company-guide-clean-live.png`(실제 첫 화면), `company-guide-clean-preview.png`, `company-guide-clean-554.png`, `company-guide-clean-390.png`, `company-guide-clean-320.png`, `company-guide-clean-welfare-390.png`. 이전 확장 화면의 검증은 아래에 이력으로 유지한다.

## 회사 안내 자료 확장·읽기 화면 · 2026-10-01

사용자 요청에 따라 회사 안내를 관련 원문32개·6분야로 확장했다. LAB 운영 원본14개를 모두 연결하고 최신 학생 복지·커리큘럼·포토부스·공간/하루 운영·약관/개인정보·회사 소개·FAQ·콘텐츠 제작 원문을 추가했다. 첫 화면은 분야6개와 자주 찾는 안내4개, 전체 목록은 분야별 접기다. 분야 안에서는 짧은 문서 행·바로가기, 검색에는 본문 발췌/검색어 표시를 제공한다. 복지·커리큘럼의 핵심→원문 이동, PC 목차/휴대폰 접힌 목차, 등록된 원문 사이 상대 링크·관련 문서로 이어 읽기를 제공한다.

- 최종 관련 자동 검사 **64/64 통과**, 실패·취소·건너뜀0. `verification/company-guide-library-tests.txt`. 회사 안내8개 검사에서 원문32개/중복 없음/LAB14개 포괄, 6분야·바로가기/요약의 실제 제목 존재·관련 문서 연결, 활성4역할/비로그인/권한 철회/임의 파일 차단, HTML·위험 링크 탈출, 본문 검색·발췌·분류/목록 복귀, 오류 재시도·계정 전환의 늦은 응답 차단, 코드 속 제목 제외·인용문 안 표와 목차 일치, 전체 원문·핵심/관련 자료 렌더링을 확인했다. 기존 홈·메뉴·데모·작업실·서버 검사를 함께 통과했다.
- CUA 격리 일반 크루에서 분야→학생 복지·목차/요약→원문, 「6개월 이상」 본문 검색2문서·검색어 강조·읽기/목록 복귀, 최신 커리큘럼·직원 복지 바로가기를 확인했다. 실제 운영 계정에서도6분야·32문서, 학생 지원5문서와 게시 전 수강약관, 원문 속 「학생 복지 정본」 버튼→학생 복지 원문 이동을 확인했다. 최종 운영 탭 경고·오류0.
- PC1280px은3열×2행 분야 화면과 왼쪽 목차, 390px은2열 분야 화면, 320px은1열로 읽힌다. 본문 페이지/스크롤 너비390/390,320/320으로 넘침 없음. 390px에서352px 표 컨테이너 안의480px 표만 자체 스크롤된다. 학생 복지 원문 이동 뒤 제목 위치30.19px, 직원 복지 원문 이동 뒤29.81px 확인. 모바일 크기는 복원하고 격리 검증 탭/서버는 종료했다.
- 학생 복지는9/29 최신7개 혜택과 미정 절차, 직원 복지는개원 시작2개/예산 없는3개, 커리큘럼은9/18 기준의90분·그룹별 발화30분/1년 목표TOPIK4급·전체 상한5급을 구분한다. 옛20분 원문은 보존하고 현행 정본을 앞에서 연결한다. 약관의 게시 전 조건·공간 설계 상태도 유지하며 규정 자체·인사·혜택 지급은 실행하지 않았다.
- 운영 프로세스의 정확한 경로 확인 후 중지, 외부 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T17-54-59-742Z`의 **COMPLETE** 확인 후 공식 숨김 실행기로4191 재시작했다. 회사 문서/자격증명·메신저6테이블·Drive 설정·그래프 데모의 전후 해시 동일. 실제 회사1계정·팀0·채널34개·업무 프로필0, 메신저1계정·방5개·메시지/파일0 유지. 임시 시작 토큰은 소비 후 임시 파일을 삭제했다. 외부 배포는 하지 않았다.

화면: `verification/company-guide-library-live.png`(운영 첫 화면), `company-guide-library-390.png`, `company-guide-library-320.png`, `company-guide-welfare-390.png`, `company-guide-crew-welfare-320.png`, `company-guide-welfare-preview.png`. 이전6문서 검증은 아래에 이력으로 유지한다.

## 회사 안내·홈 네 메뉴 · 2026-10-01

홈을 첫 줄 **내 작업실 · 회사 안내**, 둘째 줄 **마케팅 · 메신저**의2×2로 구성했다. 회사 안내는 규칙·근무/회사·브랜드/업무·제작 분류, 제목·설명·본문 검색, 원문 읽기와 목차 이동을 제공한다. 기존 크루 핸드북·강사 수업 규칙·비전·철학·디자인 기준·워크스페이스 안내6개만 허용된 경로에서 읽으며 새 규정이나 AI 지침을 직원 규칙으로 만들지 않는다. 핸드북의 LAB 적용 대상·2027-02-25 시행 예정·미정 항목을 명시한다.

- 관련 자동 검사 **61/61 통과**, 실패·취소·건너뜀0. `verification/company-guide-tests.txt`. 신규 문서5개 검사에서 원문6개/적용 대상, 활성4역할·비로그인·권한 철회·임의 파일 경로 차단, HTML/위험 링크 탈출·표/목록 읽기, 본문 검색·분류·오류 재시도, 로그아웃/재로그인 중 늦은 응답과 계정 변경 초기화를 검증했다. 회사 안내 직접 주소·사이드바 접힘, 그래프 데모→실제 계정 복귀 회귀를 추가하고 기존 홈/콘텐츠 작업실/회사 서버 검사도 통과했다.
- 격리 일반 크루로 홈→회사 안내→정보보안 검색(1문서)→핸드북 읽기·목차의 「매일 하는 일」 이동→목록/분류 복귀를 CUA에서 확인했다. 실제 계정에서도 홈 네 칸·원문6개·검색 결과·LAB 시행일 안내를 확인했다. 읽기 요청만 사용했고 열람 서명·규정 변경·인사 처리·시험 업무 자료를 만들지 않았다.
- PC1280px에서는 첫 줄 y566/둘째 줄 y628로 두 칸씩 표시된다. 320×640px에서는 첫 줄 y505.49/둘째 줄 y563.49, 마지막 메뉴 끝621.49px로 네 칸이 화면 안에 있다. 문서 페이지/스크롤 너비320/320,390/390. 문서 표는292px 컨테이너 안에서480px 표만 가로 스크롤되며 페이지는 넘치지 않는다. 목차 이동 후 해당 제목의 화면 위치30.15px 확인. 모바일 크기는 검증 후 복원했고 검증/운영 콘솔 경고·오류0. 화면 `verification/company-guide-home-live.png`, `company-guide-list-live.png`, `company-guide-home-320.png`, `company-guide-reader-320.png`, `company-guide-list-390.png`.
- 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T16-50-24-456Z`의 COMPLETE 확인 후 정식 실행기로4191 재시작, ready:true 확인. 회사1계정·팀0·34채널·업무 카드0, 메신저1계정·5방·메시지0·파일0과 업무 원문·암호화 연결 정보·참여 관계·Drive 설정·그래프 데모 해시 유지. 현재 PC 로컬에만 반영했다.

## 내 작업실 제작 데스크·트렌드·개인 관리 페이지 · 2026-10-01

작업실을 제작 데스크/트렌드·레퍼런스/내 관리 페이지로 확장했다. 기존 콘텐츠 엔진·회사 채널 등록·계정 연결과 개인 도구를 재사용한다. 팁18개·양식10종·직접 검토9개·허용 원문14개를 연결했다. 외부 플랫폼 로그인·자동 게시·모델 비용은 추가하지 않았다.

- 관련 Node **98/98 통과**, 실패·취소·건너뜀0. `verification/workroom-creator-tests.txt`. 신규 HTTP4개/클라이언트7개는 활성/비활성·비로그인·뷰어/CSRF, 팀 미배정 직원의 다중 플랫폼 본인 등록·주입 담당자 무시·중복 담당 보존, 게시물/로컬/위험 주소 거부, 일부 API 실패와 재시도, 로그아웃/동일·다른 계정 재로그인 중 늦은 응답, 계정별 체크 초기화, 본인 활성 페이지만 표시, 안전한 URL·문구, 기존 새 기획 연결, 한국 시간 날짜와 0/미확인 반응을 검사했다. 관련 홈/탐색/콘텐츠 저장/벤치마크/회사 서버 회귀 포함.
- 격리된 팀 미배정 일반 크루로 단계별6개 팁·10개 양식·제작여정 원문·선택 양식→새 기획, 체크 후 새로고침 유지·복사된 양식의 체크 상태, Instagram 개인 참고 저장을 실제 CUA에서 확인했다. Facebook/Instagram/TikTok3개 주소 등록과 게시물 주소1개 오류 분리, 기존2개 재등록 시 신규0개, TikTok 필터·이름 수정·서버 재시작 후4채널/수정 이름 유지·계정 연결 준비 안내를 확인했다. 시험 주소·참고 자료는 격리 DB에만 저장했다.
- 공식 TikTok Creative Center의 **South Korea / Last7days** 화면을 직접 확인하고 #추석(16K게시물/36.4M조회), #틱톡인생작콘테스트(5.1K/22.2M), #한가위(2.4K/3.2M)의 화면 표시 집계를 기록했다. 원문·확인 날짜와 자동 갱신하지 않는 관찰 기록임을 화면에 명시했다. 적용 아이디어는 사실과 구분한다. 근거 화면 `verification/workroom-tiktok-korea-source-20261001.png`. YouTube/Meta 공식 분석의 발행/확인 날짜도 표시한다.
- PC·390/320px 세 화면과320px 등록 모달을 확인했다. 문서/스크롤 너비390/390,320/320이며 등록 모달304px로 가로 넘침0. 관찰 날짜가 UTC 날짜로 보이던 것을 기존 한국 시간 표시 함수로 수정하고 회귀 검사·실제 저장 자료에서2026.10.01을 확인했다. 검증·운영 콘솔 경고/오류0. 화면 `verification/workroom-creator-desk-320.png`, `workroom-creator-register-320.png`, `workroom-creator-pages-390.png`, `workroom-creator-trends-390.png`, `workroom-creator-live-desktop.png`, `workroom-creator-live-trends.png`, `workroom-creator-live-390.png`. 모바일 크기 설정은 검사 후 해제했다.
- 적용 전 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T16-10-02-955Z`의 COMPLETE 확인 후 정식 실행기로4191 재시작, ready:true 확인. 회사1계정·팀0·34채널·업무 카드0, 메신저1계정·5방·메시지0·파일0과 모든 업무 원문·암호화 연결 정보·참여 관계·Drive 설정·그래프 데모의 해시가 유지된다. 실제 계정에서 작업실·현재 정본·트렌드3개·기존34채널과 연결 안내를 확인했다. 운영 공간에는 시험 페이지/기획/참고를 등록하지 않았다.

현재 PC 로컬에 반영했다. 실계정 수집을 시작하려면 관리자 최초 플랫폼 앱 설정과 각 소유자의 공식 인증이 필요하다. 트렌드는 확인한 기록+공식 탐색 링크+회사의 실제 조사 보고서이며 자동 외부 조사 피드는 아니다.

## 내 작업실 입구와 개인 바로가기 · 2026-10-01

마린 홈의 마케팅·메신저 위에 가로 한 칸으로 **내 작업실**을 추가했다. 작업실은 내 할 일·저장한 메시지·내 업무 카드·내 성과의 기존 화면을 연결한다. 새 업무 데이터나 권한을 만들지 않으며, 기존 메신저 프레임과 초안을 유지한다. 정적 파일 변경으로 실행 중인 로컬4191에 반영했다.

- 관련 자동 검사57/57 통과: 홈·직접 주소·초안 유지·권한별 메뉴·데모 전환·메신저 개인 도구 연결. 내 할 일 진입은 이전 필터에 상관없이 mine/all, 저장한 메시지 진입은 saved로 돌아가는 회귀 검사 포함. 로그 `verification/workroom-tests.txt`.
- 실제 계정에서 홈→작업실→네 화면, 작업실 주소 새로고침, 메신저 할 일의 all/done 선택 후 mine/all 복귀, 예약 알림을 본 뒤 저장한 메시지 복귀, 내 업무 카드 열기/닫기(저장 없음), 데모에서 실제 작업실 복귀를 확인했다. 업무 자료나 시험 메시지를 생성하지 않았다.
- PC·390/320px에서 홈 첫 줄이 전체 너비이고 다음 줄의 두 메뉴가 나란히 표시된다. 가로 넘침0.320×640 마린 대화에서도 입력창 하단478px, 메뉴 시작505px로 겹침 없으며 메뉴 하단640px로 화면 안에 있다. 검증용 마린 질문은 기존 빈 세션에서 조회 후 비웠다. 콘솔 경고/오류0. 화면 `verification/workroom-home-desktop.png`, `workroom-home-390.png`, `workroom-home-320.png`, `workroom-desktop.png`, `workroom-320.png`; 검사 기록 `verification/workroom-ui-checks.json`.

## 내 팀·다른 팀의 7개 지표 추이 · 2026-09-30

검증 탭·프로세스는 종료했다. 자동 승인 검토가 검증용 임시 폴더2개와 사용된 임시 실행 URL 파일의 정리 명령을 거부했다. 경로를 확인한 뒤 정확한 절대 경로로도 재시도했으나 `blocked by policy`만 반환되어 삭제하지 않았다. 임시 폴더는 `C:/Users/q1212/AppData/Local/Temp/synk-team-trends-preview-wTu4Sn`과 `synk-team-trends-preview-yNPrtS`이며, 실제 앱 자료와 분리된 가상 검증 데이터다. 운영4191은 계속 ready:true다.

팀 현황을 소속 팀 기본 선택·다른 팀 선택·동일 축 비교 화면으로 바꿨다. 조회수/좋아요/공유/댓글/저장/도달/팔로워, 1주/1개월/3개월/전체/직접 기간, 누적/하루 증감, 키보드 날짜 선택·일별 수치 표를 제공한다. 새 `/api/team-trends`는 활성 회사 계정에 활성 팀의 집계만 반환한다. 개별 채널·콘텐츠·크루·자격증명은 반환하지 않으며 기존 상세 조회 권한을 확대하지 않는다. 데모도 같은 계산 함수를 사용한다.

- 관련 자동 검사98/98 통과 뒤 최종 변경에 대해33/33 재확인. 신규 HTTP5개·클라이언트4개에서 일반 크루/팀장/뷰어의 타팀 집계와 원문 접근 차단, 비활성 사용자·팀, 읽기 전용/만료 자료, 공동 담당 중복 방지, 0/미확인/일부/이전 기록/음수, 날짜·지표 검증, 데모 보존, 늦은 응답·계정 전환을 확인했다. 최종 로그 `verification/team-trends-final-tests.txt`.
- 격리3크루/2팀의 실제 일반 크루 계정으로 소속 팀 기본 선택, 콘텐츠팀 공유 추이와 그로스팀 비교, 내 팀 복귀, 7개 지표 전환,1주·직접 기간, 누적/하루 증감, Home/→ 날짜 선택을 확인했다. 공유 누적은 원본 예시 기록과 같은 콘텐츠팀147회·그로스팀136회이며 일부 수집은 별도로 표시한다. 실제 자료에 시험 팀·크루·수치를 넣지 않았다.
- PC·390/320px를 직접 확인했다.320px 브라우저의 스크롤바를 제외한 문서 너비305/스크롤너비305로 가로 넘침0, 선택/비교/모드 변경 뒤 키보드 초점 유지. 초기 SVG 색이 CSP에 막힌 문제는 인라인 스타일을 없애고 CSS 클래스로 수정해 실제 파란 선·갈색 범례/부분 관측점의 색까지 확인했다. 보안 정책은 유지했다. 검증·실제 앱 콘솔 경고/오류0. `verification/team-trends-ui-checks.json`, `team-trends-member-desktop.png`, `team-trends-member-320.png`.
- 서버 중지 후 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T14-47-00-975Z`의 COMPLETE 확인, 정식 실행기로4191 재시작 후 ready:true. 회사 documents/credentials 및 메신저 계정·방·메시지·파일·참여·나가기 기록의 해시를 대조해 보존했다. 실제1계정·팀0·34채널·업무카드0·5방, Drive 설정과 기존 데모 해시 동일. 실제 앱의 팀0 빈 안내와 기존 DEMO에서 다른 팀 공유 추이를 확인했다(`team-trends-live-empty.png`, `team-trends-live-demo.png`). PC 로컬 반영 완료. 실제 팀 배정과 수집 기록이 있어야 실제 팀의 수치가 표시된다.

## 업무 카드·직접 팀 구성 · 2026-09-30

공통 `atlas/work.js`에 확인된 업무 정보 정규화·미입력 표시·직접 선택한 구성의 역할/시간 검토를 추가했다. 회사 어댑터가 인증·현재 조직 범위·공유 동의·저장을 담당하며 기존 학습 기록과 분리한다. 성격 추론이나 자동 선발은 하지 않는다. 사용·API 계약은 `CREW_WORK.md`에 있다.

- 2026-09-30 세션 상태 재확인: 마지막 작업은 completed이며 현재 실행 중인 턴은 없다. 운영4191 health `ok:true, ready:true`, C 드라이브 여유19.27GiB를 확인했다. 아래 공간 부족으로 미완료였던 `studio.test.mjs`의 `the 100MiB streaming ceiling and interrupted streams clean their temporary files`만 `node --test --test-name-pattern`으로 다시 실행해 **1/1 통과**했다(실패·취소·건너뜀0). 격리 임시 DB에서 실행했으며 전체574개를 다시 실행한 결과는 아니다. 해당 미완료 검증은 해소됐다.
- 엔진·HTTP 신규11개, 업무 카드/마린 새 흐름13개 통과. 확인 필수·공유 기본 off·본인만 수정/삭제·관리자/팀장 현재 범위·미공유 값 비노출·0/null 구별·중복 선택·공유 철회·삭제·세션 철회·재시작·revision 충돌을 검증했다. 공유만 변경할 때 본인 확인 날짜는 유지한다. 부정문·타인의 정보·심리/성격 표현을 업무 정보로 추정하지 않는다.
- 전체 회귀는 제한된 병렬 실행에서 **573/574 통과**했다. 남은 기존 100MiB 업로드 상한 검사는 C 드라이브 여유 약55MiB에서 `ENOSPC`로 종료되어 완료하지 못했다. 최초 기본 병렬 실행의 scrypt/파일 프로세스 실패2개는 순차17/17로 통과했다. 제품 오류로 재현되지 않았고 전체 재실행을 중단했다. 로그: `verification/crew-work-final-bounded-tests.txt`, `crew-work-final-retry-tests.txt`, `crew-work-final-environment.txt`. 자동 승인 검토가 이번 실패 검사 잔여32KB 폴더의 삭제를 거부해 미삭제 상태로 남겼다.
- `SYNK_REVIEW_CREW_WORK=1`인 격리5크루/2팀 앱에서 실제 브라우저로 빈 카드 → 선택 → 본인 확인 전 저장 차단 → 저장 → 재열기 → 공유 철회를 확인했다. 철회 후 본인 카드 내용/확인 날짜는 유지되고 조직 목록은 비공개로 바뀐다. 선택한2명의 기획·디자인은 이름, 미기재 개발은 미확인, 요청10시간 대비8시간은2시간 부족으로 표시된다. 대화의 '디자인을 좋아하고 주10시간 가능'은 선호·시간 초안만 제안하고 저장/역량 승격하지 않는다.
- 데스크톱1280px·390px 초안·320px 카드/검토 결과를 실제로 확인했다. 320px 문서/스크롤 너비320, 모달302로 가로 넘침0. 내부 스크롤로 결과와 버튼에 접근한다. 검증/운영 콘솔 경고·오류0. 화면: `verification/crew-work-roster-desktop.png`, `crew-work-selection-desktop.png`, `crew-work-result-320.png`, `crew-work-profile-320.png`, `crew-work-draft-390.png`, `crew-work-profile-live.png`, `crew-work-roster-live.png`.
- 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T12-04-35-355Z`의 COMPLETE 확인 뒤 정식 실행기로4191 재시작, health ready:true 확인. 적용 전후 회사1계정·팀0·마케팅34채널·메신저5방·메시지0·파일0·참여 관계와 Drive 설정/그래프 데모 해시가 동일하다. 운영 업무 카드0건으로 시험 프로필을 넣지 않았다. 실제 유호 계정의 빈 업무 카드와 마린 → 회사 전체 공유0/1명 화면까지 확인했다. 현재 PC 로컬 반영이며 외부 모델 비용은 추가하지 않았다.

## 마린 중심 홈 · 2026-09-30

기본 첫 화면을 마린·단일 입력창·하단 마케팅/메신저로 바꾸었다. 기존 업무 화면과 명시적인 주소는 유지하고 상단에서 마린 홈으로 돌아온다. 승인된 `docs/캐릭터/화면_1024/마린_본체.webp`를 그대로 복사한 자산을 사용했다. 별도 모델·과금 없이 현재 권한의 실제 자료를 조회하고 화면을 안내하며, 자유 생성형 대화는 연결하지 않았다.

- 전체 자동 검사 **549/549 통과**, 실패·취소·건너뜀0. `verification/marin-home-final-tests.txt`. 이후 미래 질문 가드와 실제 구계정의 팀 미지정 오류를 보완한 최종 assistant HTTP **7/7 통과**. 기본 홈·기존 query/hash·기획 링크·데모 이탈, IME/중복 전송, 입력 초점·초안, 계정별 대화·로그아웃·늦은 응답, 부모 origin/source·정확한 원문·연속 이동 취소를 검사했다.
- 5명의 합성 크루가 있는 격리 앱에서 마린 질문 → 크루 DM, 프로젝트방, 파일 원문, 본인 할 일, 콘텐츠 기획함 이동을 실제 브라우저로 확인했다. 마케팅/홈을 왕복한 뒤 메신저 초안 `홈 왕복 초안 보존 검증`이 보존되었다. 업무 외 질문은 지원 범위를 안내하고 자동 전송이나 변경을 하지 않았다.
- 신규 콘텐츠 주간 집계가 마케팅과 다르게 나온 문제를 발견해 같은 `reportSource`를 읽기 전용으로 재사용했다. 동일한 9/29=100 → 9/30=160 관측에서 이번 주 +160·오늘 누적160·전주 비교불가를 회귀로 확인했다. 미확인·부분 기록·실제0, 현재 채널 권한, 탈퇴/삭제/비참여 방의 자료 비노출을 검사했다.
- 운영 구계정에 `teamId` 필드가 없어 성과 조회 때 SQLite 바인딩 오류가 발생한 것을 실제 화면에서 발견했다. 명시적인 기존 계정 연결과 기존 아이디 로그인을 격리 재현한 뒤 팀 ID가 있는 경우만 팀을 조회하도록 수정했다. 팀 미지정·null·삭제된 팀과 기존 메신저 ID 보존을 확인했다. 정식 실행기로 재시작 후 실제 유호 계정의 동일 질문이 정상 응답하는 것을 확인했다.
- 1440px 첫 화면, 390px 홈, 320×640px 대화를 확인했다. 입력 라벨 노출과 긴 대화의 하단 메뉴 밀림을 고쳤고 입력창은 최대144px까지 자동 확장한다. 최종320px에서 문서 너비/스크롤너비320, 높이/스크롤높이640, 하단메뉴 끝640으로 넘침 없이 대화 이력만 스크롤된다. CDP 화면 크기 변경은 검사 후 해제했다. 검증·운영 콘솔 경고/오류0. 화면은 `verification/marin-home-mobile-390.png`, `marin-home-chat-320.png`, `marin-home-long-chat-320.png`, `marin-home-live.png`, `marin-home-live-answer.png`.
- 적용 전 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T11-36-34-617Z`의 COMPLETE를 확인했다. 운영1계정·5방·메시지0·파일0·참여 관계·프로젝트 생성자/범위와 Drive 설정·그래프 데모 해시가 모두 유지된다. 실제4191 health ready:true와 마케팅/메신저 왕복·마린 홈 복귀를 확인했다. 현재 PC에만 반영했다.

## 프로젝트 나가기·메신저 동선 정리 · 2026-09-30

프로젝트 목록에 항상 보이는 **× 나가기**, 모바일 현재 방 제목 옆에도34px **×**를 추가했다. 한 번 확인 후 본인만 빠지며 삭제와 구분한다. 생성자도 나갈 수 있고 남은 작성 가능 크루에게 관리를 승계한다. 마지막 활성 참여자가 나간 방은 보관하고 해당 본인이 기존 삭제 목록에서 복원한다. 공개방의 회사 동기화·재시작·방 복원도 명시적으로 나간 상태를 유지하며 재초대로만 복귀한다.

- 회사·메신저 전체 자동 검사 **526/526 통과**, 실패·취소·건너뜀0. `verification/project-leave-final-tests.txt`. 신규 독립4개·회사8개·UI16개를 포함한다. 마지막 독립 관리자 통계 제외 보완 후 관련4/4도 재확인했다. 작성 권한 없는 크루의 본인 나가기/보관방 복구, 비참여자 차단·CSRF·동시 요청·Drive 전송 중 권한 철회·본인 여러 창 SSE·생성자 승계·명시적 재초대를 검사했다. 공개/선택 보관방에 기획 카드가 있으면 복원 시 현재 원문과 참여자 읽기 권한을 확인하며, 뷰어의 새 게시 권한은 주지 않는다.
- 격리된 합성5크루 CUA: × → 취소 → 나가기 후 본인 두 창에서 프로젝트가 사라짐, 다른 크루4명의 메시지2개·41바이트 첨부 유지, 남은 관리자 재초대 뒤 목록 복귀를 확인했다. 개인방의 미전송 초안도 그대로였다. 이름만 입력해 혼자 만든 검증방에서 나간 뒤 보관 목록을 통해 같은 방으로 복원했다. 운영 방에는 나가기·삭제·시험 메시지 요청을 보내지 않았다.
- 헤더의 중복 알림·할 일·관리 아이콘을 정리하고 알림함의 알림/할 일/저장 탭 접근을 확인했다. 크루 목록의 팀 필터를 드롭다운 하나로 합쳤다. 프로젝트 생성의 중복 분류 선택을 숨기고 이름·크루 선택부터 표시하며 참여 범위·설명은 접힌 추가 설정으로 옮겼다. 화면: `verification/project-leave-desktop.png`, `project-create-simple.png`.
- 390px·320px 실제 화면에서 목록과 제목 옆 ×, 확인·취소를 검증했다. 제목 옆34px 버튼은 긴 제목에서도 화면 안에 유지되고 페이지/스크롤 너비320px로 가로 넘침이 없다. 모바일 크기는 동일 검증 탭의 CDP 에뮬레이션으로 확인한 뒤 해제했다. 검증·실제 앱 콘솔 경고/오류0. 화면: `verification/project-leave-mobile-entry.png`, `project-leave-mobile320.png`.
- 중지 후 일관 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T11-14-29-383Z`의 COMPLETE를 확인하고 정식 실행기로4191 재시작, ready:true를 확인했다. 기존1계정·5방·메시지0·파일0·참여 관계·프로젝트 생성자/공개 범위를 보존했다. 운영 나가기 기록0, Drive 설정·그래프 데모 SHA-256 동일. 실제 계정 프로젝트 옆×까지 확인했다(`verification/project-leave-live.png`). 격리 검증 탭과 프로세스 종료.

## 프로젝트 대화방 삭제·복원 · 2026-09-30

프로젝트방의 **대화방 설정 → 대화방 삭제**, 전체채팅 목록의 **삭제된 대화방 → 복원**을 연결했다. 삭제는 확인창에서 방 이름·참여 인원·전체 참여자에게 미치는 영향을 확인한 뒤 실행한다. 대화와 첨부는 보관하며 Drive 파일을 지우지 않는다. 생성자 또는 참여 중인 관리자만 처리하고 기본방·팀방·개인방은 제외한다.

- 회사·메신저 전체 자동 검사 **498/498 통과**, 실패·취소·건너뜀 0. `verification/project-delete-final-tests.txt`. 권한·CSRF, 목록·검색·개인함 접근 차단, 재시작과 복원, 삭제 중 업로드/다운로드, 공개방 복원 대상의 기획 권한, 이용 중지 크루, 리마인더 보존, 늦은 응답·이중 클릭·다른 방 초안 보존을 포함한다.
- 운영과 분리된 합성 크루 fixture에서 실제 삭제 확인 취소 → 삭제 → 다른 창 SSE 반영 → 삭제 목록 → 복원을 검증했다. 복원 후 같은 방·메시지·파일 ID를 확인하고 다른 개인방의 미전송 초안이 보존됨을 확인했다. 운영 방을 삭제하거나 테스트 메시지를 추가하지 않았다.
- 실제 390px 설정의 삭제 버튼과 320px 확인창을 확인했다. 페이지 너비/스크롤 너비 모두320px이고 확인·취소 버튼은 화면 안에 표시된다. 브라우저의 크기 변경 기능이 응답하지 않아 동일 검증 탭의 CDP 화면 에뮬레이션으로 확인한 뒤 해제했다. 검증·운영 콘솔 경고/오류0. 화면: `verification/project-delete-settings.png`, `project-delete-mobile320.png`, `project-delete-live-settings.png`.
- 서버를 중지하고 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T10-54-15-251Z`의 COMPLETE를 확인한 뒤 정식 실행기로4191에 반영했다. ready:true, 기존1계정·5방·메시지0·파일0 및 공개 프로젝트의 ID·범위를 보존했다. 삭제된 운영 방0, Drive 설정·그래프 데모 SHA-256 전후 동일. 실제 계정의 대화방 설정과 삭제 버튼 표시까지 확인했다.

## 프로젝트 크루 초대 · 2026-09-30

프로젝트방에 **전체 크루 참여 중 / 선택한 크루만 참여**, **참여 크루 N명**, 초대 가능한 경우 **크루 초대**를 항상 표시했다. 생성창에서 참여 크루를 선택하고, 명단에서 이름·팀 검색과 다중 선택으로 추가한다. 등록 크루가 본인뿐이면 **먼저 크루를 등록하세요 → 팀·크루 관리**로 안내한다. 기존 공개 프로젝트는 자동 참여 상태를 설명하고 공개 범위·기록을 보존한다.

- 전체 회귀 **474/474**(`verification/project-invite-final-tests.txt`), 이후 추가된 독립 메신저 프로젝트 권한·재시작 회귀 **3/3**(`project-membership-final-tests.txt`) 통과. 신규 UI10개, 회사 프로젝트 HTTP5개 및 기존 협업·Drive·회사 기능을 포함한다. 선택 참여와 비참여 관리자 차단, 멤버 추가 권한·CSRF·중복 초대, 신규 가입 자동 참여 제외, 이용중지 후 재초대, 기획 원문 권한 재검사를 확인했다.
- 격리된 5명 fixture의 실제 CUA에서 관리자+검증 동료 2명으로 새 프로젝트를 만들고, 검색으로 디자인팀 크루를 골라 추가한 뒤 3명으로 갱신됨을 확인했다. 5개 합성 계정의 API를 대조해 선택한 3명에게만 방이 보이고 나머지 2명에게는 보이지 않았다. 운영 데이터에 검사용 크루·방·메시지를 추가하지 않았다.
- 390px·320px 초대창의 목록 스크롤, 선택 상태, 초대 버튼과 닫기 후 화면을 검수했다. 320px에서 페이지 너비/스크롤너비 모두320px, 모달286px로 가로 넘침 없음. 휴대폰 방 안에서도 텍스트 **크루 초대**가 바로 보인다. 검증 콘솔 경고·오류0. 화면: `verification/project-invite-desktop.png`, `project-invite-mobile390.png`, `project-invite-mobile320.png`, `project-invite-mobile-entry.png`.
- 실제 1인 운영 계정에서 기존 공개 프로젝트의 **참여 크루 1명** → 자동 참여 안내·크루 등록 안내 → **팀·크루 관리** 이동을 확인했다. `verification/project-invite-live-single.png`. 서버 중지 후 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T10-35-26-725Z`의 COMPLETE를 확인하고 정식 실행기로4191에 반영했다. ready:true, 기존1계정·5방·메시지0·파일0의 ID와 기존 프로젝트 공개 범위 보존. Drive 설정과 그래프 데모 SHA-256도 전후 동일하다.

## 메신저 업무 기능 6종 · 2026-09-30

멘션·개인 알림함, 방별 알림 설정, 공지 확인·미확인 명단, 담당·기한·상태가 있는 할 일, 기획 검토 카드, 작성자·기간·첨부별 검색, 개인 저장·다시 알림을 추가했다. 알림/할 일/저장은 기존 화면의 한 패널에 모았다.

- 회사·메신저 전체 자동 검사 **459/459 통과**. 실패·취소·건너뜀 0. `verification/collaboration-final-tests.txt`. 권한 철회, 조회 전용 역할의 개인 작업과 작성 차단, CSRF, 검색 필터·페이지, 알림 중복 방지·재시작, 공지 수정 후 확인 초기화, 공유 대상 전원의 기획 열람 권한, POST/PATCH 403·404·500 처리, 비동기 전송 중 새 초안 보존과 모바일 접근성을 포함한다.
- 운영 DB와 분리한 합성 크루 5명·팀 2개 fixture에서 CUA 검증: 멘션 선택→전송→대상자의 알림 생성, 알림 클릭 원문 이동, 할 일 진행 상태 변경, 공지 확인 1→2명 및 미확인 명단, 작성자+문서 검색, 개인 저장, 지정 시각 알림 실제 도착, 기획 원문 열기→검토 대상 선택→팀 카드 초안→직접 전송, 방 알림 설정 저장을 확인했다. 운영 계정에 검사용 메시지·파일·기획을 추가하지 않았다.
- 1133px에서는 패널과 대화가 나란히 배치되며 전송 버튼을 가리지 않는다. 390px·320px 가로 넘침 0. 모바일 패널 뒤 대화의 inert·접근성 트리 제외 및 닫기 후 원래 버튼 초점 복원, 데스크톱 크기 복귀 후 입력 재활성화를 확인했다. 멘션 팝업 잘림과 패널 겹침을 실제 화면에서 발견해 수정했다. fixture 콘솔 경고·오류 0. 화면: `verification/collaboration-desktop.png`, `collaboration-mobile390.png`, `collaboration-mobile320.png`.
- 서버 중지 후 일관 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T10-19-46-438Z`의 COMPLETE를 확인하고 정식 실행기로 4191을 재시작했다. `/api/health` ready:true. 기존 메신저 1계정·4방·메시지0·파일0의 모든 ID가 사전 기록과 동일하며 마케팅 34채널을 보존했다. 운영 화면의 실제 유호 계정, Drive 저장 상태와 새 도구 진입을 확인했다.
- 운영 알림함의 정상 빈 상태와 0개 표시, 패널 닫기 후 크루 목록 복귀, 운영 콘솔 경고·오류 0을 확인했다. 화면: `verification/collaboration-live.png`. 임시 브라우저 탭과 검증 프로세스를 종료하고 320/390px 화면 크기 설정을 원래대로 복원했다. 임시 fixture 폴더 삭제는 자동 승인 검사에서 차단되어 남겨 두었다.
- 알림은 앱 내 알림이며 로컬 서버 정지 중 예약은 다시 시작할 때 처리한다. 외부 호스팅·OS 푸시·추가 유료 구독은 적용하지 않았다. 기존 그래프 데모는 보존했다.

## 공통 메뉴 자동 접기 · 2026-09-30

왼쪽 마케팅·메신저 공통 메뉴는 기본으로 접고 **› / ‹**로 여닫는다. 마케팅·메신저 메뉴 진입 시 다시 접으며, 같은 화면의 일반 렌더링에서는 수동 펼침 상태를 유지한다. PC는 40px 영역만 남기고 모바일은 상단 버튼으로 겹쳐 열리는 메뉴를 사용한다. 토글은 DOM 상태와 메신저 위치만 갱신해 기존 iframe과 초안을 보존한다. 모바일에서 메뉴가 본문을 가릴 때는 메신저를 비활성화하고 읽음 처리를 잠시 중단한다.

- 관련 자동 회귀 **38/38 통과**: `verification/workspace-sidebar-tests.txt`. 최초 접힘, 화면 이동 자동 접힘, 일반 렌더링의 펼침 유지, iframe 동일성·크기 갱신, 모바일 inert/표시 상태, 데모의 메뉴 허용과 쓰기 차단 보존을 확인했다.
- CUA 실제 1133px 화면에서 공통 메뉴가 196px→40px로 줄고 메신저 본문이 937px→1093px로 넓어짐을 확인했다. 클릭·Enter 토글, 마케팅/메신저 왕복 자동 접힘, 지표 변경 후 펼침 유지와 메신저 임시 초안 보존을 확인하고 원래 초안으로 복원했다. 화면: `verification/sidebar-messenger-collapsed.png`, `sidebar-marketing-collapsed.png`.
- 390px·320px에서 메뉴 열기·Escape 닫기·메뉴 선택 자동 닫힘, 본문 너비와 가로 넘침 없음, Shift+Tab 초점 순환을 확인했다. PC 입력창에 초점이 있는 상태로 모바일 크기로 줄일 때 공통 메뉴 버튼으로 초점이 이동하도록 보완하고 재확인했다. 콘솔 경고/오류 0. `verification/sidebar-marketing-mobile390.png`, `sidebar-messenger-mobile320.png`, `sidebar-mobile-expanded.png`.
- 정적 프런트만 새로고침으로 4191에 반영했다. 실제 메시지·파일·계정 데이터 변경이나 서버 재시작은 하지 않았다. 메신저 내부 대화 목록은 유지했다.

## 공지·정보방·수다방 · 2026-09-30

상단을 **개인채팅 / 팀채팅 / 전체채팅**으로 정리하고 전체채팅의 첫 세 방을 **공지 / 정보방 / 수다방**으로 고정했다. 기존 기본 공지사항과 팀 라운지는 같은 ID의 공지·수다방으로 연결하고 정보방만 새로 만들었다. 기본방은 고유 식별자로 구분하며 사용자가 만든 동명 방·수정한 방·기존 프로젝트방은 그대로 보존한다. 공지의 글·답글·업로드·수정·고정은 회사 admin 또는 독립 메신저 owner만 가능하고 서버에서도 검사한다. 일반 크루의 읽기·반응·본인 기존 자료 정리와 조회 전용 역할의 기존 제한은 유지한다.

- 자동 검사 **87/87 통과**, 실패·취소·건너뜀 0: `verification/messenger-system-rooms-tests.txt`. 전체 메신저 테스트와 회사 메신저·조직·데모 진입 회귀를 포함했다. 기존 ID·메시지·첨부 다운로드 보존, 재시작 2회 중복 방지, 모호한 이름과 팀/개인방 오인 방지, 신규 크루 참여, admin/member/manager/viewer 권한, UI 입력·첨부·답글·편집·핀 제한 및 권한 변경 후 초안 보존을 검증했다.
- 실제 서버는 시작 시 중지 상태였다. 일관 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-30T08-40-52-768Z`의 COMPLETE를 확인한 뒤 정식 실행기로 4191을 시작했고 ready:true를 확인했다. 백업 DB와 대조해 기존 모든 방 ID 및 사용자·메시지·파일 테이블이 동일함을 확인했다. 실제 크루 1명·메시지 0·파일 0이며, 기존 3방에서 정보방만 추가해 4방이 됐다.
- CUA 실제 계정: 세 분류, 공지→정보방→수다방 순서, 역할 설명·아이콘, 관리자 공지 작성 UI를 확인했다. 별도 임시 회사의 일반 크루 계정으로 공지 읽기 전용, 정보방·수다방 작성 가능, 팀 전용 목록과 기존 공용 프로젝트방 보존을 확인했다. 실제 계정에 시험 메시지·파일·크루는 추가하지 않았다. 실제 화면: `verification/public-rooms-final.png`.
- PC 1280×720 및 모바일 390×844·320×844에서 실제 표시를 확인했다. 빈 방은 스크롤을 맨 위에서 시작해 아이콘이 잘리지 않게 했고, 모바일 전체 목록은 기본 세 방이 한 번에 보이도록 224px를 확보했다. 추가 방과 크루는 각 목록에서 스크롤한다. 일반 크루의 공지 읽기 전용 안내, 정보·수다방 입력 가능, 크루 클릭→1:1 이동과 메뉴 닫힘 확인. 가로 넘침·콘솔 경고/오류 0. `verification/public-rooms-mobile390.png`, `public-rooms-mobile320.png`, `public-rooms-member-readonly.png`는 격리된 검증용 계정 화면이다. 검증용 서버와 탭은 종료하고 실제 4191 메신저는 열어 두었다.
- 그래프 데모 SHA-256은 `growth-history-demo-before.sha256`와 동일하다. 실제 기존 데이터와 Drive 연결을 보존했고 공용 외부 서버 배포·추가 결제는 하지 않았다.

## 메신저 개인·팀별·전체 분류 · 2026-09-30

메신저 상단을 **개인채팅 / 팀별채팅 / 전체채팅** 세 탭으로 정리했다. 개인에는 나에게·1:1 대화, 팀별에는 실제 소속 팀 전용방, 전체에는 공용방·공개 프로젝트방만 표시한다. 분류별 마지막 대화와 안 읽음 필터를 기억하고 크루·검색 결과에서 대화를 열면 맞는 분류로 이동한다. 초안·답글·첨부는 대화방별로 유지한다. 빈 분류에서는 전송·첨부를 막고 안내를 표시하며 팀 배정 변경과 접근 권한 철회를 반영한다.

- 자동 검사 **40/40 통과**, 실패·취소·건너뜀 0: `verification/chat-categories-tests.txt`. 기존 클라이언트, 신규 분류 전환·초안·빈 팀·늦은 응답·권한 철회, 통합 메신저 서버와 데모 진입 회귀를 포함했다. 별도 읽기 검토에서 빈 팀 화면 갱신과 DM·팀방 생성 후 오래된 응답의 선택 덮어쓰기 방지를 확인했다.
- CUA: 실제 유호 계정에서 세 분류와 각 대화 목록, 크루 클릭→개인채팅, 안 읽음 필터의 분류별 복원, 빈 팀 안내 및 입력 비활성화를 확인했다. 나에게 임시 초안으로 팀별·전체 왕복 후 복원을 확인하고 기존 초안으로 정확히 되돌렸다. 메시지 전송·파일 업로드·크루/팀 생성은 하지 않았다.
- 데스크톱·900px·390px·320px에서 분류 표시와 전환을 확인했다. 모바일에서도 세 탭이 항상 보이며 목록을 연 상태의 분류 전환 후 목록이 정상적으로 닫힌다. 키보드 방향키 이동, 모바일 가로 넘침 없음, 콘솔 경고/오류 0. 실제 터치 입력 검사는 하지 않았다. 화면: `verification/chat-categories-final.png`, `chat-categories-mobile390.png`, `chat-categories-mobile320.png`.
- 실제 계정은 크루 1명·팀 미배정이므로 팀별채팅은 배정 안내를 표시한다. 3명 그래프 데모는 그대로 보관했다. 정적 프런트 변경을 새로고침으로 로컬 4191에 반영했으며 외부 배포는 하지 않았다.

## 데모에서 메신저 진입 복구 · 2026-09-30

그래프 데모의 메신저 버튼이 disabled여서 들어갈 수 없었다. 이제 메신저 메뉴/빠른 검색에서 선택하면 데모 query·가상 크루·팀·hash를 제거하고 `/?tab=messenger`로 새 페이지를 연다. 실제 `/api/me`와 `/api/state`를 다시 읽어 실제 계정으로 초기화한다. demo와 messenger가 함께 든 직접 주소도 같은 경로로 정리한다. 데모 API/쓰기 차단은 유지했다. 메신저 영역을 차지하던 그래프 데모 진입 배너도 메신저에서는 제외했다.

- 기존 데모·권한·내비게이션 **30/30 통과** (`verification/demo-messenger-base-tests.txt`), 신규 `demo-messenger-navigation.test.mjs` **8/8 통과**. 실제 shell 메뉴 활성화·capture 전환·직접 주소·실제 사용자 재조회·데모 쓰기 차단 회귀 포함.
- CUA: 민지 데모에서 메신저 선택 → 유호 실제 관리자·팀 라운지·전체/팀/개인 대화 목록·크루 목록 확인. 마케팅 왕복 후 재진입과 직접 데모 메신저 주소도 정상. 콘솔 경고/오류 0. `verification/demo-messenger-entry-fixed.png`.
- 로컬 프론트 수정 및 새로고침으로 반영했다. 메시지 전송·파일 업로드·크루 생성·데모 삭제 없음. 사용자가 바로 확인할 수 있도록 실제 메신저를 열어 두었다.

## 그래프 날짜별 콘텐츠 TOP 3 · 2026-09-30

상세 분석의 성장 추이와 전체 추이에 공통 호버 팝업을 추가했다. 선택 날짜·지표·개인/팀/전체·필터 범위에 맞춰 1~3위 제목, 크루 이름, 수치를 표시한다. 하루 증감은 양일 비교가 완료된 콘텐츠의 차이, 누적은 당일 정확 관측값으로 정렬한다. 0·감소값도 보존하고 팔로워는 계정 지표 안내만 표시한다. 제작자가 명시된 자료와 관측 당시 담당 크루를 구분하며 접근 가능한 크루 이름만 반환한다.

- 자동 검사 **399/399 통과**: `verification/chart-hover-final-tests.txt`. 신규 집계·API·클라이언트 회귀 포함. 최종 키보드 자동 스크롤 보완 후 클라이언트 **18/18 통과**: `verification/chart-hover-client-final.txt`. 날짜/권한/필터 전환의 늦은 응답, 캐시, 이스케이프, 첫·두 번째 터치, 모달 전환, 키보드 포커스와 자동 스크롤을 확인했다.
- CUA 실제 마우스오버: 민지 9.23 조회수 하루 증감 **2,041** 중 **작은 자동화가 바꾼 하루 +990 / 문서 정리 전과 후 +360 / AI로 반복 업무 10분 줄이기 +249**, 제작 크루 민지 표시. 누적 전환·팔로워 안내·키보드 날짜 이동·Enter 날짜 상세 열기·팝업 닫힘을 확인했다. 전체 추이 9.30은 **당일 85,873 / 23개 중 집계**, 24개 중 미수집 1개를 순위에서 제외하고 일부 기록으로 표시했다. 상위 서연 7,419 / 서연 6,955 / 민지 5,946.
- 데스크톱·390px·320px에서 팝업 경계·제목·크루명·수치·페이지 가로 넘침을 확인했다. 브라우저 콘솔 경고/오류 0. 모바일 터치 이벤트 전송은 IAB 도구에서 미지원이므로 실제 터치는 주장하지 않으며, 첫 탭 팝업/두 번째 상세 동작은 자동 회귀로 확인했다. 화면: `verification/chart-hover-final.png`, `chart-hover-mobile390.png`, `chart-hover-mobile320.png`.
- 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T18-50-56-806Z` COMPLETE 확인 후 정식 실행기로 4191 재시작, ready:true. 데모 SHA-256은 `growth-history-demo-before.sha256`와 동일하며 원본/실제 계정/외부 서비스는 변경하지 않았다.

## 주간 비교와 첫 기록부터 전체 추이 · 2026-09-30 최종 후속

주간 홈은 **이번 주 누적 / 지난주 같은 요일까지 누적 / 전주 대비 / 전월 동기 대비** 네 칸으로 변경했다. 개인·팀·전체 모두 월요일부터 현재 요일까지와 정확히 7일 전 같은 구간을 비교한다. 그래프는 같은 0축·요일축을 쓰며 전월은 별도 보조 카드, 오늘·어제는 작은 보조줄로 남긴다.

**전체 추이** 화면은 첫 유효 관측부터 현재까지 한 누적 곡선으로 표시한다. 1주·1개월·3개월·전체, 직접 날짜 입력, 일·주·월 표시를 지원한다. 차트 포인터·터치·키보드 좌우/Home/End로 날짜를 선택하고 상단 날짜·수치 및 십자선을 함께 갱신한다. 선택 날짜의 채널별 누적·전일 대비·당일/비교 대상 수를 펼칠 수 있다. 종료일 누적, 선택 시작일 대비 증감·증가율, 두 날짜 사이 일수로 계산한 일평균, 시작일 다음 날부터의 최고 성장일을 표시한다.

- 집계: 동일한 권한/담당자 원본 범위로 날짜별 정확 관측과 최신 관측을 구분한다. 누적값을 여러 날 더하지 않는다. 주·월 차트는 마지막 날짜 값을 표시하며, 누락은 0으로 채우지 않고 이전 기록은 점선/빈 점과 설명으로 구분한다. 부분 비교는 표시하고 비율·일평균은 전체 대상을 비교할 때만 제공한다. 820일 기록도 366일 제한 없이 확인했다.
- 자동 검사 **374/374 통과**, 실패/취소/건너뜀 0: `verification/growth-history-final-tests.txt`. 선택기간·월/연도 경계·권한·담당 변경·데모 불변·오래된 응답·UI 포인터/키보드·날짜 변경·팀 전환 회귀 포함. 최종 주간 눈금을 읽기 쉬운 정수 단위로 정리한 후 렌더 회귀 **9/9**도 다시 통과했다.
- CUA: 민지 이번 주 **3,964**, 지난주 같은 요일까지 **4,049**, **-85(-2.1%)**, 전월 동기 **+18,945(+365.5%)**를 확인했다. 전체 추이는 **7.31~9.30 / 62일**, 종료 누적 **32,648**, 첫 기록 대비 **+29,418(+910.8%)**, 일평균 **+482.3**, 최고 성장일 **9.23 +2,041**. 최근 1주는 9.24 기준 **+8,262**, 직접 8.1~8.31은 **+5,224**로 원본 집계와 일치했다. 9.24 채널 두 개의 조회수 **10,646 / 13,740**, 전일 대비 **+494 / +414**도 확인했다.
- 개인/팀/전체, 그로스팀→콘텐츠팀, 지표 변경, 월말 단위 표시, 날짜 선택·채널 내역, 직접 날짜·홈 복귀를 실제로 확인했다. 전체 범위는 **90,321(23/24개 당일 확인·이전 기록 포함)**, 일부 증감임을 표시하고 일평균을 비운다. 이전 팀의 custom 기간이 새 팀의 기록보다 앞설 때 오류가 나던 문제를 발견해 팀·범위 전환 시 전체 기간으로 초기화하고 회귀 검증했다. 고정 프리셋은 날짜가 바뀌면 새 기준일로 다시 계산한다.
- 데스크톱·390px·320px 실제 화면 가로 넘침 없음, 콘솔 경고/오류 0. 화면: `verification/growth-week-final.png`, `growth-week-mobile390.png`, `growth-history-final.png`, `growth-history-mobile390.png`, `growth-history-mobile320.png`, `growth-history-live-empty.png`. 실제 계정은 미수집값을 —/첫 기록 대기로 표시하고 기존 **34채널**을 유지한다.
- 데모 JSON SHA-256이 변경 전후 동일하다. 기준값은 `verification/growth-history-values.json`, 해시는 `growth-history-demo-before.sha256`. 사용자 삭제 지시 전까지 데모를 보관한다. 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T18-23-25-928Z`의 COMPLETE 확인 후 정식 실행기로 4191 재시작, ready:true와 실제 화면을 확인했다. 로컬 반영 완료이며 외부 배포·추가 결제는 없다.

## 오늘·어제·전월 동기 성장 홈 · 2026-09-30 후속

사용자 피드백에 따라 첫 화면을 **오늘 누적 / 어제보다 / 지난달 같은 기간보다** 세 수치와 두 달의 성장 곡선 하나로 줄였다. 기본 지표는 조회수·좋아요·팔로워이며 다른 지표·일별 수치·콘텐츠/운영은 접어 둔다. 팀/크루/콘텐츠 순위·복잡한 필터·기간 선택·CSV는 **자세히 분석**에서 계속 쓴다. 선택한 나/팀/전체의 과거와 비교하며 첫 화면으로 돌아오면 오늘/월초 기준을 다시 적용한다. 접힌 운영 영역의 하이라이트와 팀 비교는 첫 화면에서 자동 요청하지 않는다.

- `growth=1` 분석 응답에 권한·선택 범위를 유지한 성장 집계를 추가했다. 오늘은 exact 관측값만 표시하고 어제와 같은 대상의 기록으로 증감을 계산한다. 전월 동기는 달력의 지난달 같은 날짜까지 비교한다. 양 기간이 완전하고 일수가 같을 때만 차이·비율을 표시하며 전월 증가량이 0 이하이면 비율을 만들지 않는다. 누락 구간은 선을 끊고 부분 관측은 빈 점으로 구분한다. 감소·0·미확인은 별도로 표시한다.
- 자동 검사 **343/343 통과**: 기존+집계/HTTP/클라이언트 335개(`verification/growth-home-tests.txt`)와 새 그래프 렌더 8개(`growth-home-view-tests.txt`). 월말/윤년/연초/0·음수/미수집/부분 수집/담당 변경·권한, 오늘 날짜 복귀, 숨은 API 요청 생략, 지표 전환·읽기 전용을 확인했다.
- CUA 수치 대조: 민지 조회수 당일 **32,648**, 어제 대비 **+1,049**, 이번 달 증가 **24,128**/전월 동기 **5,183**, 차이 **+18,945(+365.5%)**. 좋아요·팔로워 전환과 팔로워 전월 성장 감소 **-238(-32.1%)**를 확인했다. 상세 분석의 이전 기간 선택 후 요약으로 복귀하면 9.30 당일 수치로 돌아온다. 전체/팀의 부분 수집에서는 기록 수를 표시하고 전월 비율을 비운다.
- 기본 데스크톱·390·320px에서 실제 표시와 줄바꿈, 모바일 전용 SVG 좌표계·양 곡선·음수 카드·접힌 보조정보를 확인했다. 페이지 가로 넘침과 콘솔 경고/오류 0. 실제 유호 계정은 오늘 미수집값 —, 운영 영역은 기존 34채널로 표시했다. 화면: `verification/growth-home-final.png`, `growth-home-mobile390.png`, `growth-home-mobile320.png`, `growth-home-live.png`.
- 전월 기준을 확보하려고 기존 데모의 7.31~8.4 관측만 추가했다(게시글 관측30 + 계정 관측30). 원본 JSON 바이트를 `data/demo/marketing-demo.json.before-history-*.json`에 백업했고, 기존 관측 해시·기준일9.30·크루3·팀2·채널6·게시글24 보존을 확인했다. 실제 DB는 수정하지 않았다. 임시 데이터는 삭제 지시 전까지 유지한다.
- 서버 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T17-55-20-067Z`의 COMPLETE를 확인하고 정식 실행기로 4191 재시작, ready:true와 실제 화면을 확인했다. 외부 배포·실제 SNS 업로드·추가 결제는 없다. 다음은 단순화된 성장 홈에 대한 사용자 피드백이다.

## 개인·팀·전체 비교 그래프와 보관형 데모 · 2026-09-30

개인·팀·전체의 성과 요약/상세 분석에 대상별 수평 막대 그래프와 이번/직전 기간 비교 그래프를 추가했다. 지표·대상·기간 증감/최근 누적 선택, 상위 10개/전체 보기, 상세 이동을 연결했다. 기존 성장 추이는 유지한다. 0 기준을 공유하는 SVG 막대는 CSP에서도 표시되며 음수·확인된 0·미확인을 구분한다. 전체 팀 비교는 팀 미배정/운영 종료 채널도 집계하고 필터가 걸린 결과에 다른 범위 캐시를 섞지 않는다.

- **데모 보관 중**: 별도 `data/demo/marketing-demo.json`에 크루 3명·팀 2개·채널 6개·게시글 24개·기준일 2026-09-30의 8주 기록과 기준 관측을 생성했다. 실제 관리자만 접근하며 데모 API와 클라이언트 양쪽에서 쓰기를 차단한다. 실제 회사/메신저 계정·게시물을 생성하지 않았다. 사용자 삭제 요청 전까지 유지한다.
- 자동 검사 **320/320 통과**(회사 281 + 메신저 39), 실패·취소·건너뜀 0. 데모 재생성 시 원본 보존, 인증/권한 철회·쓰기 차단·운영 문서/자격증명 불변, API 범위별 실제 집계, signed SVG·null/0·기간 범위·XSS, 화면 이동/크루 전환/API 분리 회귀 포함. 결과: `verification/graph-demo-tests.txt`, `graph-demo-messenger-tests.txt`.
- CUA에서 전체→개인→팀 전환, 서연 선택 후 내 2채널/콘텐츠팀, 그로스팀 선택, 담당자 클릭→상세 필터, 콘텐츠 24개 펼치기→게시글 상세, 하루 증감/누적 추이 전환을 확인했다. 전체 28일 조회수 증감 **52,770 = 민지 23,910 + 준호 13,211 + 서연 15,649**; 팀별 37,121/15,649. 전체 최근 조회수 90,321. 팔로워 증감에서 준호 +775, 민지 +470, 서연 -268의 0선/음수 방향을 확인했다.
- 기본 데스크톱과 390/320px에서 그래프·선택기·값·줄바꿈을 실제 검수했다. 모바일 페이지/요소 가로 넘침 0, 마지막 콘솔 경고/오류 0. 실제 데이터 복귀 시 유호·기존 34채널·미수집 값 —를 확인했다. 화면: `verification/graph-demo-crew.png`, `graph-demo-period.png`, `graph-demo-mobile390.png`, `graph-demo-mobile320.png`.
- 서버 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T15-34-13-912Z`의 COMPLETE를 확인하고 정식 실행기로 4191에 재시작했다. 추가 구독·외부 배포·SNS 실제 업로드·Drive 파일 변경 없이 로컬에 반영했다. 다음은 사용자의 그래프 피드백과 임시 데이터 삭제 지시다.

## 팀별 현황 비교 · 2026-09-30 마무리

팀 현황의 성과 요약에 팀별 비교 카드를 추가했다. 크루·채널·연결 수, 누적 조회수·선택 기간 증감·팔로워를 표시하며, 팀 카드를 누르면 해당 팀 성과로 이동하고 키보드 초점도 옮긴다. 관리자는 활성 팀 전체, 다른 크루는 자기 활성 팀 안에서 기존 열람 범위만 본다. 빈 팀/미수집 값은 —로 표시한다. 기간·사용자·권한 변경 시 오래된 응답을 표시하지 않는다.

- 전체 Node **297/297 통과**. 신규 API4개·클라이언트7개 회귀 포함. 43팀에서도 각 데이터 테이블을 한 번씩 읽고 DB를 변경하지 않는지 확인했다. 결과: `verification/team-overview-tests.txt`.
- 2026-09-29 격리 DB CUA에서 마케팅팀(4크루·2채널·조회수450), 디자인팀(1크루·1채널·650)을 비교했다. 하루 기간은 조회수 증감150/250으로 갱신됐으며 디자인팀 클릭→조회수650 상세 성과로 이동했다. 일반 크루 로그인 후에는 자기 팀·허용1채널/조회수290만 보였다. 운영 데이터에 합성 팀을 추가하지 않았다.
- 데스크톱·320px 카드/숫자/선택 표시를 실제 검수했고 페이지·카드 가로 넘침 및 콘솔 경고/오류 없음. 화면: `verification/team-overview-fixture.png`, `team-overview-mobile320.png`.
- 반영 전 중지 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T13-37-09-153Z`의 COMPLETE 확인. 재개 시 로컬 서버가 중지돼 정식 분리 실행기로 다시 시작했고 ready:true 확인. 2026-09-30 실제 유호 계정의 팀 미배정0채널·팀 등록 안내를 확인했다. `verification/team-overview-live-empty.png`. 실제 팀·담당 채널 배정은 사용자 운영 준비 단계다.

## 마케팅 내·팀·전체 현황 분리 · 최종 후속

마케팅 상세 메뉴를 **내 현황 / 팀 현황 / 전체 현황 / 콘텐츠 기획 / 채널·수집**으로 변경했다. 앞의 세 현황에서 성과 요약·상세 분석을 전환하며 기존 일별/콘텐츠/채널별/담당자별 분석을 유지한다. 내 현황은 실제 담당 채널, 팀 현황은 선택한 활성 팀, 전체는 기존 열람 권한 범위만 집계한다. 팀이 없거나 비활성인 경우 전체 회사 수치로 확대하지 않는다. 팀 선택, 마지막 마케팅 화면, 새로고침, query/hash 공유 링크를 연결했다.

- 전체 Node **286/286 통과**, 실패·취소·건너뜀 0. 범위별 집계·권한·팀 미배정/비활성·URL/공유 링크 회귀 포함. 결과: `verification/marketing-scopes-tests.txt`. 최종 안내 문구 변경 후 JavaScript 구문 재확인.
- 격리 DB의 합성 크루 5명·팀 2개·채널 3개로 CUA 검증: 내 담당 1채널/조회수160, 마케팅팀 2채널/450, 전체 3채널/1,100, 디자인팀 1채널/650. 상세 분석에 선택 팀을 유지하고 새로고침 후에도 디자인팀·상세 분석이 복원됨을 확인했다. 합성 자료는 운영 DB에 넣지 않았다.
- 390px·320px에서 모든 메뉴가 보이며 내/팀/전체는 첫 줄, 기획/채널은 둘째 줄로 정렬된다. 날짜·팀 선택·콘텐츠 기획·채널 목록의 페이지 가로 넘침 없음, 격리 화면 콘솔 경고/오류 없음. `verification/marketing-scopes-mobile390.png`, `marketing-scopes-mobile320.png`.
- 서버를 중지해 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T12-08-10-458Z`에 백업하고 COMPLETE를 확인했다. 정식 분리 실행기로 4191을 재시작해 ready:true를 확인했다. 실제 계정의 내 담당34채널 및 팀 미배정0채널·설정 안내를 확인했다. `verification/marketing-scopes-live.png`, `marketing-scopes-team-empty.png`.

## 호칭 변경

사용자 요청으로 화면·접근성 이름·초대·역할·공유 안내와 서버 오류의 ‘직원’을 ‘크루’로 통일했다. ‘팀·크루’, ‘크루 목록’, ‘전체 크루’, ‘크루 초대’를 실제 화면에서 확인했다. 내부 식별자·API·계정 데이터는 유지했다. 수정 JavaScript 구문 검사를 통과했고 정식 실행기로 다시 시작한 `/api/health ready:true`를 확인했다.

## 마케팅 한 영역·직원 디렉토리·실제 팀 대화 · 최종 후속

주요 메뉴를 **마케팅 / 메신저** 두 개로 줄였다. 마케팅에는 현황·성과 분석·콘텐츠 기획·채널·수집을 모으고, 기존 공유 주소 및 마지막 마케팅 화면을 유지한다. 메신저는 전체·소속 팀·개인 대화 목록과 직원 디렉토리를 함께 표시한다. 직원 이름 검색, 전체/내 팀/팀별 필터, 이름 클릭 즉시 1:1 대화를 연결했다. 기존 공개 category=team 방은 공개로 유지하고, 새 팀 전용방만 실제 활성 팀 소속원으로 제한한다. 관리자의 자기 팀 설정은 관리자 역할·현재 세션을 유지한다.

- 전체 Node **280/280 통과**, 실패·취소·건너뜀 0. 최종 반응형 보완 뒤 클라이언트 회귀 9/9 재통과. `verification/team-directory-tests.txt`.
- 새 회귀는 실제 팀 소속과 디렉토리, 다른 팀 관리자 접근 차단, 팀 이동·비활성화·신규 입사, SSE 갱신, 느린 메시지·고정·업로드·Drive 다운로드 중 접근 철회, 독립 메신저 로그인 우회 차단, 관리자 자기 팀 설정과 세션, 빠른 직원 선택을 포함한다.
- 합성 직원 5명·팀 2개의 격리 localhost 앱에서 CUA로 직원 클릭→새 DM→메시지 전송, 내 팀 필터, 이름 검색, 팀 전용 메시지·답글·파일 표시, 관리자 자기 팀 변경→팀방/직원 목록 자동 갱신, 탭 왕복 초안과 콘텐츠 하위 화면 복귀를 확인했다. 실제 운영 공간에는 합성 직원을 만들지 않았다.
- 기본 데스크톱에서 오른쪽 디렉토리, 900px에서 왼쪽 디렉토리, 390/320px에서 직원 전용 목록과 DM 이동을 확인했다. 중간 폭 직원 목록을 72px에서 약 170px로 개선했고 모바일 직원 목록은 약 389~436px를 확보했다. 확인한 화면에서 가로 넘침 없음. `verification/team-directory-fixture.png`, `team-directory-mobile390.png`, `team-directory-mobile320.png`.
- 운영 서버 중지 상태에서 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T08-48-10-396Z`에 백업하고 `COMPLETE`를 확인한 뒤 재시작했다. `/api/health`의 `ready:true` 확인. 회사 34채널·1직원, 메신저 1계정·3방·0메시지·0파일 보존. 실제 디렉토리는 유호 1명/팀 미배정으로 표시한다.
- 운영 브라우저에서 **Drive 연결됨, unmet23@gmail.com, 423.86GB / 5TB**를 확인했다. 페이지 콘솔 경고·오류 없음. `verification/two-area-marketing-live.png`, `team-directory-live.png`. 새 Drive 업로드나 외부 배포는 이번 변경에서 수행하지 않았다.

아래 기록은 이전 단계의 메뉴 구성과 검증이다.

## 메뉴 개편·메신저 강화 · 후속 반영

메인 메뉴를 마케팅 현황·메신저·성과 분석·콘텐츠 기획 네 개로 정리했다. 채널 등록/담당자/연결/수집 상태/기록은 마케팅 현황 안의 채널·수집 관리로 합쳤고, 팀·직원과 설정은 하단 관리 영역으로 옮겼다. 채널/수집/스튜디오의 이전 주소는 통합된 위치로 연결된다. 상태 필터가 검색·등록한 채널을 가리는 문제와 OAuth 결과 정리 시 현재 화면 주소가 사라지는 문제도 회귀 검증 후 수정했다.

콘텐츠는 기획함·새 기획·좋은 콘텐츠로 정리하고 보조 입력/자료/검토 목록은 접었다. 좋은 콘텐츠에서 기존 팀 예시·벤치마크·개인 참고를 보며 링크/글 예시를 바로 등록한다. 제작 상황판·소재함·검토실 진입은 제거하고 데이터/API/기존 재생 파일은 보존했다.

메신저는 답글/원문 연결/답글 모아보기, 고정/해제, 안 읽음, 팀·프로젝트·1:1 분류, 방 이름·설명·분류 수정, 파일 범위/종류/이름 검색·페이지 추가·원대화 이동을 추가했다. 팀·프로젝트 방은 회사 공용이다. 실제 렌더한 마지막 메시지 ID까지만 읽음 처리하며 숨긴 모듈·파일/고정 화면·다른 대화방은 읽음 처리하지 않는다.

- 최종 전체 Node **270/270 통과**, 실패·취소·건너뜀 0. 후속 UI 마감 뒤 메신저 클라이언트 회귀 5/5 재통과. 결과는 `verification/reorganization-tests.txt`에 있다.
- 임시 DB의 합성 사용자로 CUA 브라우저에서 로그인, 예시 등록/상세, 기획 생성/저장, 안 읽음 필터, 답글 작성/전송/모아보기, 탭 왕복 초안, 고정 목록, 파일 전체/문서 검색, 원대화 이동, 프로젝트 방 생성을 직접 확인했다. 기본 1265px·390px·320px에서 새 입력/탐색 화면의 가로 넘침과 버튼 잘림을 확인했다. 스크린샷은 `verification/reorganized-*.png`에 있다.
- 운영 서버를 중지해 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T08-25-15-759Z`에 백업(`COMPLETE`)한 뒤 4191에 적용했다. health `ready:true` 확인. 실제 마케팅 34채널·메신저 1계정/3대화방/0메시지/0파일을 보존했다.
- 실제 관리자 화면에서 `unmet23@gmail.com`의 **421.49GB / 5TB**, Drive 연결됨을 다시 확인했다. 운영 공간에 검증용 메시지/파일/기획/예시를 작성하지 않았다. 새 Drive 업로드는 이번 메뉴 개편에서 반복하지 않았다.

아래는 초기 통합 및 접속 복구 당시의 검증 기록이다.

## 접속 복구

2026-09-29 후속 접속 불가 신고에서도 4191·4197 listener가 모두 없고 연결이 거부됐다. 앞서 직접 실행했던 개발용 프로세스 세션도 더 이상 존재하지 않았다. 기존 `start-company.ps1 -NoBrowser -Messenger` 정식 실행기로 분리 프로세스를 시작했고, 실행기 종료 후에도 두 포트의 동일 프로세스와 `/api/health ready:true`를 확인했다. CUA에서 실제 유호 계정의 메신저 페이지·입력창을 다시 열었다. 당시 개발용 프로세스의 종료 로그는 없어 정확한 종료 원인은 확정하지 않았다. 복구 화면은 `verification/workspace-recovered.png`다.

후속 접속 실패 신고 때 4191·4197 양쪽의 listener가 없고 HTTP 연결이 거부되는 것을 확인했다. 기존 런처가 서버 출력을 버려 종료 원인은 확정하지 못했다. 서버를 다시 실행해 실제 브라우저의 유호 계정·메신저·실시간 연결을 확인했다. 런처는 두 listener와 초기화의 준비 완료(`health.ready=true`)를 기다리도록 수정했고, 다음 실행부터 비공개 `data/logs/`에 서버 출력·시작 오류를 남긴다. 준비 중 성공 오판, 포트 충돌 정리, 중복 종료와 기존 서버 회귀 7/7 통과. 재시작 뒤 ready=true·4197 주소 이동·기존 서버에 대한 런처 시작 링크 발급을 확인했다. PC 부팅 자동 실행이나 외부 서버는 추가하지 않았다.

## 구현·실제 적용

회사 앱을 공통 워크스페이스로 실행하고 `/messenger/`에 메신저를 합쳤다. 공통 로그인·직원 권한·초대, 메뉴·읽지 않은 대화 표시·초안 보존·업무 화면 링크 공유를 연결했다. 최신 직원 정보가 달라질 때만 메신저 DB를 동기화해 반복 조회의 불필요한 쓰기를 없앴다.

실제 두 서버를 중지하고 일관된 백업을 만든 뒤 통합 서버를 시작했다. 4191과 이전 주소 안내용 4197을 동일 프로세스가 처리하며 `http://127.0.0.1:4197/`는 `http://127.0.0.1:4191/?tab=messenger`로 302 이동한다. 회사 health의 `workspaceIntegration:true` 확인. Windows PowerShell 5에서도 기존 `start.ps1 -NoBrowser`가 통합 서버로 연결되는 것을 확인했다. 한국어 경로가 있는 실행기는 UTF-8 BOM으로 저장했다.

운영 데이터의 마케팅 채널 34개, 회사 관리자 1명, 기존 메신저 사용자 1명·대화방 3개를 보존했다. 기존 관리자와 메신저 계정을 명시적으로 1:1 연결했다. 메시지·파일은 적용 전후 모두 0개로, 운영 공간에 시험 데이터를 작성하지 않았다.

앱 내 브라우저에서 실제 관리자 계정으로 공통 홈→메신저를 열고 파일 저장소 화면에서 `unmet23@gmail.com`, **421.49GB / 5TB**, Drive 연결됨을 확인했다. 기존 active connection ID가 유지됐다. 새 Drive 파일 업로드는 이번 통합 검증에서 수행하지 않았다.

## 자동 검증

```powershell
node --test tools/company-messenger/tests/*.test.mjs docs/마케팅/온라인마케팅지도/engagement/company/*.test.mjs
node docs/마케팅/온라인마케팅지도/engagement/company/verify-workspace.mjs
```

- Node **246/246 통과**, 실패·취소·건너뜀 0. 임시 DB·가짜 Drive 사용.
- 통합 회귀 10개: 명시적 ID 연결과 기존 메시지·첨부 보존, 기존 아이디 로그인과 회사 비밀번호 전환, 다른 사람 DM 차단, 조회 전용·CSRF·세션 해제·SSE 차단, 업로드/조회 중 권한 변경, Drive 전환 직전 권한 취소, 직원 동기화.
- 변경 없는 직원 목록으로 bootstrap/summary 반복 조회 시 메신저 DB `total_changes()` 증가 0. 직원 추가·이름/역할/활성 변경 반영, 재활성화 시 기존 ID·개인 메모방 유지.
- 두 저장소 백업에 암호화 키·Drive 연결·등록된 로컬 첨부·검토 파일 포함, 미완료 업로드 제외, 기존 데이터 경로를 복원 경로로 잘못 재사용하지 않는지 검사.
- 브라우저 **23개 검사 통과**. 공통 로그인, 메시지 전송, 첨부 원본 다운로드, 탭 왕복 초안 보존, 스튜디오 링크 초안, 숨긴 채팅의 읽지 않음 보존, 실제 읽음 반영, 조회 전용 UI, 로그아웃 시 모듈 제거.
- 1440/900/768/390/320px에서 부모 화면·메신저 가로 넘침 0. 페이지 오류·외부 서비스 요청 0. 화면 원본과 보고서는 Git 제외 `verification/workspace-*.png`, `workspace-ui-report.json`에 저장했다.
- 실제 화면 검토 후 로딩 완료 시 뒤에 남은 안내를 접근성 트리에서도 숨기고 공통 모달이 열린 동안 채팅 프레임의 키보드 접근을 차단했다.

## 백업·남은 범위

적용 직전 백업: `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-09-29T07-38-14-737Z` (`COMPLETE` 포함). 자세한 복원 절차는 백업 안의 `RESTORE.txt`에 있다. 백업에는 자격증명이 포함되며 Git에 추가하지 않았다.

현재 PC의 로컬 실행만 반영했다. 추가 결제·외부 배포·SNS 계정 신규 연결·자동 게시·Drive 파일 자동 삭제는 하지 않았다. 직원들의 원격 동시 사용은 공용 서버와 HTTPS 구성 후 별도 부하·운영 검증이 필요하다. 공유 기능은 현재 업무 화면의 제목과 링크를 초안에 넣는 범위이며 특정 제작물의 자동 알림·댓글 복제는 포함하지 않는다.

## 첫 홈 화면 정리 · 2026-10-02

`public/marin-home.js`의 홈 마크업과 `public/marin-home.css`의 홈 스타일만 바꿨다. 안내 왼쪽에 제목과 짧은 설명, 오른쪽에 승인 마린 원본과 기존 메신저 봉투 스티커를 배치했다. 입력창과 내 작업실·회사 안내·마케팅·메신저 네 카드를 압축하고 카드마다 쓰임을 표시했다. 마린 응답이 나온 뒤에는 안내를 작게 접고 대화 영역만 스크롤한다. 로컬 `4191` 정적 파일로 적용했다.

- 기존 홈·내비게이션·작업실 검토 검사 **33/33 통과**, JavaScript 구문 확인 통과.
- 실제 브라우저 **320×640 / 390×844 / 768×900 / 958×629 / 1280×600 / 1280×720 / 1440×960**에서 가로 넘침 없이 네 메뉴가 첫 화면 안에 표시되는 것을 확인했다. 높이 600px 화면도 전체 메뉴가 잘리지 않는다.
- 네 메뉴를 실제로 열고 홈으로 돌아왔으며 각 화면의 주소·선택 상태와 홈 입력 초안 보존을 확인했다. 키보드 이동 시 회사 안내에 청금석 2px 초점 테두리가 표시된다.
- 실제 **내 할 일** 조회 응답을 320×640에서 확인했다. 대화·입력창·네 메뉴가 화면 안에 남고 테스트 대화만 정리했다. 기존 사용자 초안은 유지했다.
- 최종 브라우저 경고·오류 **0**. 회사 1계정·34채널, 메신저 1계정·5방·0메시지·0파일, Drive 설정과 그래프 데모 해시 보존 검사 통과.

최종 [화면](verification/home-upgrade-after-20261002.png), [모바일 화면](verification/home-upgrade-390x844-20261002.png), [검증 기록](verification/home-upgrade-20261002.json). 서버·인증·데이터·다른 업무 화면은 이 변경의 수정 범위가 아니다.

## 전체 화면의 Slack 참고 리디자인 · 2026-10-02

위의 홈 단독 변경 이후 사용자의 전체 리디자인 요청을 반영했다. 공통 상단 검색·고정 주요 메뉴·세부 메뉴·스크롤 본문을 통일하고 홈, 작업실, 회사 안내, 마케팅 하위 화면, 메신저와 공통 로그인·모달의 글자·색·간격·버튼·목록을 정리했다. 메신저의 중복 상단 바와 큰 콜라주를 줄이고 크루 목록은 필요할 때 연다. 모바일에는 하단 탐색, 선택 후 닫히는 세부 메뉴와 메시지 더보기를 적용했다. 현재 로컬 4191 서버가 정적 파일을 바로 제공한다.

- 메신저 검사 **131/131**, 워크스페이스 관련 클라이언트·회사 안내·홈·이동 검사 **122/122** 통과. 두 범위 합계 **253개**, 실패·취소·건너뜀 0. 격리 DB와 기존 시험 공급자를 사용했다.
- 실제 계정의 홈·작업실·회사 안내·마케팅을 **320×640 / 390×844 / 768×900 / 958×629 / 1280×720 / 1440×900**에서 실제 메뉴로 전환했다. **24개 화면 조합 모두 가로 넘침 0**. 마케팅의 팀·전체·기획·채널·분석·추이도 PC와 390px에서 12개 조합을 확인했다.
- 회사 핸드북 핵심 안내와 긴 원문·목차·9개 표, 작업실의 트렌드와 기존 34개 관리 페이지를 실제로 열었다. 390px 원문은 가로 넘침 0이며 표는 자체 영역에서 읽는다. PC 메뉴 접힘 상태의 화면 왕복 유지와 전역 검색→작업실 결과, 모바일 회사 안내·작업실 메뉴 선택 후 닫힘을 확인했다.
- 실제 메신저는 PC·390px에서 가로 넘침 0, 입력창이 프레임 안에 있다. 별도 3인 검수 공간의 메시지 3개는 6개 크기로 확인했다. 크루 목록 열기·닫기, 대화 검색, 모바일 메시지 더보기와 공통 메뉴의 키보드 초점 순환을 확인했다. 작업실 왕복 후 검수용 작성 초안이 유지되며 원래 값으로 복원했다. 실제 회사에 검수 계정·메시지·파일을 넣지 않았다.
- 실제 회사 **1계정·0팀·34채널**, 메신저 **1계정·5방·0메시지·0파일**, 회사 문서/자격증명과 기존 메신저 기록·Drive 설정·그래프 데모의 보존 해시 검사 통과. 최종 실제 화면과 별도 검수 화면의 경고·오류 로그 **0**. 임시 검수 서버를 종료하고 브라우저 크기 설정을 복원했다.

화면: [최종 홈](verification/slack-20261002/home-final.png), [실제 메신저](verification/slack-20261002/messenger-live-1440x900.png), [모바일 메신저](verification/slack-20261002/messenger-live-390x844.png), [회사 안내](verification/slack-20261002/handbook-1440x900.png), [제작 데스크](verification/slack-20261002/workroom-1440x900.png). 메시지가 있는 [검수 화면](verification/slack-20261002/messenger-fixture-1440x900.png)은 실제 회사 대화가 아니다. [워크스페이스 검증 기록](verification/slack-20261002/workspace-review.json), [메신저 검증 기록](verification/slack-20261002/messenger-review.json)에 치수와 확인 항목을 저장했다.

로컬 UI 개편과 기존 기능 회귀 확인이다. 이번에는 외부 배포·SNS 신규 연결·실제 Drive 전송·원격 직원 동시 운영을 다시 수행하지 않았다. 직원 사용성·만족도·업무 시간 개선은 실제 사용 피드백이 필요하다.

## 전체 펠트 브랜드 마감 · 2026-10-02

후속 중복 메뉴 정리: 홈의 흰 세부 메뉴와 펼치기 버튼을 제거하고 왼쪽 펠트 주요 메뉴만 남겼다. 홈 본문은 옆 빈 칸 없이 넓어지고, 다른 공간의 세부 메뉴는 그대로 열린다. 홈·내비게이션 검사 **26/26 통과**. 실제 1133px·390px 홈에서 사이드바/토글 없음·가로 넘침 0, 작업실 이동과 홈 복귀, 계정 메뉴의 팀·크루/설정 접근을 확인했다. [중복 제거 후 홈](verification/felt-20261002/home-nav-single.png).

Slack 참고 개편의 탐색 구조에 최신 승인 펠트 부품을 적용했다. 공통 머리·주요 메뉴의 청금석 섬유, 실제 코랄 행동 판·연코랄 선택 판·칩·체크 배지, 승인 마린·책·편지·돋보기 스티커를 홈·작업실·회사 안내·마케팅·메신저에 연결했다. 오래 읽는 본문·입력창은 흰 바탕이다. 작은 실땀 선은 화면 확인 후 일반 경계로 정리했고, 대화 날짜는 12px·보통 자간으로 선명하게 표시한다.

- 메신저 **131/131**, 워크스페이스 관련 **122/122**, 합계 **253개** 검사 통과. JavaScript 구문 확인 통과. 이번 후속 변경은 마크업·CSS·승인 자산 복사이며 인증·서버 계약을 바꾸지 않았다.
- 실제 홈·작업실·회사 안내·마케팅을 **320×640 / 390×844 / 768×900 / 958×629 / 1280×720 / 1440×900**에서 확인했다. **24개 조합 가로 넘침·깨진 이미지 0**. 마케팅 하위 메뉴 6개는 PC·390px의 **12개 조합**에서 확인했다.
- 실제 메신저와 별도 3인 검수 공간의 대화 3개를 각각 같은 6개 크기로 확인했다. **12개 조합 가로 넘침 0**, 작성창이 프레임 안에 있다. 별도 검수 대화는 실제 회사 데이터가 아니다.
- 작업실 체크를 선택해 **26px 실제 체크 배지**가 보이고 다시 해제되는 것을 확인했다. 기존 34개 관리 페이지와 390px 등록창의 코랄 버튼을 확인하고 입력·등록 없이 닫았다. 회사 커리큘럼의 원문·목차·9개 표를 390px에서 열어 가로 넘침 0을 확인했다.
- 높이 720px PC 홈에서는 네 공간 카드가 첫 화면 안에 있다. 더 좁거나 낮은 화면은 본문을 스크롤하며, 고정 주요 메뉴에서 모든 공간으로 바로 이동한다. 마스코트·부품을 줄인 낮은 PC용 배치도 별도로 확인했다.
- 이번에 복사한 승인 자산 **18개**가 원본 SHA-256과 일치하며 로컬 HTTP **200**이다. 최종 실제 탭의 경고·오류 로그 **0**. 회사 **1계정·0팀·34채널**, 메신저 **1계정·5방·0메시지·0파일**, 기존 문서·자격증명·대화·Drive 설정·그래프 데모의 보존 해시 검사 통과.

최종 [홈](verification/felt-20261002/home-final.png), [실제 메신저](verification/felt-20261002/messenger-live-1440x900.png), [회사 안내](verification/felt-20261002/handbook-1440x900.png), [작업실](verification/felt-20261002/workroom-1440x900.png), [검수 대화](verification/felt-20261002/messenger-fixture-1440x900.png), [종합 검증](verification/felt-20261002/final-review.json). 치수는 같은 폴더의 `workspace-responsive.json`, `marketing-responsive.json`, `messenger-responsive.json`, `messenger-live-responsive.json`, `home-fit.json`에 있다. 임시 검수 서버는 종료됐으며 브라우저 크기를 복원했다. 중단됐던 로컬 서버는 기존 정식 실행기로 재개해 `ready:true`와 실제 접속을 확인했다. 현재 PC의 로컬 반영이며 외부 배포·직원 원격 운영·실제 Drive 전송은 이번 마감의 확인 범위가 아니다.

## 전체 중복 제거와 마감 검수 · 2026-10-02

이 절이 앞선 홈 카드·반복 세부 메뉴 기록을 대체하는 최신 화면 기준이다. 공통 주요 메뉴는 한 곳에, 공간별 분류는 세부 메뉴에, 작성·등록·검색은 각각의 기능 영역에 모았다.

| 영역 | 최종 정리 |
| --- | --- |
| 공통·홈 | 본문 업무 공간 4카드, 이어서 하기, 홈의 흰 메뉴, 반복 홈·계정 버튼 제거. 주요 공간은 PC 왼쪽/모바일 하단, 홈은 로고, 관리는 상단 계정에 한 번만 표시. |
| 내 작업실 | 본문 분류·개인 바로가기 제거. 새 기획은 선택한 양식에서 한 번, 원문 링크는 단계별 출처마다 한 번, 등록 페이지는 URL 링크 하나. |
| 회사 안내 | 본문 분류 버튼과 같은 분류로 이동하는 제목 링크 제거. 복지·조건·원문 보존, 모바일 핵심 안내의 좁은 두 칸을 읽기 쉬운 행으로 변경. |
| 마케팅·채널 | 보고서 전환은 본문 3개 선택에 통합. 반복 상세 분석 이동, 지표 선택, CSV 저장, 채널 등록·새로고침·건강 진단 이동 제거. 데모와 공유 도구는 한 줄. |
| 콘텐츠 | 기획 시작·보완 버튼은 각각 한 번. 기본 화면의 새 기획 탭 중복 제거, 작성 중인 내용과 저장 기획으로 돌아가는 탭은 상태별 표시. |
| 메신저 | 반복 분류 제목·대화 소개·빈 화면 CTA 제거. 새 대화방 하나에서 공용/프로젝트, 내 업무 하나에서 알림/할 일/저장, 검색 하나에서 전체/현재 대화 범위 선택. |
| 관리 | 계정 메뉴에서 팀·크루/설정 접근. 빈 팀 화면의 중복 생성 버튼 제거. |

- 워크스페이스·회사 안내·작업실·기획·현황 관련 **132/132**, 메신저 **131/131**, 겹치지 않는 두 범위 합계 **263개** 검사 통과. 실패·취소·건너뜀 0. 첫 로딩 중 크기 변경 때 초기화 전 상태를 읽던 실제 오류를 수정하고 재현 검사를 추가했다. 수정 뒤 워크스페이스 132개를 다시 실행했으며 실제 새로 열기·320px 왕복에서 새 경고·오류 0.
- 실제 계정에서 **1133×704 / 390×844의 42개 화면 조합**을 확인했다. 홈, 작업실 3개, 회사 안내 5개·문서 읽기, 마케팅 6개·기획함·기획 작성·좋은 콘텐츠, 메신저, 팀·크루와 설정을 검사했다. 같은 동작·주소를 가진 반복 컨트롤, 페이지/본문의 가로 넘침, 깨진 이미지가 확인되지 않았다. 기록은 [review.json](verification/dedup-20261002/review.json)에 있다.
- 추가로 **320×640**의 홈·회사 안내·기획함·메신저 4개와 모바일 설정 하단을 확인했다. 페이지 가로 넘침·반복 동작·깨진 이미지가 없고 설정의 긴 설명과 연결 버튼이 화면 안에 있다.
- 실제 메뉴 이동, 모바일 메뉴 선택 후 닫힘·Escape 복귀, 작성 중 기획 왕복 후 입력 유지, 회사 안내 원문 읽기, 메신저 내 업무 3탭·검색 범위·공용/프로젝트 종류 선택, 계정 관리 접근을 확인했다. 검수용 작성 입력은 지웠으며 저장·전송·방 생성은 하지 않았다.
- 실제 회사 **1계정·0팀·34채널**, 메신저 **1계정·5방·0메시지·0파일**, 원문·자격증명·Drive 설정·데모 보존 해시 동일. 실제 메시지가 있는 화면은 이번 운영 계정 검수에서 확인할 수 없었고 기존 메신저 검사로 해당 상태를 검증했다.

최신 화면: [홈 PC](verification/dedup-20261002/home-final-pc.jpg) · [홈 모바일](verification/dedup-20261002/home-final-mobile.jpg) · [회사 안내 모바일](verification/dedup-20261002/guide-overview-final-mobile.jpg) · [채널 관리](verification/dedup-20261002/marketing-channels-final-pc.jpg) · [메신저](verification/dedup-20261002/messenger-final-pc.jpg). 승인 펠트 자산을 유지한 로컬 4191 반영이다.

## 추가 실사용 마감 검수 · 2026-10-02

후속 질문에서 생성 대기 중 새 기획을 시작했을 때 이전 응답이 새 작성 화면을 바꾸는 오류를 재현했다. 생성 요청의 식별자를 확인하고 기획 이동·새 작성·다른 기획 열기·로그아웃 때 이전 요청을 무효화했다. 늦은 성공·실패·로딩 종료가 새 작업의 상태를 바꾸지 않는다. 이미 요청한 서버 작업 자체를 취소하는 기능은 아니다.

- 관련 회귀 6개를 추가했고 회사 **138/138**·메신저 **131/131**, 합계 **269개** 검사 통과. 새 작성 중 이전 성공/실패, 새 요청의 로딩 유지, 다른 공간 이동, 실패 뒤 입력 보존·재시도, 같은 사용자 재로그인을 검증했다.
- 회사 운영 DB와 분리한 임시 공간에서 합성 기획 3개·메시지 3개로 실제 UI를 확인했다. 세 구성안 전환, 선택과 검토 상태 저장·새로 열기, 내용 보완·작성 중 왕복, 새 기획 생성과 저장이 동작했다. 긴 제목의 단어 중간 줄바꿈도 수정했다. PC·390px 결과와 데이터가 있는 메신저에서 가로 넘침·깨진 이미지 0, 브라우저 경고·오류 0. [기록](verification/dedup-followup-20261002/review.json) · [저장 결과](verification/dedup-followup-20261002/generated-pc.jpg) · [긴 제목 모바일](verification/dedup-followup-20261002/plan-mobile.jpg) · [검수 대화](verification/dedup-followup-20261002/messenger-mobile.jpg).
- 임시 서버·탭을 종료하고 크기 설정을 복원했다. 운영 데이터 쓰기 없이 실제 회사의 원문·계정·채널·대화방·Drive/데모 해시 보존을 재확인했고 실제 서버는 ok:true·ready:true다.

남은 검증은 실제 휴대폰의 키보드·터치와 배포하려는 환경에서 여러 직원의 실사용이다. 브라우저 크기 조절과 분리 검수 계정의 결과가 실제 기기·직원 운영 검증을 대신하지 않는다.



## 작업실 일일 트렌드 수집 · 2026-10-02

- 사용자 요청에 따라 외부 탐색 카드 대신 국가·날짜·플랫폼별 내부 피드를 구현했다. 참고 시장은 한국·미국·중국이며 몽골을 기본 시장으로 지정하지 않는다. Google 공식 RSS(KR/US), 바이두 정상 공개 목록(CN), YouTube 공식 문화 분석 RSS(GLOBAL)를 실제 수집한다. YouTube 차트는 기존 Data API 키가 있을 때만 수집하며, TikTok/Instagram/도우인의 승인 연결과 샤오홍슈 공식 경로는 미확보 상태로 명시했다. 전체 SNS 탐색이나 인기 영상 수집 완료가 아니다.
- 2026-10-02 05:01 KST 초기 저장 후 실제 UI의 수동 수집으로 05:08 KST 갱신한 회사 DB에 검색 트렌드70건(한국10·미국10·중국50), 공식 문화 분석2건을 저장했다. 발행일과 수집일을 분리하고 검색 대략값/바이두 지수/유튜브 누적 조회를 합산하지 않는다. 수동 관찰·회사 기준·벤치마크·개인 레퍼런스는 하단에서 보존했다.
- 일일 서비스/API16개·수집기9개·기존 서버31개 **56/56**, 작업실·기획·회사 안내·탐색 등 기존/추가 클라이언트 묶음 **156/156**, 겹치지 않는 두 실행 **212/212** 통과. 두 별도 Node 프로세스의 동시 수집은 collector1회/run1개, 만료된 이전 응답은 최신 스냅샷을 덮지 못함을 독립 확인했다. 예약 전 수동 수집, 실패·빈 목록 보존, 영구 미지원 재시도 차단, 관리자·CSRF·Origin·조회 역할, 종료 시 저장 완료, 날짜·계정 race, UI 진행 중 폴링과 취소를 검사했다.
- 승인 펠트 부품을 재사용하고 처음10개/20개 더 보기로 압축했다. 격리 계정으로 1133/390/320px ×3국가, 30/50개 펼침, 320px 설정 저장, 지난 빈 날짜, 미연결 플랫폼, 원문·주제의 새 기획 전달을 실제 UI로 확인했다. 운영 환경에서도 3국가 목록·원문/출처 상태·수집 설정·지금 수집을 확인했다. 새 기획에 출처 국가·실제 지표·발행/수집 시각이 전달되는 화면도 대조했고 관련 클라이언트25개를 다시 통과했다. 운영 기획은 저장하지 않았다. 화면·세부 기록: [검수 결과](verification/trends-20261002/review.json).
- 서버 중지 시점의 백업 COMPLETE 확인 뒤 새 서버로 재시작했고 health ok:true·ready:true다. 회사 원본 문서(인증/감사·새 트렌드 기록 제외), 암호화 자격증명, 메신저 사용자/방/메시지/파일/참여관계, Drive·데모·키·통합 설정의 해시 보존 검사를 통과했다. 실제1계정·34채널·5방·0메시지·0파일을 유지했다.
- 기본 한국시간06시 서버 스케줄과 공식 Codex heartbeat **SYNK 일일 트렌드 수집**(synk-2, ACTIVE)을 등록했다. 실행 명령은 company/daily-trends-cli.mjs --scheduled이며 저장된 설정·일일 잠금·중복 판정을 따른다. 예약 전 실제 CLI 실행은 changed:false로 추가 수집하지 않음을 확인했다. 미래06시 자동 실행 자체는 아직 시간이 도래하지 않아 관찰하지 않았다. PC/실행환경 중지 중의 정시 실행·실제 플랫폼 승인 연결·다른 직원/실제 모바일 기기 운영은 미검증이다.

## 작업실 플랫폼 제작 인사이트 · 2026-10-02

YouTube Trends·TikTok Top Ads·Facebook·Instagram을 기존 트렌드·레퍼런스에 통합했다. 내부 자료 저장·플랫폼/실제 국가/검색 필터·상세·수정·보관/복원·기존 새 기획을 연결하고 공식 출처 도움말은 한 접기 목록에 모았다.

- 최종 관련 자동 검사 **73/73 통과**, 실패·취소·건너뜀0. 서비스14·HTTP5·클라이언트16·작업실29·서버 인증/수집/준비 회귀9개. [검사 로그](verification/creative-research-tests.txt). 기본 비공개/명시적 공유, 활성 팀·현재 채널 권한, CSRF/Origin·viewer·세션/채널 해지 중 import·종료 대기, 공식 주소/리다이렉트·용량·수치 검증, 동시 중복, 날짜/국가/미확인0·CTR 상대 위치, 제목 XSS, 늦은 응답/모달·기획 경합을 검사했다.
- 실제 공개 KIPP SoCal 교육 Top Ads 상세를 읽어 제목·US·좋아요510/댓글43/공유4·CTR Top18%를 확인했다. 조회·저장·도달은 null이며 예산 High는 금액을 뜻하지 않는다. 원문 필터와 실제 광고 국가를 따로 보관하고 영상/썸네일 파일은 가져오지 않았다. Meta 2023·2024 공식 안내의 발행연도와 기능 이용 가능 여부를 메모에 유지한다. 오늘 확인 날짜를 최신 급상승 사례의 발행일로 바꾸지 않는다.
- 새 임시 DB의 합성 관리자/크루/열람자, 플랫폼4개 채널과 검수 자료4개로 동작을 확인했다. 실제 UI에서 메모 수정 후 공식 확인 시각·출처/수치 유지, 보관·복원, 근거 전달 후 기획함0 유지, 같은 광고의 국가 필터 변경 재등록 중복0을 확인했다. Meta 광고의 성과 입력은 숨김/높이0이며 종류 변경에 맞춰 주소 안내·담당 채널 필수가 바뀐다.
- PC1280px·실제1133px·390/320px와320px 자료 모달을 확인했다. 문서 너비390/390·320/320, 모달304px이며 가로 넘침0. 깨진 이미지0, 실제/격리 콘솔 경고·오류0. [PC 실제 광고](verification/creative-20261002/live-topads-desktop.jpg), [전체 자료](verification/creative-20261002/live-all-desktop.jpg), [실제390px](verification/creative-20261002/live-390.jpg), [실제320px](verification/creative-20261002/live-320.jpg), [320px 모달](verification/creative-20261002/fixture-form-320.jpg). 합성 YouTube 예시는 운영 DB에 넣지 않았다.
- 서버를 중지한 뒤 백업 `C:/Users/q1212/AppData/Local/SYNK/workspace-backups/synk-workspace-2026-10-01T21-18-06-622Z`의 COMPLETE를 확인하고 정식 실행기로4191을 재개했다. health ok:true·ready:true. 원본 회사 문서(인증/감사·일일 트렌드·신규 제작 자료 제외), 암호화 연결 정보, 메신저 사용자/방/메시지/파일/참여 관계, Drive·데모·키·통합 설정의 해시를 보존했다. 실제1계정·34채널·5방·메시지0·파일0 유지. 실제 작업실에 교육 광고1개와 공식 제작 가이드2개만 추가했다.

로컬4191에 반영했다. Studio·Meta 개인 화면/전체 탐색의 자동 수집, 다른 직원의 실제 계정 운영, 원격/실제 모바일 기기, 외부 배포는 이번 확인 범위에 포함하지 않는다. 저장한 공개 자료를 매일 갱신하는 수집기는 추가하지 않았다. 기존 일일 검색 트렌드 수집은 유지한다.
